
import numpy as np
import xarray as xr
from PIL import Image, ImageDraw, ImageFont

from .fromtxt import makefromtext
from .fromformula import makefromformula


def make(self):
    if hasattr(self, "flx_text"):
        flx_txt = self.flx_text
        dom_xsize = self.domain.nlon
        dom_ysize = self.domain.nlat
        file_font = getattr(
        self, "file_font", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf"
        )
        flx = makefromtext(flx_txt, dom_xsize, dom_ysize, file_font)
    
    elif hasattr(self, "flx_formula"):
        formula = self.flx_formula
        zlon = self.domain.zlon
        zlat = self.domain.zlat
        flx = makefromformula({"sum": formula}, zlon, zlat)
    
    else:
        raise Exception("Not recognized type of fluxes")

    flx = xr.DataArray(
        flx[np.newaxis, np.newaxis, ...],
        dims=("time", "lev", "lat", "lon"),
    )
    return flx

