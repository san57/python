import pandas as pd
import copy

from logging import info, debug


def adjoint(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    """Translates real-size data as extracted from the model outputs to
     the control space. This includes mainly temporal and spatial aggregation.
     This routine is used in adjoint mode, thus computes operations on
     increments.

     Args:
         self (Plugin): the control vect
         datastore (dict): the data at the model resolution to be converted
                           to the control space
         di (datetime): starting date of the simulation window
         df (datetime): ending date of the simulation window
         workdir (str): pycif working directory

     """

    ddi = min(di, df)
    ddf = max(di, df)

    datastore = pipe.datastore
    datavect = obsvect.datavect

    tracer_ids = mapper["outputs"]

    # Loop over type of outputs
    for tracer_id in tracer_ids:
        mod_input = tracer_id[0]
        trcr = tracer_id[1]

        # If this type of input is not considered in the control vector,
        # ignoring the model sensitivity
        component = getattr(getattr(datavect, "components", None),
                            mod_input,
                            None)
        parameters = getattr(component, "parameters", None)
        
        if parameters is None:
            debug(
                "{} simulates {} but your observation vector doesn't "
                "include it as a component".format(
                    transform.model.plugin.name, mod_input
                )
            )
            continue
        
        # Skip tracers not in the obs space
        if not hasattr(parameters, trcr) or not getattr(
            getattr(parameters, trcr, None), "isobs", False
        ):
            debug(
                "{} simulates {} as a {} "
                "but your observation vector doesn't "
                "include it as a component".format(
                    transform.model.plugin.name, trcr, mod_input
                )
            )
            continue
        
        # Now fetch info from data structure to common structure
        param = getattr(parameters, trcr)
        ds = param.datastore["data"]

        # Get observations meta data for the sub-period
        mask = (
            (ds["date"] + pd.to_timedelta(ds["duration"], unit="h") > ddi)
            & (ds["date"] < ddf)
        )
        y0 = ds.loc[mask]
        
        datastore[tracer_id] = {"tracer": param,
                                "component": component,
                                "data": copy.copy(y0)}
        
        # Fetching values from increments and forward if needed later
        datastore[tracer_id]["data"].loc[:, "obs_incr"] = \
            obsvect.dy[param.ypointer: param.ypointer + param.dim][mask]
        datastore[tracer_id]["data"].loc[:, "sim"] = \
            obsvect.ysim[param.ypointer: param.ypointer + param.dim][mask]
        datastore[tracer_id]["data"].loc[:, "sim_tl"] = 0.
        


