#####################
Observation operators
#####################

.. toctree::
    :maxdepth: 3

    standard







