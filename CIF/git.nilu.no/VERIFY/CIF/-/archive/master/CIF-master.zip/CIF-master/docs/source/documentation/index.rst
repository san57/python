#############
Documentation
#############

Details on the different components of the CIF can be found below:

.. toctree::
    :maxdepth: 2

    monitor
    pandas
    paths
    plugins/index
