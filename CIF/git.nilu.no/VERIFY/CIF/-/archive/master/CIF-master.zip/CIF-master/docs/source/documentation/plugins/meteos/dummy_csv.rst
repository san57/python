#####################
Gaussian Plume Model
#####################

.. automodule:: pycif.plugins.meteos.dummy_csv