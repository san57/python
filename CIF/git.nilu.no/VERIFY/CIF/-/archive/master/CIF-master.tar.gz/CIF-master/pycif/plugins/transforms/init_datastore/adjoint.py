

def adjoint(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    """Translates real-size data as extracted from the model outputs to
     the control space. This includes mainly temporal and spatial aggregation.
     This routine is used in adjoint mode, thus computes operations on
     increments.

     Args:
         self (Plugin): the control vect
         datastore (dict): the data at the model resolution to be converted
                           to the control space
         di (datetime): starting date of the simulation window
         df (datetime): ending date of the simulation window
         workdir (str): pycif working directory

     """

    ddi = min(di, df)

    if pipe == {}:
        xout = transform.from_dict({})
        xout.datastore = {}
        xmod = {}

    else:
        xout = pipe
        xmod = pipe.datastore

    # Basic objects
    tracer_ids = mapper["outputs"]

    for trid in tracer_ids:
        tracer = tracer_ids[trid]

        comp = trid[0]
        trcr = trid[1]

        force_read = tracer.get("force_read", False)

        component = transform.orig_component_plg
        tracer = transform.orig_parameter_plg

        # Saving reference directories if specified
        xmod[trid] = {"tracer": tracer}
        xmod[trid]["fileorig"] = getattr(tracer, "file", None)
        xmod[trid]["dirorig"] = getattr(tracer, "dir", None)
        xmod[trid]["varname"] = getattr(tracer, "varname", None)

        xout.datastore = xmod
        