#####################
M1QN3
#####################

.. automodule:: pycif.plugins.minimizers.m1qn3
