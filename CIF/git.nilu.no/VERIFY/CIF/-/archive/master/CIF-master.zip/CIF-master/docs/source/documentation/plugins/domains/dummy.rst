#####################
Gaussian Plume Model
#####################

.. automodule:: pycif.plugins.domains.dummy