from .utils import add_default
from pycif.utils.classes.transforms import Transform


def init_after(self,
               obsvect,
               all_inputs, all_outputs,
               backup_comps, mapper):
    
    # Initializes the overall transform pipe
    if not hasattr(obsvect, "transform_pipe"):
        obsvect.transform_pipe = Transform.from_dict({})

    all_transforms = self.transform_pipe
    transforms = obsvect.transform_pipe
    transfs_ids = getattr(transforms, "attributes", [])

    components = obsvect.datavect.components
    comps = components.attributes
    
    obs_mapper = obsvect.ini_mapper(obsvect)
    model_outputs_keys = list(all_outputs.keys())
    all_outputs.update(obs_mapper["outputs"])
    
    # Loops backwards on available transformations and update inputs/outputs
    # According to model outputs
    itransf = len(transfs_ids)
    ntransf_before = len(all_transforms.attributes)
    while itransf > 0:
        itransf -= 1
        ntransf_loc = 0
        transform = "{}_after".format(transfs_ids[itransf])

        # Initializes mapper if not already done
        if transform not in mapper:
            # Replacing the transform by a transform class
            # if not already initialized
            transf = getattr(transforms, transfs_ids[itransf])
            if transf is None:
                transf = Transform.from_dict({}, orig_name=transform)
            
            setattr(all_transforms, transform, transf)
            all_transforms.attributes.insert(ntransf_before + itransf, transform)

            # Updating the general mapper, and creates a local one
            transf_mapper = transf.ini_mapper(
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )
            transf.mapper = transf_mapper
            mapper[transform] = transf_mapper

            all_inputs.update(transf_mapper["inputs"])
            all_outputs.update(transf_mapper["outputs"])

        else:
            transf_mapper = mapper[transform]

        for trid in transf_mapper["inputs"]:
            if transf_mapper["inputs"][trid].get("force_dump", False):
                # Adding a dump transformation before the present transform
                yml_dict = {
                    "plugin": {
                        "name": "dump2inputs",
                        "version": "std",
                        "type": "transform",
                    },
                    "component": [trid[0]],
                    "parameter": [trid[1]],
                }
                add_default(
                    all_transforms,
                    yml_dict,
                    position="index",
                    index=ntransf_before + itransf,
                    mapper=mapper,
                    init=True,
                    inputs=all_inputs,
                    outputs=all_outputs,
                    backup_comps=backup_comps,
                )
                ntransf_loc += 1
                itransf += 1
                continue
                
    # Add default transformations prior to other transforms
    itransf = ntransf_before
    
    for trid in all_outputs:
        prm = trid[1]
        cmp = trid[0]
    
        cmp_in = cmp if cmp in comps else backup_comps.get(cmp, None)
        if cmp_in is None:
            continue
    
        cmp_plg = getattr(components, cmp_in)
    
        # Fetch parameters
        # If no parameters, handle the component as a whole
        if not hasattr(cmp_plg, "parameters"):
            params = cmp_plg
            parameters = [""]
        else:
            params = cmp_plg.parameters
            parameters = params.attributes[:]
    
        param = getattr(params, prm, cmp_plg)
        
        if param.isobs:
            # Default satellite transformation
            if cmp == "satellites":
                yml_dict = {
                    "plugin": {
                        "name": "satellites",
                        "version": "std",
                        "type": "transform",
                    },
                    "component": [cmp],
                    "parameter": [prm],
                    "orig_parameter_plg": param,
                    "orig_component_plg": cmp_plg,
                    "formula": getattr(param, "formula"),
                    "pressure": getattr(param, "pressure", "Pa"),
                    "product": getattr(param, "product", "level"),
                    "cropstrato": getattr(param, "cropstrato", False),
                    "chosenlev": getattr(param, "chosenlev", 0),
                    "extend_surf": getattr(param, "extend_surf", False),
                    "nchunk": getattr(param, "nchunk", 10),
                    "dir_satellites": getattr(param, "orig_dir"),
                    "correct_pthick": getattr(param, "correct_pthick", False)
                }
                add_default(
                    all_transforms,
                    yml_dict,
                    position="index",
                    index=itransf,
                    mapper=mapper,
                    init=True,
                    inputs=all_inputs,
                    outputs=all_outputs,
                    backup_comps=backup_comps,
                )
                
            # Initializing the transformation chain for this parameter
            # Create a random name to identify the current transformation
            yml_dict = {
                "plugin": {
                    "name": "toobsvect",
                    "version": "std",
                    "type": "transform",
                    "newplg": True,
                },
                "component": [cmp],
                "parameter": [prm],
                "orig_parameter_plg": param,
                "orig_component_plg": cmp_plg,\
            }
            add_default(
                all_transforms,
                yml_dict,
                position="last",
                index=itransf,
                mapper=mapper,
                init=True,
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )

        # Initializing the transformation chain for this parameter
        # Create a random name to identify the current transformation
        yml_dict = {
            "plugin": {
                "name": "init_datastore",
                "version": "std",
                "type": "transform",
                "newplg": True,
            },
            "component": [cmp],
            "parameter": [prm],
            "orig_parameter_plg": param,
            "orig_component_plg": cmp_plg,
        }
        add_default(
            all_transforms,
            yml_dict,
            position="last",
            index=itransf,
            mapper=mapper,
            init=True,
            inputs=all_inputs,
            outputs=all_outputs,
            backup_comps=backup_comps,
        )
