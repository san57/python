import xarray as xr
import numpy as np
from netCDF4 import Dataset


def read(
    self,
    name,
    tracdir,
    tracfile,
    varnames,
    dates,
    interpol_flx=False,
    comp_type=None,
    model=None,
    **kwargs
):
    """Get fluxes from pre-computed fluxes and load them into a pyCIF
    variables

    Args:
        self: the fluxes Plugin
        name: the name of the component
        tracdir, tracfile: flux directory and file format
        dates: list of dates to extract
        interpol_flx (bool): if True, interpolates fluxes at time t from
        values of surrounding available files

    """
    list_file_prodloss = [dd.strftime(tracfile) for dd in dates]
    trcr_prodloss = []
    for dd, file_prodloss in zip(dates, list_file_prodloss):
        ds = xr.open_dataset("{}/{}".format(tracdir, file_prodloss), decode_times=True)

        data = ds['{}_prod'.format(name)].values

        # Loops zonally for consistency with other call to gridded values
        data = np.append(data, data[..., np.newaxis, 0], axis=3)

        # Searching for the right day
        day = dd.day
        ds_days = ds["time_counter.day"]
        if day in ds_days:
            data = data[day - 1]
        else:
            data = data[0]

        trcr_prodloss.append(data)

    xmod = xr.DataArray(
        np.array(trcr_prodloss),
        coords={"time": dates},
        dims=("time", "lev", "lat", "lon")
    )

    return xmod
