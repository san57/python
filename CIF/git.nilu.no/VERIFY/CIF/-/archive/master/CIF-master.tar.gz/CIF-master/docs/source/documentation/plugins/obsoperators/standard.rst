#####################
Standard
#####################

.. automodule:: pycif.plugins.obsoperators.standard