####################
Control vectors
####################

.. role:: bash(code)
   :language: bash


Available Control vectors
=========================

The following :bash:`controlvects` are implemented in pyCIF:

.. toctree::

    standard

