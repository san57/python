def write(self, name, flx_file, flx, mode="a"):
    raise Exception("Can't write EDGAR fluxes so far")
