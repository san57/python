import shutil
import sys

from logging import info
from pycif.utils.path import init_dir, link
from .make_chemistry import create_chemicalscheme
from .read_chemistry import read_chemicalscheme

_name = "TM5"
_version = "SINK-TIPP"

input_arguments = {
    "dir_tipp": {
        "doc": "Path to kinetics files",
        "accepted": str
    },
}


def ini_data(self, **kwargs):
    """Initializes the chemistry depending on the model used
    for the inversion.

    Args:
        plugin (ChemistryPlugin): chemistry definition

    Returns:
        Updates on the fly the chemistry
    """

    info("Initializing the Chemistry")

    # Copying the chemical scheme to the working directory
    workdir = self.workdir
    self.dirchem_ref = "{}/chemical_scheme/".format(workdir)

    shutil.rmtree(self.dirchem_ref, ignore_errors=True)
    init_dir(self.dirchem_ref)
    
    # Copy files
    try:
        link(self.dir_tipp, "{}/TIPP".format(self.dirchem_ref))
        link(self.dir_sink, "{}/SINKS".format(self.dirchem_ref))

    # Otherwise, initialize files from the yaml
    except IOError:
        info("Could not find Kinetics files for TM5. Terminating.")
        raise
