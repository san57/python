def write():
    raise Exception("I don't know yet how to write FLEXPART flux files")
