import os

from .ini_periods import ini_periods
from .run import run
from .ini_mapper import ini_mapper
from .io.native2inputs import native2inputs
from .io.native2inputs_adj import native2inputs_adj
from .io.outputs2native import outputs2native
from .io.outputs2native_adj import outputs2native_adj
from .utils.flexpart_header import read_header

_name = "FLEXPART"

requirements = {'domain': {'name': 'FLEXPART', 'version': 'std',
                           'empty': False, 'any': False},
                'fluxes': {'name': 'FLEXPART', 'version': 'nc',
                           'empty': True, 'any': False}}

# Required inputs for running a FLEXPART simulation
required_inputs = ['fluxes']

default_values = {
    "read_background": False,
    "periods": "1MS"
}


def ini_data(plugin, **kwargs):
    """Initializes FLEXPART

    Args:
        plugin (dict): dictionary defining the plugin
        **kwargs (dictionary): possible extra parameters

    Returns:
        loaded plugin and directory with executable

    """

    # Update required inputs if reading background
    if plugin.read_background:
        plugin.required_inputs.append("inicond")

    # Read header for vertical resolution
    fp_header_nest = read_header(
        os.path.join(plugin.run_dir_nest,
                     plugin.outheight_header))
    plugin.domain.heights = \
        fp_header_nest.outheight[fp_header_nest.outheight > 0]
    plugin.domain.nlev = len(plugin.domain.heights)

    return plugin

