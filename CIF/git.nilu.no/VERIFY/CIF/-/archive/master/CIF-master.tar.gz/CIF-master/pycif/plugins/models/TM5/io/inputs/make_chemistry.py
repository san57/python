import filecmp
import os
import shutil

import numpy as np
from netCDF4 import Dataset

from pycif.utils import path
from logging import debug


def make_chemistry(self, data, runsubdir, mode, datei, datef):
    """Initialize chemitry files properly here"""

    debug("Initializing empty chemical files here")