import copy
import os
import glob
import re
import pandas as pd
import numpy as np
import pickle
from logging import info
from pycif.utils.datastores.dump import read_datastore
from .basefunctions import compute_sample
from .build_H import build_Hx


def execute(self, **kwargs):
    """Performs an analytical inversions, including computation of base
    functions"""
    
    # Working directory
    workdir = self.workdir

    # Control vector
    controlvect = self.controlvect
    xb_ref = copy.deepcopy(controlvect.xb)

    # Observation operator
    obsoper = self.obsoperator
    
    # Observation vector
    obsvect = self.obsvect

    # Simulation window
    datei = self.datei
    datef = self.datef

    # Some verbose
    towrite = """
        Running an Ensemble Kalman Filter with the following modules:
            Observation operator: {}
            Model: {}
        """.format(
        obsoper.plugin.name, obsoper.model.plugin.name
    )
    info(towrite)
    
    # Load Hx
    ensemble_dir = "{}/ensemble/".format(workdir)
    sample_file = os.path.join(ensemble_dir, "x_sample.pickle")
    hx_file = os.path.join(ensemble_dir, "Hx.pickle")
    nsample = self.nsample
    try:
        with open(sample_file, "rb") as f:
            x_sample = pickle.load(f)

        with open(hx_file, "rb") as f:
            hx_array = pickle.load(f)

    except IOError:
        # Build ensemble
        bfull = controlvect.build_b(controlvect)
        x_sample = np.random.multivariate_normal(
            controlvect.xb, bfull,
            size=nsample)
        x_sample = np.append(x_sample, np.ones((1, controlvect.dim)), axis=0)
        compute_sample(self, controlvect, x_sample)

        # Save corresponding samples
        with open(sample_file, "wb") as f:
            pickle.dump(x_sample, f, pickle.HIGHEST_PROTOCOL)

        # Build Hx matrix
        hx_array = build_Hx(obsvect, ensemble_dir, x_sample)

    # Solve operations
    controlvect.xb[:] = xb_ref[:]
    hxb = hx_array[:, -1]
    hx_array = hx_array[:, :nsample]
    x_sample = x_sample[:nsample]

    dy = obsvect.yobs - hxb
    rfull = obsvect.build_r(obsvect)

    hbh = hx_array.dot(hx_array.T) / (nsample - 1)
    bh = x_sample.T.dot(hx_array.T) / (nsample - 1)
    srm = np.linalg.inv(rfull + hbh)
    kmatrix = bh.dot(srm)

    xa = controlvect.xb + kmatrix.dot(dy)

    # Dump control vector
    controlvect.x = xa

    dir_control = "{}/controlvect/".format(workdir)
    file_xa = "{}/controlvect_post.pickle".format(dir_control)
    controlvect.dump(file_xa, to_netcdf=True, dir_netcdf=dir_control)
    
    # Saving posterior simulations
    controlvect.xb[:] = xa[:]

    obsvect = obsoper.obsoper(
        controlvect,
        obsvect,
        "fwd",
        datei=datei,
        datef=datef,
        workdir=workdir,
        reload_results=self.reload_results,
        run_id=nsample,
        **kwargs
    )
    
    dir_dump = "{}/obsvect/".format(workdir)
    obsvect.dump(dir_dump)
