import datetime
import glob
import os

import numpy as np
import pandas as pd
import xarray as xr

from netCDF4 import Dataset

from logging import info
from pycif.utils.datastores.empty import init_empty


def outputs2native(
        self, data2dump, input_type, di, df, runsubdir, mode="fwd", dump=True,
        onlyinit=False
):
    """Read concentrations as simulated by TM5 at observation points"""

    ddi = min(di, df)

    if not hasattr(self, "dataobs"):
        self.dataobs = {spec: init_empty()
                        for spec in self.chemistry.acspecies.attributes}
    
    # If no data to extract, pass
    if data2dump.datastore == {}:
        return data2dump
    
    # If species to extract are empty, pass
    extract = len([trid for trid in data2dump.datastore
                   if len(self.dataobs.get(trid[1], {})) > 0]) > 0
    if not extract:
        return data2dump

    # Here simulations should be read
    # Filling random values so far
    self.dataobs["CH4"].loc[:, "sim"] =  0.5 * self.dataobs["CH4"].loc[:, "obs"]

    data2dump.datastore[("concs", "CH4")]["data"] = self.dataobs["CH4"]
    return data2dump

    # Below is for example


    # If no simulated concentration is available just pass
    sim_file = "{}/mod.txt".format(runsubdir)
    if os.stat(sim_file).st_size == 0:
        info(
            "TM5 ran without any observation "
            "to be compared with for sub-simu "
            "only TM5's outputs are available"
        )
        
        # Filling simulations with NaNa
        for trid in data2dump.datastore:
            self.dataobs[trid[1]].loc[:, "sim"] = np.nan
        
        return

    # Read simulated concentrations
    # Adapt here to read TM5 output
    # To start with, only "spec", "sim" and "simfwd" are needed
    # "spec" corresponds to the tracer name,
    # "simfwd" is the simulated forward,
    # "sim" is the same as "simfwd" in forward mode,
    # the increment in tangent-linear mode

    # For satellites, other parameters are needed:
    # - the pressure at the middle of layers ("pmid")
    # - the thickness in pressure ("dp")
    # - the number of molecules per cm3 ("airm")
    # - the height in meters of the layer ("hlay")
    # - the forward simulation
    data = pd.read_csv(
        sim_file,
        delim_whitespace=True,
        header=None,
        usecols=range(5, 12),
        names=["spec", "sim", "pmid", "dp", "airm", "hlay", "simfwd"],
    )
    
    # Loop over species
    avail_species = data["spec"].unique()
    for trid in data2dump.datastore:
        spec = trid[1]
        if spec not in avail_species:
            continue
        
        dataloc = self.dataobs[spec]
    
        # Loop over observations in active species
        mask = data["spec"].str.lower() == spec.lower()
    
        # Putting values to the local data store
        # Assumes arithmetic averages upto now
        # Here, one only needs to do the sum of the values,
        # the division by the number of time steps is done outside the mode
        # to deal with observations overlapping different simulation windows
        inds = [0] + list(np.cumsum(dataloc.loc[:, "dtstep"][:-1]))
        avg_inds = pd.Series(np.nan, index=np.arange(len(data)))
        avg_inds.loc[inds] = np.arange(len(dataloc))
        avg_inds = avg_inds.ffill()

        data = data.loc[mask, ["sim", "pmid", "dp", "airm", "hlay", "simfwd"]]
        dataavg = data.groupby(avg_inds).sum()

        column = "sim" if mode == "fwd" else "sim_tl"

        dataloc.loc[:, column] = dataavg.loc[:, "sim"].values
        dataloc.loc[:, "pressure"] = dataavg.loc[:, "pmid"].values
        dataloc.loc[:, "dp"] = dataavg.loc[:, "dp"].values
        dataloc.loc[:, "airm"] = dataavg.loc[:, "airm"].values
        dataloc.loc[:, "hlay"] = dataavg.loc[:, "hlay"].values
    
        if column == "sim_tl":
            dataloc.loc[:, "sim"] = dataavg.loc[:, "simfwd"].values

        data2dump.datastore[("concs", spec)]["data"] = dataloc

    return data2dump
