########
Overview
########

.. contents:: Contents
    :local:

.. include:: context.rst
.. include:: theory.rst
.. include:: implementation.rst

