import pandas as pd
import datetime
import os
import glob
from netCDF4 import Dataset
import xarray as xr
import numpy as np


def native2inputs_adj(
    self, datastore, input_type, datei, datef, runsubdir, mode="fwd",
    **kwargs
):
    """Read sensitivity to input and converts them to pyCIF data

    Args:
        self: the model Plugin
        input_type (str): one of 'fluxes'
        datastore: data to convert
            if input_type == 'fluxes',
        datei, datef: date interval of the sub-simulation
        mode (str): running mode: one of 'fwd', 'adj' and 'tl'
        runsubdir (str): sub-directory for the current simulation
        workdir (str): the directory of the whole pyCIF simulation

    Notes:
        - CHIMERE expects hourly inputs;

    """
    
    if datastore == {}:
        return datastore
    
    ddi = min(datei, datef)
    
    # List of TM5 dates
    dref = datetime.datetime.strptime(
        os.path.basename(os.path.normpath(runsubdir)), "%Y-%m-%d_%H-%M"
    )
    list_dates = self.input_dates[ddi]

    # Reading only output files related to given input_type
    ref_names = {
        "inicond": "corresponding file name",
        "fluxes": "corresponding file name",
    }

    # If looking for sensitivity to input not provided by TM5, do nothing
    if input_type not in ref_names:
        return datastore

    # Otherwise, loop over component/parameters in the datastore
    for trid in datastore:
            # Here you need to read the correspondig sensitivity
            # for that tracer and input_type
            ndate = 1
            nvert = 1
            nmerid = 1
            nzonal = 1
            data = np.zeros((ndate, nvert, nmerid, nzonal))

            # Then you put in "adj_out" as a xr.DataArray
            datastore[trid]["adj_out"] = xr.DataArray(
                data,
                coords={"time": list_dates},
                dims=("time", "lev", "lat", "lon"),
            )

    return datastore
