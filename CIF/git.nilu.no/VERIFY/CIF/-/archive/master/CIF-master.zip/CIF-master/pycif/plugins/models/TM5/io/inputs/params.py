def make_config(self, runsubdir, sdc, mode):
    """
    PURPOSE
    Write a configuration file for running TM5. This file will have the
    name 'tm5.rc' and is therefore also called an rc-file. This function
    is imported/called in native2inputs.py.

    IN/OUT
    runsubdir = The directory in which TM5 is run. Probably depends on iteration
                number and date.
    sdc       = No idea. Is set in native2inputs as
                   ddi = min(datei, datef)
                   sdc = ddi.strftime("%Y%m%d%H")
                so it is probably the formatted start date of the current
                iteration.
    mode      = in native2inputs this is described as
                "running mode: one of 'fwd', 'adj' and 'tl'". I'm not sure what
                'tl' stands for.

    KWARGS
    none

    ASSUMPTIONS
    none

    EXCEPTIONS
    When this function encounters a problem that it cannot solve,
    it will raise a RuntimeError. Pythons exeception handling will
    provide a traceback, including files, calls and line numbers.

    PYTHON VERSION
    3.7.6

    VERSION CHANGE HISTORY
    1.0 09-11-2020 by J.C.A. van Peet.
        Original code.
    """

    # Set the name of this function
    PROG_NAME = "params.py, make_config(...)"


    # Write config file
    # Note: in the Chimere variant of this subroutine, rc_file_id.write(...) is
    #       used instead of print(...). The function write(...) doesn't add line
    #       endings automatically, while print(...) does. So if you use
    #       write(...), you'll have to add "\n" to each print statement. On the
    #       other hand, when using print, you'll have to add the "file=..."
    #       argument to each function call. Besides, if you want to run this on
    #       Windows, you'd have to change all the line endings from "\n" to
    #       "\r\n" or something linke that. I assume that print does that
    #       automatically, but you can easily add the end keyword to
    #       print_kwds yourself.
    with open("{}/tm5.rc".format(runsubdir), "w") as rc_file_id:
        print_kwds = {"file":rc_file_id, "sep":""}
        print("! Lines starting with an exclamation mark will be ignored"        , **print_kwds)
        print("runsubdir        : "+runsubdir                                    , **print_kwds)
        print("sdc              : "+sdc                                          , **print_kwds)
        print("mode             : "+mode                                         , **print_kwds)
        print("path_to_input    : /home/jpt930/werk/verify/cif/tm5_simple/input/", **print_kwds)
        print("emission_file    : emission-20170701_20190701-glb600x400.nc4"     , **print_kwds)
        print("iniconc_file     : iniconc-20180101-tropo25_ec60_glb600x400.nc4"  , **print_kwds)
        print("point_input_file : point_input-20170701_20200428.nc"              , **print_kwds)
    # end with

    #return

# end function make_config
