import numpy as np
import datetime
import os
import pandas as pd

from logging import info

from ..utils.flexpart_header import read_header
from .inputs.fluxes import flux_contribution
from .inputs.inicond import inicond_contribution


def outputs2native(self, data2dump, input_type,
                   di, df, runsubdir, mode='fwd', **kwargs):
    """Reads outputs to pycif objects.
       
       Does nothing for now as we instead read FLEXPART output 
       inside loop over observations in obsoper.py 

    """
    
    ddi = min(di, df)

    dataobs = list(self.dataobs.values())[0]
    nobs = len(dataobs)
    subdir = ddi.strftime("%Y%m")
    
    # Initialize header
    fp_header_glob = read_header(
        os.path.join(self.run_dir_glob,
                     dataobs.head(1)['station'][0].upper(),
                     subdir, 'header'))
    
    fp_header_nest = None
    if self.nested:
        fp_header_nest = read_header(
            os.path.join(self.run_dir_nest,
                         dataobs.head(1)['station'][0].upper(),
                         subdir, 'header_nest'))
    
    fp_header_init = None
    if self.read_background:
        fp_header_init = read_header(
            os.path.join(self.run_dir_bg,
                         dataobs.head(1)['station'][0].upper(),
                         subdir, 'header'))
    
    # Nest domain definition
    ix1 = self.domain.ix1
    ix2 = self.domain.ix2
    iy1 = self.domain.iy1
    iy2 = self.domain.iy2
    
    # Save to datastore for debugging purposes
    obs_ghg = np.nan * np.empty(nobs)
    obs_bkg = np.nan * np.empty(nobs)
    obs_sim = np.nan * np.empty(nobs)
    obs_model = np.nan * np.empty(nobs)
    obs_check = np.nan * np.empty(nobs)
    obs_bkgerr = np.nan * np.empty(nobs)
    obs_err = np.nan * np.empty(nobs)
    
    info("di, df: {}, {}, {}".format(di, df, datetime.datetime.now()))

    # Apply fluxes contribution
    flux_contribution(self, mode, subdir, dataobs,
                          fp_header_nest, fp_header_glob)

    # Apply sensitivity to background if required
    if self.read_background:
        inicond_contribution(self, mode, subdir, dataobs, fp_header_init)

    # Update data2dump
    spec = list(data2dump.datastore.keys())[0]
    data2dump.datastore[spec]["data"] = dataobs

    return data2dump

