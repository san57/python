from netCDF4 import Dataset
from pycif.utils.datastores import dump
from pycif.utils.netcdf import readnc
from pycif.utils.datastores import empty
from pycif.utils.datastores.dump import dump_datastore
import calendar
import os
import pandas as pd
import datetime
import numpy as np
import xarray as xr

##### previously formatted monitor file to read
filein = 'oldshaped_monitor.nc'
dataread = xr.open_dataset(filein)
dataold = dataread.to_dataframe()
# date = previously the index, now a column
dataold['date']=dataold.index.values 
# example of forcing values for testing purposes
yy = dataold['date'][0].year
mm = dataold['date'][0].month
dd = dataold['date'][0].day
for i in range(len(dataold)):
  dataold['date'][i] = datetime.datetime(year= yy, month= mm , day= dd , hour = i )
# end forcing values
dataold.reset_index(inplace=True)

###### data to dump
# list of infos required for in-situ, including level (either by choice of the user or because the automatic placing is not enabled)
list_basic_cols = [ 'date', 'duration', 'station' , 'network', 'parameter', 'lon', 'lat', 'alt', 'obs', 'obserror', 'level' ]
datadump = dataold[list_basic_cols]
# assigning the level (here, the same for all data)
datadump = datadump.assign(level = 2)

##### dump in netcdf file for use by the CIF
datadump = datadump.to_xarray()
datadump.to_netcdf('monitor_lastformat.nc')

