from .execute import execute

_name = "adj-tl_test"

requirements = {
    "obsvect": {
        "any": True,
        "empty": False,
        "name": "standard",
        "version": "std",
    },
    "controlvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "obsoperator": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
}

input_arguments = {
    "incrmode": {
        "doc": "Type of increments to use in the test.",
        "default": "cst",
        "accepted": {
            "cst": "Increments are the same for all dimensions "
                   "of the control vector",
            "rand": "Increments are selected randomly with a Normal "
                    "distribution centered to zero "
                    "with standard deviation ${increments}"
        }
    },

    "increments": {
        "doc": "Scale of the increments to do the test. "
               "The following equation is used: "
               ":math:`\delta x = \delta i \;.\; \sigma_\mathbf{x}`",
        "default": 0.0,
        "accepted": float
    },

    "testspace": {
        "doc": "Reference space to apply the test of the adjoint",
        "default": "control",
        "accepted": {
            "control": "The test is applied in the control space",
            "chi": "The test is applied is the reduction :math:`\chi` space; "
                   "this includes multiplication by the square root of the "
                   "matrix :math:`\mathbf{B}`; it is recommended "
                   "to do this test before an inversio using error correlations"
        }
    },

    "reload_results": {
        "doc": "Reload results from previously compiled test. "
               "If True does not recomputed the tangent-linear and/or the adjoint",
        "default": False,
        "accepted": bool
    },

    "random_seed": {
        "doc": "Seed to use in the test of the adjoint "
               "for generating random numbers; used only with incrmode = rand",
        "default": 0,
        "accepted": int
    },


}



