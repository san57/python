######################
Satellite observations
######################

.. automodule:: pycif.plugins.transforms.satellites