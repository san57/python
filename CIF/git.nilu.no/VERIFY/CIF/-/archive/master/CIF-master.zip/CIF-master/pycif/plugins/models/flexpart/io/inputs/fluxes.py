import os
from logging import debug
import numpy as np
import pandas as pd

from .read import read_flexpart_grid


def flux_contribution(self, mode, subdir, dataobs,
                      fp_header_nest, fp_header_glob):
    for obs_i, row in enumerate(dataobs.itertuples()):
        row = dataobs.iloc[obs_i]
        station = row.station

        fluxes = {"sim": list(self.dataflx.values())[0]["spec"]}
        if mode == "tl" and "incr" in list(self.dataflx.values())[0]:
            fluxes["sim_tl"] = list(self.dataflx.values())[0]["incr"]

        # Read nested grids
        runsubdir_nest = os.path.join(
            self.run_dir_nest, station.upper(), subdir)
        file_date = row.date.strftime('%Y%m%d%H%M%S')
        file_name = 'grid_time_nest_{}_001'.format(file_date)

        debug("Reading {} for station {}".format(file_name, station))

        if not os.path.isfile(os.path.join(runsubdir_nest, file_name)):
            return

        grid_nest, gtime, ngrid = read_flexpart_grid(
            runsubdir_nest, file_name, fp_header_nest,
            numscale=self.numscale)

        # Conversion of footprints
        grid_nest *= self.coeff * self.mmair / self.molarmass

        # Multiply footprints with fluxes for fwd and tl
        for data_id in fluxes:
            dataflx = fluxes[data_id]
            flx_dates = pd.DatetimeIndex(
                dataflx.time.values).to_pydatetime()

            inds_flx = \
                np.argmin(np.abs(np.array(gtime)[:, np.newaxis]
                                 - flx_dates[np.newaxis, :]), axis=1)
            nest_sim = (
                    grid_nest.T[:ngrid].reshape(ngrid, -1)
                    * dataflx[inds_flx, 0, :self.domain.zlon_in.size, 0]) \
                .sum()

            # Filling simulation
            sim_col = dataobs.columns.get_indexer([data_id])
            dataobs.iloc[obs_i, sim_col] = nest_sim

        # Read global footprints
        # TODO: read correction factor dry air!
        runsubdir_glob = os.path.join(
            self.run_dir_glob, station.upper(), subdir)
        file_name = 'grid_time_{}_001'.format(file_date)

        if not os.path.isfile(os.path.join(runsubdir_glob, file_name)):
            return

        grid_glob, gtime_glob, ngrid_glob = \
            read_flexpart_grid(
                runsubdir_glob, file_name, fp_header_glob,
                numscale=self.numscale)

        # Conversion of footprints
        grid_glob *= self.coeff * self.mmair / self.molarmass

        # Multiply footprints with fluxes for fwd and tl
        for data_id in fluxes:
            dataflx = fluxes[data_id]
            flx_dates = pd.DatetimeIndex(
                dataflx.time.values).to_pydatetime()

            inds_flx_glob = \
                np.argmin(np.abs(np.array(gtime_glob)[:, np.newaxis]
                                 - flx_dates[np.newaxis, :]), axis=1)
            glob_sim = (
                    grid_glob.T[:ngrid_glob].reshape(ngrid_glob, -1)
                    * dataflx[inds_flx_glob, 0,
                      self.domain.zlon_in.size:, 0].values
            )
            glob_sim[:, self.domain.raveled_indexes_glob] = 0.
            glob_sim = glob_sim.sum()

            # Filling simulation
            sim_col = dataobs.columns.get_indexer([data_id])
            dataobs.iloc[obs_i, sim_col] += glob_sim
