##################################################################
First forward simulation with CHIMERE
##################################################################

.. role:: bash(code)
   :language: bash


Here we run a forward simulation of
:doc:`CHIMERE</documentation/plugins/models/chimere>` including the comparison to observation data.

Please note :doc:`here</documentation/paths>` some instructions about how pyCIF deals with paths.

1. Prepare the executable: in directory :bash:`model_sources/chimereGES`, compile the fortran chemistry-transport model:

.. code-block:: bash

    ./compile_chimere D 

Option `D` indicates that the forward code is compiled.

In case of a previous compilation,

.. code-block:: bash

    ./compile_chimere D N clean

ensures that the new compilation starts from scratch. Option `N` indicates that the compiling mode is NOT for debugging.

=> check that you obtain an executable in sub-directory :bash:`src` named :bash:`fwdchimere.e`, about 2.5M in size.

  .. 
    to modify to add the case of auto-compilation by the CIF

2. Locate the input files required by CHIMERE which are not yet processed by the CIF and must be pre-processed and provided in the format directly read by CHIMERE: 

    - the files defining the simulation domain COORDcorner_DOM, domainlist.nml
    - the METEO.nc file (requires COORD_DOM, VCOORD_NumberOfLevels_Psurf_Ptop, see XXXdoc CHIMEREXXX for more details)
    - the chemical scheme  in 12 text files: ACTIVE_SPECIES, ANTHROPIC, BIOGENIC, CHEMISTRY, DEPO_PARS, DEPO_SPEC, FAMILIES, OUTPUT_SPECIES, PHOTO_PARAMETERS, REACTION_RATES, STOICHIOMETRY, WETD_SPEC. These files are the same as the standard CHIMERE issue (see XXXdoc CHIMERE PYVARXXX for more details) but for:
         - ACTIVE_SPECIES: contains columns for the number of the species, its name, the number of the transport scheme on the horizontal (1 = PPM, 2 = Van Leer, other = up-wind), the number of the transport scheme on the vertical (1 = up-wind, 2 = Van Leer), the indicator for dry or humid boundary conditions (1 for dry BCs, which will then be converted into humid values for use by CHIMERE)
         - OUTPUT_SPECIES: contains columns for the name of the species and its conversion factor: < 0 = ppb as computed by CHIMERE, 0 = dry ppb (eg for comparison to surface in-situ measurements), > 0 = converting factor to use as such.
    - if deposition used in the chemical scheme, the file containing the land-use: LANDUSE_DOM

3. If the observations for comparison are not (yet) in a format recognized by the CIF (XX what are these formats???XX), prepare the :bash:`monitor.nc` files. All details are given in :doc:`the documentation for observations</documentation/monitor>`. Here, the case of satellite observations for one species is given as an example. XXX indiquer combien de monitor: un par espece et par type d'obs, segmentation dans le temps libre?XXX

4. Elaborate the yaml for the CIF:
   
   a. section for PyCIF parameters:

     .. code-block:: yaml

        #####################################################################
        #####################################################################
        # PYCIF parameters

        # Verbose level
        # 1 = Basic information
        # 2 = Debugging
        verbose : 1

        # Log file (to be saved in $wordkir)
        logfile: test_std

        # Execution directory
        workdir: /home/chimereicos/ipison/test_chimere_cif_n2o/

        # Initial date
        # Use the following compatible format for the date:
        # YYYY-mm-dd or YYYY-mm-dd HH:mm:ss
        datei : 2011-07-01 00:00:00

        # End date (same as for the initial date)
        datef : 2011-07-31 03:00:00
   

   b. :mode: 
      here, a forward simulation. The key-word for the class (:bash:`mode`), the name and version of the plugin can be found in the :doc:`cheat-sheet</documentation/plugins/dependencies>`. In the cheat-sheet, the link to the full description of the class (:doc:`mode</documentation/plugins/modes/index>`) gives access to arguments. For :bash:`mode`, there is no mandatory argument to specify but a few optional arguments can be used. In the example, :bash:`reload_results` is used so as not to have to recompute the whole simulation in case of an interruption.

      .. code-block:: yaml
        
        #####################################################################
        #####################################################################
        # Running mode for PYCIF
        mode:
          plugin:
            name: forward
            version: std
          reload_results: True

      The requirements for our forward mode are :bash:`obsoperator` (c) and :bash:`controlvect` (d). They are to be specified in the next sections (c and d XX see for links?) of the yaml file.


   c. :obsoperator: 
      CHIMERE works from the flux space to the concentration space, which corresponds to the standard choice. For :bash:`obsoperator`, there is no mandatory argument to specify but a few optional arguments can be used. In the example, :bash:`autorestart` is used.

      .. code-block:: yaml

        #####################################################################
        #####################################################################
        # Observation operator
        # Used to run the model and translates information from model/measurement
        # spaces to control/observation spaces
        obsoperator:
          plugin:
            name: standard
            version: std
          autorestart: True 

      The requirements for our standard obsperator are :bash:`controlvect` (d), :bash:`model` (e), :bash:`obsvect` (f) and :bash:`platform` (g).

   d. :controlvect: 
      so far, there is only one possibility for :bash:`controlvect`.

      .. code-block:: yaml

        #####################################################################
        #####################################################################
        controlvect:
          plugin:
            name: standard
            version: std

      The requirements for the standard controlvect are :bash:`domain` (h), :bash:`model` (e), :bash:`obsvect` (f) and :bash:`datavect` (j), with its various :bash:`components`.

   e. :model: 
      here, it is CHIMERE. The usual user's choices for running a CHIMERE simulation are either in the mandatory arguments or in the optional arguments, for which defalut values are specified. Be sure to check all the mandatory AND OPTIONAL arguments to fully set up the simulation as wanted. It must be consistent with e.g. the chemistry (see setp 2 and i) and domain (see step 2 and h).

      .. code-block:: yaml

        #####################################################################
        #####################################################################
        # Transport model
        model :
          plugin:
            name    : CHIMERE
            version : std

          # Executable: the one compiled at step 1
          direxec: your_path_for_the_CIF/model_sources/chimereGES/ 
   
          #  Number of physical steps per hour
          nphour_ref : 6
       
          # Number of chemical refined iterations
          ichemstep : 2

          # Deep convection
          ideepconv: 0

          #  Number of vertical layers in output files
          nivout: 20

          # Number of levels for emissions
          nlevemis: 20

          # Force using processes
          usechemistry: 1
          usewetdepos: 1 
          usedepos: 1 

          nsavedepos: 24

          dryairout: 1 

          nitgs: 2

          useabsclipconc: 1
  
          # Number of MPI subdomains in zonal and meridian directions for // use
          nmdoms : 8
          nzdoms : 6

          write_for_adjoint: False #XXX A SUPPRIMER XXX

      The requirements for CHIMERE are :bash:`domain` (h), :bash:`chemistry` (i) and a set of components (corresponding to the inputs of CHIMERE itself) to be detailed in :bash:`datavect` (j): :bash:`fluxes` (I), :bash:`biofluxes` (II), :bash:`meteo` (III), :bash:`latcond` (IV), :bash:`topcond` (V), :bash:`inicond` (VI) 

   f. :obsvect: 
      so far, there is only one possibility for :bash:`obsvect`. As this is the first simulation, there is no previous file to be read but the file generated by this simulation is dumped to be used in later simulations.

      .. code-block:: yaml

        #####################################################################
        #####################################################################
        # Observation vector and observation uncertainties if needed
        # Also projects information from the observation to the model space
        obsvect:
          plugin:
            name: standard
            version: std
          dump: True

      The requirements for the standard obsvect are :bash:`model` (e) and :bash:`datavect` (j)

   g. :platform: 
      on which to run. Here the example is set at LSCE, on the obelix cluster. 
     
      .. code-block:: yaml

        #####################################################################
        #####################################################################
        platform:
          plugin:
            name: LSCE
            version: obelix

      The only requirement is the :bash:`model` (e). 

   h. :domain:
      for CHIMERE. Specify according to the :doc:`cheat-sheet</documentation/plugins/dependencies>`, consistently with the pre-computed input files (see step 2). The files defining the domain can be copied into the repgrid or links can be used.

      .. code-block:: yaml

        #####################################################################
        #####################################################################
        domain :
          plugin:
            name    : CHIMERE
            version : std
          repgrid: a_path_for_CHIMERE_COORD_definition_files/
          domid : MYDOMAIN
          nlev: 20
          p1: 997
          pmax: 200


   i. :chemistry:
      for CHIMERE, the only possibility so far is for photolysis with tabulated Js, the cehmical scheme being pre-computed (see step 2).

      .. code-block:: yaml

        #####################################################################
        #####################################################################
        chemistry :
          plugin:
            name: CHIMERE
            version: gasJtab
          schemeid: name.chemistry
          dir_precomp: the_path_for_the_directory_of_which_chemical_scheme_named_above_is_a_subdir/

   j. :datavect:
      so far, there is only the standard :bash:`datavect`. For the fisrt forward simulation with comparison to some observations, its components must include the dependencies listed in the :doc:`cheat-sheet</documentation/plugins/dependencies>` for the :bash:`model` (e) plugin, which are not already specified outside :bash:`datavect`: they are the items I to VI in (e). These components include the usual inputs required by CHIMERE: :bash:`meteo` (I) for the meteorological inputs (see step 2), :bash:`fluxes` (II) for emissons treated as "anthropogenic" emissions i.e. not interpolated within the 1-hour time steps in CHIMERE), 
XXXXXXXXXXx :bash:`biofluxes` (emissions treated as "biogenic" emissions i.e. linearly interpolated within the 1-hour time steps) if relevant i.e. if :bash:`optemisb` is True, :bash:`inicond`, :bash:`latcond` and :bash:`topcond` (initial, lateral and top conditions) and :bash:`concs` for the observations to be compared with the simulations. 

     I. The components are plugins, they therefore require a name and version to be specified. Here, according to the :doc:`cheat-sheet</documentation/plugins/dependencies>`, the yaml should read:

        .. code-block:: yaml
 
          #####################################################################
          #####################################################################
          datavect:
            plugin:
              name: standard
              version: std
            components:
              meteo:
                plugin:
                  name: CHIMERE
                  version: std
              [...]
              fluxes:
                plugin:
                  name: CHIMERE
                  version: AEMISSIONS

        Nevertheless, to avoid redundant information to be specified in all components, the :bash:`plugin` specification can be omitted: the CIF will then use the default plugins associated to the chosen model, as indicated by the plugin specifications of :bash:`datavect`. Here, for :bash:`meteo` and :bash:`fluxes`, if the CIF is to use the default plugins associated to CHIMERE, it will expect METEO.nc and AEMISSIONS.nc files. For the default plugins, see the :bash:`model` section of the cheat-sheet for the model to use: the default plugins are given for each required plugin. For example, for CHIMERE, the default plugin for :bash:`fluxes` and :bash:`biofluxes` is AEMISSIONS XXX description AEMISSION??XXX

        Since the CIF is so far able to use only standard pre-computed METEO.nc files, it is not necessary to explicitly state the plugin specifications. The meteo component then requires only the directory where the pre-computed METEO.nc files are available (see step 2) and, if necessary, the file name format, to be specified. The yaml then reads:

        .. code-block:: yaml

          #####################################################################
          #####################################################################
          datavect:
            plugin:
              name: standard
              version: std
            components:
              meteo:
                dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                # files must be named METEO.YYYYMMDDHH.hh.nc, see XX CHIMERE docXX for more details

        or

        .. code-block:: yaml

          #####################################################################
          #####################################################################
          datavect:
            plugin:
              name: standard
              version: std
            components:
              meteo:
                dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                file: METEO_some_etiket.%Y%M.nc
                # files formatted as classical METEO.nc but with names based on the template provided are used XXXCHECK formattage exactXXX

        If pre-computed files are also available for fluxes, biofluxes, inicond, latcond and topcond, they can be specified in the same way (see example in II for fluxes). 

        **Remark:** the pre-computed files must be consistent together and with the domain (h), the PyCIF parameters (a) of the simulation and the choices made for the model (e), particularly with the optional argument :bash:`periods` (default 1D = 24 hours).



     II. The principle of default plugin specifications makes it possible to specify various sources of inputs for the different species. Here, these possibilities are illustrated for the species to be emitted as "anthropogenic" species. The same applies to the species in the biofluxes, initial, boundary and top conditions. 

           * AEMISSIONS.nc files pre-computed and to be used for all species: case explained in I. Plugin specifications are not required at the :bash:`fluxes` level since the CIF will use by default the plugin specifications provided at the :bash:`datavect` level and these are the standard ones for CHIMERE, which correspond to AEMISSIONS.nc files (see also I). Only the location of the files remains to be specified.

             .. code-block:: yaml
 
               #####################################################################
               #####################################################################
               datavect:
                 plugin:
                   name: standard
                   version: std
                 components:
                   meteo:
                     dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                     file: METEO_some_etiket.%Y%M.nc
                   fluxes:
                     dir: directory_containing_AEMISSIONS.YYYYMMDDHH.*.nc_files

           * several sets of AEMISSIONS.nc files e.g one set for all species required by the chemical scheme but one, this species to be taken fron another set. Plugin specifications are not required but it is necessary to indicate the location of the pre-computed files in which a particular :bash:`parameter` is to be read.XX CHECK THIS IS THE ACTUAL BEHAVIOR!!!XXX

             .. code-block:: yaml

              #####################################################################
              #####################################################################
              datavect:
                plugin:
                  name: standard
                  version: std
                components:
                  meteo:
                    dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                    file: METEO_some_etiket.%Y%M.nc
                  fluxes:
                    dir: directory_containing_AEMISSIONS.YYYYMMDDHH.*.nc_files
                    parameters:
                      S1:
                        dir: directory_containing_AEMISSIONS.YYYYMMDDHH.*.nc_files_for_S1

         The CIF can uses pre-computed files already formatted for reading by CHIMERE but it is also able to internally pre-process various types of files. In this case, it reads the known formats and applies a chosen set of transformations to obtain input netcdf files for CHIMERE such as AEMISSIONS.nc, INI_CONCS.nc, etc. The supported raw inputs are listed in XXX DOC QUI MANQUE?XXX. The users may simply add transformations as required for new inputs: XXX DOC + TUTOS SUR CA XXXX

           * a raw inventory to be read and processed into AEMISSIONS.nc files by the CIF for all species: plugin specifications are required at the level of the component, here :bash:`fluxes`. 

             .. code-block:: yaml

               #####################################################################
               #####################################################################
               datavect:
                 plugin:
                   name: standard
                   version: std
                 components:
                   meteo:
                     dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                     file: METEO_some_etiket.%Y%M.nc
                   fluxes:
                     plugin:
                       name: EDGAR
                       version: v5
                     


           * a raw inventory to be read and processed for all species but one, which is already pre-processed:


             .. code-block:: yaml

               #####################################################################
               #####################################################################
               datavect:
                 plugin:
                   name: standard
                   version: std
                 components:
                   meteo:
                     dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                     file: METEO_some_etiket.%Y%M.nc
                   fluxes:
                     plugin:
                       name: EDGAR
                       version: v5
                     dir: directory_containing_raw_v50.nc_EDGAR_files
                     parameter:
                       S1:
                         plugin:
                           name: CHIMERE
                           version: AEMISSIONS
                         dir: directory_containing_AEMISSIONS.YYYYMMDDHH.*.nc_files_for_S1


           * a raw inventory to be read and processed for all species but one, which comes from a different raw inventory:

             .. code-block:: yaml

               #####################################################################
               #####################################################################
               datavect:
                 plugin:
                   name: standard
                   version: std
                 components:
                   meteo:
                     dir: directory_containing_METEO.YYYYMMDDHH.*.nc_files
                     file: METEO_some_etiket.%Y%M.nc
                   fluxes:
                     plugin:
                       name: EDGAR
                       version: v5
                       dir: directory_containing_raw_v50.nc_EDGAR_files
                     parameter:
                       S1:
                         plugin:
                           name: INS
                           version: v2012
 
XXXXXXXXXXXXXXXXXXXXBelow is an example for boundary conditions processed from ECMWF grid files and for fluxes processed from the French INS (XXX files).

    III. The biofluxes  


