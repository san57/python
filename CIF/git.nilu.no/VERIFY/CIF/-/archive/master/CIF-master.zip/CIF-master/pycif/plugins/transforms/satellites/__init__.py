from .forward import forward
from .adjoint import adjoint

import os
import glob
from logging import info
from pycif.utils.path import init_dir, link

_name = "satellites"

requirements = {"model": {"any": True, "empty": False}}


def ini_mapper(
        transf, inputs={}, outputs={}, backup_comps={}
):
    """Initialize mapper for time cropping.
    Does not need to change the mapper as cropping time keep similar
    names and dimensions"""
    
    mapin = {(cmp, prm): outputs[(cmp, prm)]
             for cmp, prm in zip(transf.component, transf.parameter)}
    mapout = {("concs", prm): outputs[(cmp, prm)]
              for cmp, prm in zip(transf.component, transf.parameter)}
    mapper = {"inputs": mapin,
              "outputs": mapout}
    
    return mapper


def ini_data(transf):
    info("Link satellite files to the working directory")
    
    if not hasattr(transf, "dir_satellites"):
        raise AttributeError("Missing dir_satellites attributes "
                             "to initialize satellites")
    
    dir_sat = "{}/datavect/{}/{}/".format(
        transf.workdir,
        transf.component[0],
        transf.parameter[0])
    if not os.path.isdir(dir_sat):
        init_dir(dir_sat)
        
    for dd in transf.model.subsimu_dates[:-1]:
        sat_files = glob.glob(
            dd.strftime("{}/infos_*%Y%m%d%H%M.nc").format(
                transf.dir_satellites
            )
        )

        for obs_file in sat_files:
            target = os.path.join(dir_sat, os.path.basename(obs_file))
            link(obs_file, target)
