from .inputs.make_obs import make_obs


def outputs2native_adj(
        self, data2dump, input_type, di, df, runsubdir, mode="fwd",
        dump=True, onlyinit=False, do_simu=True, **kwargs
):
    """Reads outputs to pyCIF objects.

    If the mode is 'fwd' or 'tl', only observation-like outputs are extracted.
    For the 'adj' mode, all outputs relative to model sensitivity are extracted.

    Dumps to a NetCDF file with output concentrations if needed"""

    ddi = min(di, df)

    for trid in data2dump:
        mod_input = trid[0]
        trcr = trid[1]
        
        if mod_input != "concs":
            continue
        
        if "data" in data2dump[trid]:
            if onlyinit:
                make_obs(self, data2dump[trid]["data"],
                         runsubdir, "fwd", trcr, do_simu)
            else:
                make_obs(self, data2dump[trid]["data"],
                         runsubdir, "adj", trcr, do_simu)
