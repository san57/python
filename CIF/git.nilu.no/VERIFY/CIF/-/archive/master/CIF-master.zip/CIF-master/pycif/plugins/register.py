#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pkgutil
import os

from pycif.utils.classes.baseclass import Plugin

for plg_type in Plugin.plugin_types:
    # Load the class
    class_name = Plugin.plugin_types[plg_type][1]
    class_path = "pycif.utils.classes{}".format(Plugin.plugin_types[plg_type][0])
    class_module = pkgutil.importlib.import_module(class_path)
    local_class = getattr(class_module, class_name)

    # Loop over modules of this class
    local_package = "{}{}".format(locals()["__package__"],
                                  Plugin.plugin_types[plg_type][0])
    import_package = pkgutil.importlib.import_module(local_package)
    for mod in pkgutil.walk_packages(import_package.__path__,
                                     prefix=import_package.__name__ + "."):
        if not mod.ispkg:
            continue

        loc_mod = pkgutil.importlib.import_module(mod.name)

        # Register modules only when a name is given
        if not hasattr(loc_mod, "_name"):
            continue

        name = loc_mod._name
        version = getattr(loc_mod, "_version", "std")

        if not local_class.is_registered(name, version, plg_type):
            local_class.register_plugin(name, version, loc_mod,
                                        plugin_type=plg_type)
