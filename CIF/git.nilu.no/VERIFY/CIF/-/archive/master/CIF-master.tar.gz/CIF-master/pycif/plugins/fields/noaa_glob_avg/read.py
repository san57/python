import datetime
import os

import numpy as np
import xarray as xr
from netCDF4 import Dataset

from pycif.utils.netcdf import readnc


def read(
    self,
    name,
    tracdir,
    tracfile,
    varnames,
    dates,
    interpol_flx=False,
    comp_type=None,
    tracer=None,
    model=None,
    **kwargs
):
    """Get fluxes from pre-computed fluxes and load them into a pyCIF
    variables

    Args:
        self: the fluxes Plugin
        name: the name of the component
        tracdir, tracfile: flux directory and file format
        dates: list of dates to extract
        interpol_flx (bool): if True, interpolates fluxes at time t from
        values of surrounding available files

    """

    list_files = tracfile
    if type(tracfile) != list:
        list_files = [dd.strftime(tracfile) for dd in dates]

    data = []
    for dd, ff in zip(dates, list_files):
        tmp = readnc(os.path.join(tracdir, ff),
                     [self.varname_init])
        data.append(tmp[0])

    # Putting in DataArray
    xmod = xr.DataArray(
            data, coords={"time": dates}, dims=("time", "lev", "lat", "lon")
        )

    # Converting ppb to ppm for pycif
    xmod /= 1e3

    return xmod
