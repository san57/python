import glob
import os
from types import MethodType

import numpy as np

from pycif.plugins.obsvects.standard.utils.check_monitor import check_monitor
from pycif.utils import path
from .init_rinvprod import init_rinvprod
from .init_y0 import init_y0
from .rinvprod import rinvprod
from .ini_mapper import ini_mapper
from .utils.dump import dump
from .utils.read import read
from .build_full_r import build_r

_name = "standard"

# It is necessary to have some measurements and some info about the meteo
# to initialize the observation vector
requirements = {
    "model": {"any": True, "empty": False},
    "datavect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    }
}

input_arguments = {
    "dump": {
        "doc": "dump the control vector in a netcdf file",
        "default": "False",
        "accepted": bool
    },
    "dir_obsvect": {
        "doc": "contains the observation vector from a previous simulation",
        "default": "",
        "accepted": str
    },
}

default_obstypes = ["concs", "insitu", "flasks", "satellites"]


def ini_data(plugin, **kwargs):
    """Initializes the observation vector from information in the Yaml file

    Args:

    """

    # Set dump type if not defined; default is nc
    if not hasattr(plugin, "dump_type"):
        plugin.dump_type = "nc"

    # Set default file_obsvect
    file_default = "{}/obsvect/monitor.{}".format(
        plugin.workdir, plugin.dump_type
    )
    plugin.file_obsvect = getattr(plugin, "file_obsvect", file_default)

    # Keeping check_monitor as a class method
    plugin.check_monitor = MethodType(check_monitor, plugin)

    # Initializing y0
    init_y0(plugin, **kwargs)


