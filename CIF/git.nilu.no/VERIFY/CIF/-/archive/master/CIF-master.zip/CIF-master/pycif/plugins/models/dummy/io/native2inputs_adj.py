import numpy as np
import copy

from .inputs.fluxes import make_fluxes
from .inputs.meteo import make_meteo


def native2inputs_adj(
        self, datastore, input_type, datei, datef, runsubdir, mode="adj",
        onlyinit=False, do_simu=True,
        **kwargs
):
    """Converts data at the model data resolution to model compatible input
    files.

    Args:
        self: the model Plugin
        input_type (str): one of 'fluxes', 'obs'
        datastore: data to convert
            if input_type == 'fluxes', a dictionary with flux maps
            if input_type == 'obs', a pandas dataframe with the observations
        datei, datef: date interval of the sub-simulation
        mode (str): running mode: one of 'fwd', 'adj' and 'tl'
        runsubdir (str): sub-directory for the current simulation
        workdir (str): the directory of the whole pycif simulation

    Notes:
        - LMDZ expects daily inputs; if the periods in the control vector are
        longer than one day, period values are uniformly de-aggregated to the
        daily scale; this is done with pandas function 'asfreq' and the option
        'ffill' as 'forward-filling'
        See Pandas page for details:
        https://pandas.pydata.org/pandas-docs/stable/generated/pandas
        .DataFrame.asfreq.html

    """

    if mode == "adj":
        if input_type != "fluxes":
            return datastore
    
        # Reads sensitivities
        # In the toy model's case, just take the data from the object itself
        datasensit = self.dflx
    
        # TODO: generalize with several species
        for spec in self.chemistry.acspecies.attributes:
            datastore[("fluxes", spec)]["adj_out"] = \
                copy.deepcopy(datasensit[spec])
        
        return datastore

    else:
        raise Exception("Dummy native to input (adjoint function) "
                        "was call in a mode different than adjoint")
    