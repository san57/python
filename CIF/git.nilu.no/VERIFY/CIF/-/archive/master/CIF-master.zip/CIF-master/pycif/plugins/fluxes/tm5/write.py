import os

from netCDF4 import Dataset
import numpy as np
import pandas as pd
import xarray

from pycif.utils.classes.fluxes import Fluxes
from pycif.utils.netcdf import save_nc


def write(self, name, flx_file, flx, mode="a"):
    """Write flux to TM5 emission compatible files.

    Args:
        self (Fluxes): the Fluxes plugin
        flx_file (str): the file where to write fluxes
        flx (xarray.DataArray): fluxes data to write
        mode (str): 'w' to overwrite, 'a' to append
        """


    return