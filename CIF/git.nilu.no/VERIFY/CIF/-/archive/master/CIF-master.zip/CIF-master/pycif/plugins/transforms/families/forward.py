def forward(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):

    xmod = pipe.datastore

    keys = ["spec"]
    if mode == "tl":
        keys.append("incr")

    trid_out = list(mapper["outputs"].keys())[0]

    xmod[trid_out] = {k: 0 for k in keys}
    for trid in mapper["inputs"]:
        for k in keys:
            xmod[trid_out][k] += xmod[trid][k]

        for k in xmod[trid]:
            if k not in keys:
                xmod[trid_out][k] = xmod[trid][k]

        del xmod[trid]

    pipe.datastore = xmod
