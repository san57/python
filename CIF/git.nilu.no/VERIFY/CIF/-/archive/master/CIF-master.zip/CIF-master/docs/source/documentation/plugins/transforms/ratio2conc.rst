#################################
Isotopic ratios to concentrations
#################################

.. automodule:: pycif.plugins.transforms.ratio2conc