import numpy as np
import pandas as pd

from logging import info
from pycif.utils.datastores.dump import dump_datastore, read_datastore
from pycif.utils.datastores.empty import init_empty

_name = "random"
_version = "param"

requirements = {"domain": {"any": True, "empty": False}}

default_values = {
    "frequency": "1H",
    "duration": "1H",
    "zmax": 100,
    "random_subperiod_shift": False,
    "seed": False,
    "seed_id": 0
}


def ini_data(plugin, **kwargs):
    """Generate random observations at random locations in the domain"""
    if hasattr(plugin, "file_monitor"):
        file_monitor = plugin.file_monitor

        try:
            info("Extracting measurements from {}".format(file_monitor))
            return read_datastore(
                file_monitor,
                dump_type=getattr(plugin, "dump_type", "nc"),
                **kwargs
            )

        except IOError as e:
            info(str(e))
            info("Could not find a monitor file, reading observations")

        except Exception as e:
            info(e)
            info("Could not read the specified monitor file: {}", file_monitor)
            raise e

    # Otherwise, create the monitor from observations
    else:
        if hasattr(plugin, "workdir"):
            workdir = plugin.workdir

        # if file_monitor == "" or file_monitor is None:
        #     file_monitor = workdir + "/obs/monit_standard.nc"
    
    # Create random sampling
    if plugin.seed:
        np.random.seed(plugin.seed_id)
    
    # Make date range
    drange = pd.date_range(
        plugin.datei, plugin.datef, freq=plugin.frequency
    )
    ndates = drange.size

    # Pick random locations for x and y within the reference domain
    xmin = plugin.domain.zlon.min()
    xmax = plugin.domain.zlon.max()
    ymin = plugin.domain.zlat.min()
    ymax = plugin.domain.zlat.max()
    zmax = plugin.zmax

    nstat = plugin.nstations

    statx = np.random.uniform(low=xmin, high=xmax, size=nstat)
    staty = np.random.uniform(low=ymin, high=ymax, size=nstat)
    statz = np.random.uniform(low=1, high=zmax, size=nstat)

    # Put locations into a monitor
    duration = pd.to_timedelta(plugin.duration)
    seconds_duration = duration.total_seconds() / 3600.0
    
    df = pd.DataFrame(
        {
            "alt": np.array(ndates * list(statz)),
            "lat": np.array(ndates * list(staty)),
            "lon": np.array(ndates * list(statx)),
            "obs": np.random.uniform(0, 1, size=ndates * nstat),
            "station": ndates * list(range(nstat)),
            "parameter": plugin.orig_name,
            "duration": seconds_duration,
            "date": np.array(nstat * list(drange))
                .reshape((ndates, nstat), order="F").flatten()
        }
    )

    if plugin.random_subperiod_shift:
        df["date"] += np.random.uniform(0, 1, size=ndates * nstat) * duration
        
    df.sort_values(by=["date"], inplace=True)
    df.index = np.arange(len(df))
    
    plugin.datastore = {"data": df}
    
    # Dumping the datastore for later use by pycif
    # dump_datastore(ds, file_monit=self.file_monitor, dump_type="nc")

