from .execute import execute

_name = "post-proc"

requirements = {
    "obsvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "controlvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "obsoperator": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
}
