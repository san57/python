from logging import warning


def run(self, runsubdir, mode, workdir, **kwargs):
    """Empty run method for model FLEXPART

    """

    warning("Empty run method for model FLEXPART")

