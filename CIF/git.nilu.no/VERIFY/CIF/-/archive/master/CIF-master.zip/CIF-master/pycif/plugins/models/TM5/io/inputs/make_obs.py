import numpy as np
import pandas as pd

from pycif.utils.datastores.empty import init_empty


def make_obs(self, datastore, runsubdir, mode, tracer, do_simu=True):

    # If empty datastore, do nothing
    if datastore.size == 0:
        return

    # Otherwise, crop the datastore to active species
    # Save it to the model in case it is needed later
    if not hasattr(self, "dataobs") or getattr(self, "reset_obs", True):
        self.dataobs = {spec: init_empty()
                        for spec in self.chemistry.acspecies.attributes}

    self.dataobs[tracer] = pd.concat([self.dataobs[tracer], datastore],
                                     axis=0, sort=False)

    # If do not need to do CHIMERE simulation, just update obs datastore
    if not do_simu:
        return

    # Write only species simulated by the model
    mask = (
        self.dataobs[tracer]["parameter"]
        .str.upper()
        .isin(["CH4"])
    )
    data2write = self.dataobs[tracer].loc[mask]
    
    # For adjoint, check that there is no NaN values
    if mode == "adj":
        if not np.all(~np.isnan(data2write.loc[:, "obs_incr"])):
            raise Exception("WARNING: pycif will drive TM5 adjoint "
                            "with NaNs values! Check prior informations")

    # Then write the data
    # pyCIF needs observations overlapping several model time steps to be unfolded
    # That mean that if "dtstep" > 1, you need to create as many virtual observations
    # in the observation file as dtstep
    # Refer to CHIMERE or LMDZ for examples