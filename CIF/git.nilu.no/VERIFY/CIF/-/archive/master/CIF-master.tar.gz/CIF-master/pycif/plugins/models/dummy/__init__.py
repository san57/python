"""
This toy model is implemented in the CIF as a testing utility.
It can easily be run on office laptop with low computational requirements.
Thus, features in pycif can be explored quickly.

It is also proposed as a minimal example of a fully implemented model in pycif.
We recommend developers to explore its code as a template for new model implementation in pycif.

Gaussian plume equation
***********************

The Toy Gaussian Model follows the standard version of the Gaussian plume equation
based on Pasquill-Gifford stability classification:


.. math::
    :label: gaussplume

    \\frac{1}{2 \\, \\pi \\;.\\;\\sigma_y \\;.\\; \\sigma_z \\;.\\;\\bar{u}}
    \\exp\\left(-\\,\\dfrac{y^2}{\\sigma_y ^2}\\right)
    \\exp\\left(-\\,\\dfrac{z^2}{\\sigma_z ^2}\\right)


with


.. math::
    :label: gaussplume_params

    \\left\\{
    \\begin{array}{rcl}
    \\sigma_z &=& a\\;.\\;x^b   \\\\
    \\sigma_y &=& | 465.11628 \\;x\\;.\\; \\tan(0.017653293 (c - d \\;\\ln x)) |
    \\end{array}
    \\right.

x is the distance between the source and receptor points, (a, b, c, d) are parameters depending on the stability class.


"""

import os
import shutil

from pycif.utils import path
from logging import info
from pycif.utils.classes.baseclass import Plugin
from .flushrun import flushrun
from .ini_mapper import ini_mapper
from .ini_periods import ini_periods
from .io.native2inputs import native2inputs
from .io.outputs2native import outputs2native
from .io.native2inputs_adj import native2inputs_adj
from .io.outputs2native_adj import outputs2native_adj
from .run import run

_name = "dummy"

requirements = {
    "domain": {"name": "dummy", "version": "std", "empty": False},
    "fluxes": {"name": "dummy", "version": "nc", "empty": True},
    "meteo": {
        "name": "dummy",
        "version": "csv",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
    },
}

input_arguments = {
    "file_pg": {
        "doc": "file with Pasquill-Gifford stability classes. "
               "Give correspondences between stability classes "
               "and gaussian dispersion parameters. "
               "The file is provided alongside pyCIF sources in the directory: "
               "``${CIF_root}/model_sources/dummy_gauss/``",
        "accepted": str
    },
    "periods": {
        "doc": "length of simulation sub-periods",
        "default": "1D",
        "accepted": str
    },

    "tstep": {
        "doc": "length of simulation temproal steps",
        "default": "1H",
        "accepted": str
    },
    "save_H": {
        "doc": "save the sensitivity matrix to a pickle file",
        "default": False,
        "accepted": bool
    },

}

required_inputs = ["fluxes", "meteo", "param"]


def ini_data(plugin, **kwargs):
    """Initializes the dummy_txt Gaussian model

    Args:
        plugin (Plugin): the model plugin to initialize
        **kwargs (dictionary): possible extra parameters

    Returns:
        loaded plugin and directory with executable

    """

    info("Initializing the model")

    workdir = getattr(plugin, "workdir", "./")

    # Initializes the directory
    path.init_dir("{}/model".format(workdir))

    # copying the model Pasquill Gifford matrix
    target = "{}/model/".format(workdir) + os.path.basename(plugin.file_pg)
    source = plugin.file_pg

    shutil.copy(source, target)

    # Initializes the sensitivity matrix
    plugin.H_matrix = {}

    return plugin
