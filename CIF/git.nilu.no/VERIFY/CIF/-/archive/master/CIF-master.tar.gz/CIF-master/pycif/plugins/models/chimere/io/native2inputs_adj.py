import pandas as pd
import datetime
import os
import glob
from netCDF4 import Dataset
import xarray as xr
import numpy as np

from pycif.utils import path
from .inputs.make_boundcond import make_boundcond
from .inputs.make_fluxes import make_fluxes
from .inputs.make_inicond import make_inicond
from .inputs.make_meteo import make_meteo
from .inputs.make_obs import make_obs
from .inputs.params import make_nml


def native2inputs_adj(
    self, datastore, input_type, datei, datef, runsubdir, mode="fwd",
    **kwargs
):
    """Converts data at the model data resolution to model compatible input
    files.

    Args:
        self: the model Plugin
        input_type (str): one of 'fluxes'
        datastore: data to convert
            if input_type == 'fluxes',
        datei, datef: date interval of the sub-simulation
        mode (str): running mode: one of 'fwd', 'adj' and 'tl'
        runsubdir (str): sub-directory for the current simulation
        workdir (str): the directory of the whole pyCIF simulation

    Notes:
        - CHIMERE expects hourly inputs;

    """
    
    if datastore == {}:
        return datastore
    
    ddi = min(datei, datef)
    
    # List of CHIMERE dates
    dref = datetime.datetime.strptime(
        os.path.basename(os.path.normpath(runsubdir)), "%Y-%m-%d_%H-%M"
    )
    list_dates = self.input_dates[ddi]

    # Reading only output files related to given input_type
    ref_names = {
        "inicond": "ini",
        "fluxes": "aemis",
        "biofluxes": "bemis",
        "latcond": "bc",
        "topcond": "bc",
    }
    
    if input_type not in ref_names:
        return datastore
    
    for trid in datastore:
        file_list = glob.glob(
                    "{}/aout.*{}*.nc".format(runsubdir, ref_names[trid[0]])
                )
        if len(file_list) == 0:
            continue
        
        sensit_file = file_list[0]
        sensit_basename = os.path.basename(sensit_file)
        with Dataset(sensit_file, "r") as f:
            # Load list of species and reformat it
            list_species = [
                b"".join(s).strip().decode("ascii")
                for s in f.variables["species"][:]
            ]
            
            if trid[1] not in list_species:
                continue
            
            # Different output structure between LBC and others
            if "ini" in sensit_basename or "emis" in sensit_basename:
                data = f.variables[trid[1]][:]
        
            elif "bc" in sensit_basename:
                k = list_species.index(trid[1])
                data_lat = f.variables["lat_conc"][..., k]
                data_top = f.variables["top_conc"][..., k]
                
        if "ini" in sensit_basename:
            datastore[trid]["adj_out"] = xr.DataArray(
                    data[np.newaxis, ...],
                    coords={"time": np.array([dref])},
                    dims=("time", "lev", "lat", "lon"),
                )
    
        elif "bc" in sensit_basename:
            if input_type == "latcond":
                datastore[trid]["adj_out"] = xr.DataArray(
                    data_lat[..., np.newaxis, :],
                    coords={"time": list_dates},
                    dims=("time", "lev", "lat", "lon"),
                )
            if input_type == "topcond":
                datastore[trid]["adj_out"] = xr.DataArray(
                        data_top[..., np.newaxis, :],
                        coords={"time": list_dates},
                        dims=("time", "lev", "lat", "lon"),
                    )
    
        elif "aemis" in sensit_basename or "bemis" in sensit_basename:
            if "aemis" in sensit_basename:
                emis_type = "fluxes"
            else:
                emis_type = "biofluxes"
            
            datastore[trid]["adj_out"] = xr.DataArray(
                data,
                coords={"time": list_dates},
                dims=("time", "lev", "lat", "lon"),
            )

    return datastore
