#################################################
Contributing to the Community Inversion Framework
#################################################

The Community Inversion Framework is designed as a cooperative project.
Any contribution is very welcome, should it concern developing new functionalities in the system,
fixing bugs or improving the documentation.

Please find below instructions for contributing to the code or the documentation.

.. toctree::
    :maxdepth: 2

    code_conduct
    contrib_code
    contrib_doc
