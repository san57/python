###############
Modes
###############

.. toctree::
    :maxdepth: 3

    forward
    adjtl-test
    variational
    footprints







