
import numpy as np
import xarray as xr



from logging import info, debug
from pycif.utils.datastores.dump import read_datastore
from .apply_AK import apply_ak_ad
from .vinterp import vertical_interp
import copy


def adjoint(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    """De-aggregate total columns to the model level."""
    ddi = min(di, df)

    datastore = pipe.datastore
    ref_parameter = transf.parameter[0]
    ref_component = transf.component[0]

    ref_datastore = datastore[(transf.component[0], transf.parameter[0])]
    ref_ds = ref_datastore["data"]
    
    # Copy data to output datastore
    datastore[("concs", transf.parameter[0])] = \
        {key: pipe.datastore[(transf.component[0], transf.parameter[0])][key]
         for key in pipe.datastore[(transf.component[0], transf.parameter[0])]}

    y0 = pipe.datastore[("concs", transf.parameter[0])]["data"]

    # Number of levels to extract for satellites
    dlev = np.ones(len(y0), dtype=int) * transf.model.domain.nlev

    # Index in the original data of the level-extended dataframe
    native_inds = np.append([0], dlev.cumsum())

    # Output index
    idx = np.zeros((native_inds[-1]), dtype=int)
    idx[native_inds[:-1]] = np.arange(len(y0))
    np.maximum.accumulate(idx, out=idx)
    native_inds = native_inds[:-1]

    # Output dataframe
    datacol = "obs_incr" if mode == "adj" else "obs"
    col2process = [
        "tstep",
        "tstep_glo",
        "i",
        "j",
        "level",
        "dtstep",
        "parameter",
        "duration",
        datacol,
    ]
    df = copy.deepcopy(y0.iloc[idx])

    # Levels
    sublevels = np.meshgrid(
        list(range(transf.model.domain.nlev)),
        np.ones(len(y0)))[0].flatten()
    df["level"] = sublevels

    # Building the extended dataframe
    # iq1 = (np.abs(y0['level']) - np.abs((y0['level'] / 10.)
    #                                    .astype(int) * 10)) \
    #    .astype(int)
    iq1 = y0["station"]
    list_satIDs = iq1.unique()
    
    # Saving original values for later re-aggregation
    df.loc[:, "indorig"] = idx
    df.loc[:, "iq1"] = iq1.iloc[idx]

    # Stop here if not adjoint
    if onlyinit:
        pipe.datastore[("concs", transf.parameter[0])]["data"] = df
        return

    # Load pressure coordinates from previous run
    file_monit = ddi.strftime(
        "{}/chain/satellites/monit_%Y%m%d%H%M.nc".format(
            transf.model.adj_refdir)
    )
    fwd_pressure = read_datastore(
        file_monit,
        col2dump=["pressure", "dp", "indorig", "hlay", "airm", "sim", "pthick"]
    )
    ref_indexes = ~fwd_pressure.duplicated(subset=["indorig"])
    
    for satID in list_satIDs:
        satmask = iq1 == satID
        nobs = np.sum(satmask)

        # Getting the vector of increments
        obs_incr = y0.loc[satmask, "obs_incr"]
        sim_ak = y0.loc[satmask, "sim"]
        # If all increments are NaNs, just pass to next satellite
        if not np.any(obs_incr != 0.0):
            continue

        # Get target pressure
        native_ind_stack = (
            native_inds[satmask]
            + np.arange(transf.model.domain.nlev)[:, np.newaxis]
        )
        datasim = xr.Dataset(
            {
                "pressure": (
                    ["level", "index"],
                    np.log(fwd_pressure["pressure"].values[native_ind_stack]),
                ),
                "dp": (
                    ["level", "index"],
                    fwd_pressure["dp"].values[native_ind_stack],
                ),
                "airm": (
                    ["level", "index"],
                    fwd_pressure["airm"].values[native_ind_stack],
                ),
                "hlay": (
                    ["level", "index"],
                    fwd_pressure["hlay"].values[native_ind_stack],
                ),
                "sim": (["level", "index"],
                        fwd_pressure["sim"].values[native_ind_stack]),
            },
            coords={
                "index": np.arange(len(y0)),
                "level": np.arange(transf.model.domain.nlev),
            },
        )

        # Getting averaging kernels
        dir_sat = ref_datastore["tracer"].dir
        file_sat = ref_datastore["tracer"].file
        file_aks = "{}/{}".format(dir_sat, file_sat)
        files_aks = ref_datastore["tracer"].input_files[ddi]

        try:
            colsat = ["qa0", "ak", "pavg0", "date"]
            all_sat_aks = []
            for file_aks in files_aks:
                sat_aks = \
                    read_datastore(file_aks,
                                   col2dump=colsat,
                                   keep_default=False,
                                   to_pandas=False)
                sat_aks["index"] = np.arange(sat_aks.dims["index"])
                if len(all_sat_aks) == 0:
                    all_sat_aks = sat_aks
                else:
                    all_sat_aks = xr.concat([all_sat_aks, sat_aks], "index")
    
            # Selecting only lines used in simulation
            mask = all_sat_aks["date"].isin(ref_ds["date"]) \
                   & all_sat_aks.index.isin(ref_ds.index)
            sat_aks = all_sat_aks.loc[{"index": mask}]
            
        except IOError:
            # Assumes total columns?
            # groups = fwd_pressure.groupby(['indorig'])
            # df['obs_incr'] = y0.ix[idx, 'obs_incr'] * fwd_pressure['dp'] \
            #                  / groups['dp'].sum().values[idx]
            continue

        # Defining ak info
        #        aks = sat_aks['ak'][nblloc, ::-1][:,1:].T
        aks = sat_aks["ak"][:, ::-1].T

        if transf.pressure == "Pa":
            pavgs = sat_aks["pavg0"][:, ::-1].T
        else:
            pavgs = 100 * sat_aks["pavg0"][:, ::-1].T

        coords0 = {"index": np.arange(nobs),
                   "level": np.arange(aks.level.size + 1)}
        coords1 = {"index": np.arange(nobs),
                   "level": np.arange(aks.level.size)}
        dims = ("level", "index")
        pavgs = xr.DataArray(pavgs, coords0, dims).bfill("level")
        pavgs_mid = xr.DataArray(
            np.log(0.5 * (pavgs[:-1].values + pavgs[1:].values)),
            coords1, dims)
        dpavgs = xr.DataArray(np.diff(-pavgs, axis=0), coords1, dims)
        qa0 = sat_aks["qa0"][:, ::-1].T

        # Applying aks
        nbformula = transf.formula
        chosenlevel = getattr(transf, "chosenlev", 0)

        debug("nbformula: {}".format(nbformula))
        debug("chosenlev: {}".format(chosenlevel))
        
        obs_incr = apply_ak_ad(
            sim_ak, dpavgs, aks, nbformula, qa0, chosenlevel, obs_incr
        )
        obs_incr[np.isnan(obs_incr)] = 0.

        # Correction with the pressure thickness
        # WARNING: there is an inconsistency in the number of levels
        if transf.correct_pthick:
            scale_pthick = fwd_pressure.iloc[
                np.flatnonzero(ref_indexes)[satmask],
                fwd_pressure.columns.get_loc("pthick")]
            obs_incr *= scale_pthick.values
        
        # Adjoint of the log-pressure interpolation
        obs_incr_interp = 0.0 * datasim["pressure"].values

        nchunks = getattr(transf, "nchunks", 50)
        chunks = np.linspace(0, nobs, num=nchunks, dtype=int)
        cropstrato = getattr(transf, "cropstrato", False)
        for k1, k2 in zip(chunks[:-1], chunks[1:]):
            # Vertical interpolation
            xlow, xhigh, alphalow, alphahigh = vertical_interp(
                datasim["pressure"][:, k1:k2].values,
                pavgs_mid[:, k1:k2].values,
                cropstrato,
            )

            # Applying coefficients
            # WARNING: There might be repeated indexes in a given column
            # To deal with repeated index, np.add.at is recommended
            levmeshout = np.array(
                (k2 - k1) * [list(range(pavgs_mid.shape[0]))]
            ).T
            meshout = np.array(pavgs_mid.shape[0] * [list(range(k1, k2))])

            np.add.at(
                obs_incr_interp,
                (xlow, meshout),
                obs_incr[levmeshout, meshout] * alphalow,
            )

            np.add.at(
                obs_incr_interp,
                (xhigh, meshout),
                obs_incr[levmeshout, meshout] * alphahigh,
            )
        
        # Convert CHIMERE fields to the correct unit
        # from ppb to molec.cm-2 if the satellite product is a column
        if getattr(transf, "product", "level") == "column":
            obs_incr_interp *= datasim["hlay"].values / (
                1e9 / datasim["airm"].values
            )

        # Applying increments to the flattened datastore
        df.iloc[
            native_ind_stack.flatten(), df.columns.get_loc("obs_incr")
        ] = obs_incr_interp.flatten()
    
    pipe.datastore[("concs", transf.parameter[0])]["data"] = df
    