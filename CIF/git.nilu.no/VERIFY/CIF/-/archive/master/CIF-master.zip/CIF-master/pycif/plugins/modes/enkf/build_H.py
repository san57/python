import pandas as pd
import os
import pickle
import numpy as np
from pycif.utils.datastores.dump import read_datastore


def build_Hx(obsvect, ensemble_dir, x_sample):
    datavect = obsvect.datavect
    nsamples = len(x_sample)
    
    # If no definition is specified for the control vector in the Yaml,
    # return empty control vector
    if not hasattr(datavect, "components"):
        raise Exception("Computing H operator with no observations")
    
    # Else, carry on initializing
    harray = np.zeros((obsvect.dim, nsamples))
    jacobian = {}
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
        
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
        
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
            
            # Skip tracers that are not observation variables
            if not tracer.isobs:
                continue
            
            ds = tracer.datastore["data"]
            hloc = pd.DataFrame(columns=range(nsamples),
                                index=ds.index)
            for isample in range(nsamples):
                monitor_file = \
                    "{}/H_matrix/obsvect_{:04d}/{}/{}/monitor.nc"\
                        .format(ensemble_dir, isample, comp, trcr)
                data = read_datastore(monitor_file)
                hloc.loc[:, isample] = data.loc[:, "sim"].values
                
            jacobian[(comp, trcr)] = hloc
            harray[tracer.ypointer: tracer.ypointer + tracer.dim, :] = \
                hloc

    # Dumping H
    H_file = os.path.join(ensemble_dir, "Hx.pickle")
    with open(H_file, "wb") as f:
        pickle.dump(harray, f, pickle.HIGHEST_PROTOCOL)
    
    return harray
