####################
Observation vectors
####################

.. role:: bash(code)
   :language: bash




Available Observation vectors
===============================

The following :bash:`obsvects` are implemented in pyCIF:

.. toctree::

    standard

