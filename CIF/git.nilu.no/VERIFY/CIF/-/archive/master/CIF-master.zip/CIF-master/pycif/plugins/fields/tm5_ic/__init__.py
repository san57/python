from .read import read
from .write import write

_name = "TM5"
_version = "ic"

requirements = {"domain": {"name": "dummy", "version": "std", "empty": False}}
