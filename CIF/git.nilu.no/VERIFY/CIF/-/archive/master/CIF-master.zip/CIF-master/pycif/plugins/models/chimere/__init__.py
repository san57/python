import pandas as pd

from pycif.utils import path
from logging import info
from .compile import compile
from .flushrun import flushrun
from .ini_mapper import ini_mapper
from .ini_periods import ini_periods
from .run import run
from .io.outputs2native import outputs2native
from .io.outputs2native_adj import outputs2native_adj
from .io.native2inputs import native2inputs
from .io.native2inputs_adj import native2inputs_adj

_name = "CHIMERE"

requirements = {
    "domain": {
        "name": "CHIMERE",
        "version": "std",
        "empty": False,
        "any": False,
    },
    "chemistry": {
        "name": "CHIMERE",
        "version": "gasJtab",
        "empty": False,
        "any": False,
    },
    "fluxes": {
        "name": "CHIMERE",
        "version": "AEMISSIONS",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
    },
    "biofluxes": {
        "name": "CHIMERE",
        "version": "AEMISSIONS",
        "type": "fluxes",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
        "emis_type": "bio"
    },
    "meteo": {
        "name": "CHIMERE",
        "version": "std",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
    },
    "latcond": {
        "name": "CHIMERE",
        "version": "icbc",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
    "topcond": {
        "name": "CHIMERE",
        "version": "icbc",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
    "inicond": {
        "name": "CHIMERE",
        "version": "icbc",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
}

input_arguments = {
    "direxec": {
        "doc": "Path to CHIMERE sources and/or executables. "
               "For executables, ``fwdchimere.e``, ``tlchimere.e`` and ``achimere.e`` should be in "
               "``${path}/src``, ``${path}/src_tl`` and ``${path}/src_ad`` respective sub-folders.",
        "default": None,
        "accepted": str
    },

    "nphour_ref": {
        "doc": "Number if physical steps per hour. "
               "6 is well tested for regional cases.",
        "default": None,
        "accepted": int
    },

    "ichemstep": {
        "doc": "Number of chemical refined iterations, "
               "i.e., refined time steps relative to physical time steps. "
               "Down to 1/4 degree resolution, phys=6 and step=1 is fine; "
               "For finer grids (5-10 kms), take at least step=4; "
               "For grids of 2-5 kms, try step=6 or more.",
        "default": None,
        "accepted": int
    },

    "ideepconv": {
        "doc": "Computation of the deep convection.",
        "default": None,
        "accepted": {
            0: "No deep convection",
            1: "Select deep convection automatically according to resolution, "
               "deep conv fluxes from Tiedtke",
            2: "Select deep convection automatically according to resolution, "
               "deep conv fluxes from meteorological data"
        }
    },

    "nivout": {
        "doc": "Number of vertical layers in output files.",
        "default": None,
        "accepted": int
    },

    "nlevemis": {
        "doc": "Number of levels for emissions. Applies to AEMISSION files.",
        "default": None,
        "accepted": int
    },

    "periods": {
        "doc": "Length of sub-simulations periods. Use Pandas frequency strings",
        "default": "1D",
        "accepted": str
    },

    "ihoursu": {
        "doc": "Number of spin-up hours.",
        "default": 0,
        "accepted": int
    },

    "optemisb": {
        "doc": "Include biogenic emissions, i.e. the file BEMISSIONS.nc",
        "default": False,
        "accepted": bool
    },

    "dumpnctype": {
        "doc": "Precision for the output NetCDF files. Do not impact the values in mod.txt",
        "default": "float",
        "accepted": {
            "double": "double precision: needed if precise post-processing of output files",
            "float": "float precision: save some disk space"
        }
    },

    "dumpncoutput": {
        "doc": "Dump outputs into a NetCDF file.",
        "default": True,
        "accepted": bool
    },

    "dumpncpar": {
        "doc": "Dump parameters into a NetCDF file.",
        "default": False,
        "accepted": bool
    },

    "usechemistry": {
        "doc": "Use chemistry.",
        "default": 0,
        "accepted": [0, 1]
    },

    "useemissions": {
        "doc": "Use emisions.",
        "default": 1,
        "accepted": [0, 1]
    },

    "usetransmix": {
        "doc": "Use transport and mixing.",
        "default": 1,
        "accepted": [0, 1]
    },

    "usewetdepos": {
        "doc": "Use wet deposition.",
        "default": 0,
        "accepted": [0, 1]
    },

    "usedepos": {
        "doc": "Use dry deposition.",
        "default": 0,
        "accepted": [0, 1]
    },

    "nsavedepos": {
        "doc": "Save deposition in NetCDF file every ... hours.",
        "default": 4,
        "accepted": int
    },

    "dryairout": {
        "doc": "Use dry air conversion to produce output files. "
               "By default, CHIMERE produces wet mole fractions. "
               "Be aware that most observation data are reported "
               "in dry mole fractions. "
               "Hence, prefer using dry air mole fraction "
               "if comparing to observations.",
        "default": 0,
        "accepted": [0, 1]
    },

    "nitgs": {
        "doc": "Number of Gauss-Seidel iterations in the TWOSTEP solver.",
        "default": 1,
        "accepted": {
            1: "for model testing, and when using the adjoint",
            2: "for better accuracy"
        }
    },

    "nitgssu": {
        "doc": "Same during spin-up",
        "default": 1,
        "accepted": {
            1: "for model testing, and when using the adjoint",
            2: "for better accuracy"
        }
    },

    "useabsclipconc": {
        "doc": "Clip small (in absolute value) concentrations. "
               "Warning: the clipping is done only and "
               "not only at the output writting; "
               "thus, clipping must be used with care as it can alter the mass conservation",
        "default": 0,
        "accepted": [0, 1]
    },

    "clipconc": {
        "doc": "Clipping concentration (in molecule/cm3)",
        "default": 1,
        "accepted": float
    },

    "ntyperate": {
        "doc": "Max number of reaction types",
        "default": 50,
        "accepted": int
    },

    "nvegtype": {
        "doc": "Number of vegetation types",
        "default": 16,
        "accepted": int
    },

    "nlduse": {
        "doc": "Max number of landuse classes",
        "default": 9,
        "accepted": int
    },

    "nparammax": {
        "doc": "Max number of output parameters",
        "default": 30,
        "accepted": int
    },

    "hpulse": {
        "doc": "Hour of emission pulse. All emissions before this hour "
               "from the beginning of the simulations are ignored, "
               "and all transport/chemistry computations are skipped."
               "To be used when computing response functions from a given hour",
        "default": 0,
        "accepted": int
    },

    "auto-recompile": {
        "doc": "Auto-compile executables before running",
        "default": False,
        "accepted": bool
    },

    "compile-mode": {
        "doc": "Compilation mode",
        "default": "PROD",
        "accepted": {
            "PROD": "production mode; all optimizations are activated",
            "DEBUG": "check-all and traceback are activated, "
                     "hence slowing down the execution"
        }
    },

    "compile-clean": {
        "doc": "Cleaning repositories before compiling; "
               "slows the compilation but prevent side-effects from re-compiling."
               "Can be switched of for minor modifications in the code",
        "default": True,
        "accepted": bool
    },

    "nlevemis_bio": {
        "doc": "Number of vertical levels in biogenic emissions (BEMISSIONS.nc)",
        "default": 1,
        "accepted": int
    },

    "nmdoms": {
        "doc": "Number of parallel domains in meridional direction",
        "default": 1,
        "accepted": int
    },

    "nzdoms": {
        "doc": "Number of parallel domains in zonal direction",
        "default": 1,
        "accepted": int
    },

    "write_for_adjoint": {
        "doc": "Write tmp files for running the adjoint; "
               "tmp files are binary including concentrations "
               "at all time steps in the forward and used by the adjoint",
        "default": True,
        "accepted": bool
    },
}

# Replacement component if not defined in state vector
backup_comps = {"latcond": "background",
                "topcond": "background"}

# Required inputs for running a CHIMERE simulation
required_inputs = [
    "exe",
    "nml",
    "fluxes",
    "biofluxes",
    "meteo",
    "inicond",
    "latcond",
    "topcond",
]


def ini_data(plugin, **kwargs):
    """Initializes CHIMERE

    Args:
        plugin (dict): dictionary defining the plugin
        **kwargs (dictionary): possible extra parameters

    Returns:
        loaded plugin and directory with executable

    """

    info("Initializing the model")

    workdir = getattr(plugin, "workdir", "./")

    # Initializes the directory
    path.init_dir("{}/model".format(workdir))

    # Number of hours per period
    plugin.nhours = int(
        pd.to_timedelta(plugin.periods).total_seconds() // 3600
    )
    plugin.nho = "{:.0f}".format(plugin.nhours)

    # Replacing nsaveconcs if not specified
    # Forces the end.nc file to contain concentration every N hours
    # By default, saves only at the end
    if not hasattr(plugin, "nsaveconcs"):
        plugin.nsaveconcs = plugin.nhours

    # Replace name for METEO files
    plugin.meteo.file = plugin.meteo.file.format(nho=plugin.nho)

    # Replace name for AEMISSION files and BEMISSIONS files
    plugin.fluxes.file = plugin.fluxes.file.format(nho=plugin.nho)
    plugin.fluxes.nlevemis = plugin.nlevemis
    
    plugin.biofluxes.file = plugin.biofluxes.file.format(nho=plugin.nho)
    plugin.biofluxes.nlevemis = plugin.nlevemis_bio
    
    # Replace name for BOUN_CONCS files
    plugin.latcond.file = plugin.latcond.file.format(nho=plugin.nho)
    plugin.topcond.file = plugin.topcond.file.format(nho=plugin.nho)
    
    # Run options
    plugin.run_options = ['--oversubscribe',
                          "-mca",
                          "btl",
                          "self,sm,tcp"]
    
    return plugin
