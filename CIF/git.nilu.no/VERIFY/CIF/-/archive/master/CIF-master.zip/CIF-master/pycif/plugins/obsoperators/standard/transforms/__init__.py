from pycif.utils.classes.transforms import Transform
from .utils import add_default
from .init_model import init_model
from .init_before import init_before
from .init_after import init_after


def init_transform(self):
    
    # Initializes the overall transform pipe
    if not hasattr(self, "transform_pipe"):
        self.transform_pipe = Transform.from_dict({})
    
    transforms = self.transform_pipe
    transfs_ids = getattr(transforms, "attributes", [])
    
    mapper = {}
    backup_comps = {}
    all_inputs = {}
    all_outputs = {}
    
    # Adding model transform if not already included
    # And initializes mapper
    init_model(transfs_ids, transforms,
               all_inputs, all_outputs, backup_comps, mapper)

    # Initializing transformation before the model
    # It includes controlvect transformations
    init_before(self, self.controlvect,
                all_inputs, all_outputs, backup_comps, mapper)

    # Initializing transformation after the model
    # i.e., on the observation side
    init_after(self, self.obsvect,
               all_inputs, all_outputs, backup_comps, mapper)
    
    # # If observations initialize at the root level
    # if transform_type == "obs":
    #     mapper = {}
    #     for transform in transform_pipe.transform.attributes:
    #         # Replacing the transform by a transform class
    #         transf = getattr(transform_pipe.transform, transform)
    #         if transf is None:
    #             transf = Transform.from_dict({}, orig_name=transform)
    #             setattr(transform_pipe.transform, transform, transf)
    #
    #         # Updating the general mapper, and creates a local one
    #         transf_mapper = transf.ini_mapper(transform_type)
    #         transf.mapper = transf_mapper
    #         mapper[transform] = transf_mapper
    #
    #     transform_pipe.transform.mapper = mapper
    #     return

    transforms.mapper = mapper
