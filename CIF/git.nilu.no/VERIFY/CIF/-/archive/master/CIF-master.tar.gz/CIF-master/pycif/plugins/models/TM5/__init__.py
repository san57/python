# JvP 20200918: added following import statement
from logging import info
import shutil
from pycif.utils import path

from .ini_mapper import ini_mapper
from .ini_periods import ini_periods
from .compile import compile
from .flushrun import flushrun
from .run import run
from .io.outputs2native import outputs2native
from .io.outputs2native_adj import outputs2native_adj
from .io.native2inputs import native2inputs
from .io.native2inputs_adj import native2inputs_adj

_name = "TM5"


requirements = {
    "domain": {
        "name": "dummy",
        "version": "std",
        "empty": False,
        "any": False,
    },
    "chemistry": {
        "name": "TM5",
        "version": "SINK-TIPP",
        "empty": False,
        "any": False,
    },
    "fluxes": {
        "name": "TM5",
        "version": "std",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
    },
    "meteo": {
        "name": "TM5",
        "version": "std",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
    },
    "inicond": {
        "name": "TM5",
        "version": "ic",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
}

# JvP 20201016: Apparently, the keys of the input_arguments dict provide default
# values for the settings in the yaml file. If a key is not present in the yaml
# file, it is still added as a model attribute using the value specified here.
#    Each value is another dict, containing one or all
# of the following keys (judging by the Chimere code): "doc", "default" and
# "accepted". A full key value pair for a required setting would therefore be:
#
#    "BAGGER": {
#       "doc"      : "Required variable in the yaml file.",
#       "default"  : None,
#       "accepted" : str,
#    }
#
#
# JvP 20201103: In general, do not use minus signs in variable names.
# In this case, variables like 'direxec' and 'auto-recompile' will become
# attributes to the model TM5. You should be able to get the value of these
# attributes by using either of:
#    1) self.auto-recompile
#    2) getattr(self, 'auto-recompile')
# Note that the first method won't work, because python will interpret that
# as 'get the value for self.auto and subtract the variable recompile'. That
# will yield an AttributeError, since there is no attribute called 'auto'.
# To prevent that error from occuring, I replaced auto-recompile with
# auto_recompile. See .../pycif/plugins/models/TM5/{__init__,compile}.py and
# the yaml file (e.g. config_TM5_forward.yml) for the use of auto_recompile.
#
input_arguments = {
    "direxec": {
        # JvP 20201016: added "default" and "accepted" keys
        "doc"      : "Path to executable and/or sources",
        "default"  : None,
        "accepted" : str,
    },
    "auto_recompile": {
        # JvP 20201016: added "accepted" keys
        "doc"      : "Recompile sources",
        "default"  : False,
        "accepted" : bool,
    },
    "make_clean": {
        "doc"      : "When compiling, do a 'make clean' first.",
        "default"  : True,
        "accepted" : bool,
    },
}


def ini_data(plugin, **kwargs):
    """Initilize any variable or folder specific to the model
    and not initialized somewhere else

    Period and time variables are initialized in ini_period.

    All the rest can be initialized here

    """

    info("Initializing the model")

    workdir = getattr(plugin, "workdir", "./")

    # Cleaning the model working directory
    shutil.rmtree("{}/model/".format(workdir), ignore_errors=True)

    # Initializes the directory
    path.init_dir("{}/model".format(workdir))
