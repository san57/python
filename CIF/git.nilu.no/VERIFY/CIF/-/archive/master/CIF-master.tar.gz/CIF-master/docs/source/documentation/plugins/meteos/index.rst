#####################
Meteorological fields
#####################

.. role:: bash(code)
   :language: bash


Available Meteo
================================

The following :bash:`meteos` are implemented in pyCIF:

.. toctree::

    chimere_meteo
    dummy_csv
    lmdz_massflx

