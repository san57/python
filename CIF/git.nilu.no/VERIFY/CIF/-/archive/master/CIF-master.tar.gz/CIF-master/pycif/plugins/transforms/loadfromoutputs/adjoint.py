from logging import info


def adjoint(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        do_simu=True,
        **kwargs
):

    datastore = pipe.datastore
    for trid in mapper["inputs"]:
        input_type = trid[0]

        # If trid in datastore, dumps this one
        if trid in datastore:
            todump = [trid]

        # If input parameter is '',
        # dumps all available parameters of this component
        elif trid[1] == "":
            todump = [t for t in datastore if t[0] == trid[0]]

        # Otherwise check whether there is a component
        # encompassing all parameters (i.e., with '' as parameter)
        else:
            todump = [(trid[0], "")]
        
        # Create new data to extract
        data2dump = {t: datastore[t] for t in todump if t in datastore}

        if data2dump == {}:
            return
        
        data2dump = transform.model.outputs2native_adj(
            data2dump, input_type, di, df, runsubdir, mode,
            onlyinit=onlyinit, do_simu=do_simu
        )

