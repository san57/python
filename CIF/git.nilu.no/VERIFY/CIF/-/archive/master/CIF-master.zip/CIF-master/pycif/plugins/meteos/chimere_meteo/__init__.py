from .fetch import fetch
from .read import read

_name = "CHIMERE"

requirements = {
    "domain": {"name": "CHIMERE", "version": "std", "empty": False}
}

input_arguments = {
    "dir": {
       "doc": "directory where the METEO.nc files are located",
       "default": None,
       "accepted": str
    },
    "file": { 
       "doc": "form of the name of the files to use if different from METEO.YYYYMMDDHH.hh.nc",
       "default": "METEO.%Y%m%d%H.{nho}.nc",
       "accepted": str
    }
}

def ini_data(plugin, **kwargs):

    # Default file names for CHIMERE: METEO
    if not hasattr(plugin, "file"):
        plugin.file = "METEO.%Y%m%d%H.{nho}.nc"
