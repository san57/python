#####################
CONGRAD
#####################

.. automodule:: pycif.plugins.minimizers.congrad