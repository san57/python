def write():
    raise Exception("I don't know yet how to write LMDZ sflx files")
