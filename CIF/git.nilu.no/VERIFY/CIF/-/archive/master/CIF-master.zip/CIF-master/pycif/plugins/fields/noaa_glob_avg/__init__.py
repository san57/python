from .read import read
from .get_domain import get_domain
from .write import write

_name = "NOAA"
_version = "glob_avg"