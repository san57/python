import os
import pickle
import numpy as np
from scipy.interpolate import RectBivariateSpline

from .reproject import reproject_emissions


def get_weights(
    transform,
    wgt_file,
    nlon_in,
    nlat_in,
    zlon_in,
    zlat_in,
    zlonc_in,
    zlatc_in,
    domain_out,
    is_lbc
):
    
    if is_lbc:
        zlon_out = domain_out.zlon_side
        zlonc_out = domain_out.zlonc_side
        zlat_out = domain_out.zlat_side
        zlatc_out = domain_out.zlatc_side

    else:
        zlon_out = domain_out.zlon
        zlonc_out = domain_out.zlonc
        zlat_out = domain_out.zlat
        zlatc_out = domain_out.zlatc

    # Loading weights if available
    loaded_weights = False
    if os.path.isfile(wgt_file):
        with open(wgt_file, "rb") as f:
            weights = pickle.load(f)
            loaded_weights = True

    # Otherwise, creating them
    meshj, meshi = np.meshgrid(range(nlon_in), range(nlat_in))
    if not loaded_weights:
        if transform.method == "mass-conservation":
            weights = reproject_emissions(
                0. * zlon_in,
                zlonc_in,
                zlatc_in,
                zlonc_out,
                zlatc_out,
                return_weight=True,
            )

        elif transform.method == "bilinear":
            interp = RectBivariateSpline(
                zlon_in[0],
                zlat_in[:, 0],
                meshi.T,
                bbox=[None, None, None, None],
            )
            meshi_out = interp(
                zlon_out.flatten(order="F"),
                zlat_out.flatten(order="F"),
                grid=False,
            )

            interp = RectBivariateSpline(
                zlon_in[0],
                zlat_in[:, 0],
                meshj.T,
                bbox=[None, None, None, None],
            )
            meshj_out = interp(
                zlon_out.flatten(order="F"),
                zlat_out.flatten(order="F"),
                grid=False,
            )

            imin = np.floor(meshi_out).astype(int)
            jmin = np.floor(meshj_out).astype(int)
            alpha_imax = meshi_out - imin
            alpha_jmax = meshj_out - jmin

            weights = [
                (
                    [i, i, i + 1, i + 1],
                    [j, j + 1, j + 1, j],
                    [
                        (1 - ai) * (1 - aj),
                        (1 - ai) * aj,
                        ai * aj,
                        ai * (1 - aj),
                    ],
                )
                for i, j, ai, aj in zip(imin, jmin, alpha_imax, alpha_jmax)
            ]

        else:
            raise Exception(
                "Regrid method not known: {}\n"
                "Please check your Yaml file".format(transform.method)
            )

        with open(wgt_file, "wb") as f:
            pickle.dump(weights, f)
            loaded_weights = True

    return weights
