

from pycif.utils import path


def make_meteo(self, runsubdir, sdc):
    """Link to meteo file"""

    return
