import datetime

import pandas as pd

from logging import info


def crop_monitor(datastore, datei, datef, **kwargs):
    """Crops observation datasets to keep observations whose duration fits
    entirely during the simulation period

    Args:
        datastore (pd.DataFrame): observation dataset
        datei (datetime.datetime): start date
        datef (datetime.datetime): end date

    Returns:
        pd.DataFrame: Cropped dataframe
    """

    info("Cropping obsvect.datastore to simulation window")
    info("{} to {}".format(datei, datef))
    
    ds = datastore["data"]
    mask = (ds["date"] >= datei) \
           & (ds["date"] + pd.to_timedelta(ds["duration"], unit="h") <= datef)
    datastore["data"] = ds.loc[mask]
    
    return datastore
