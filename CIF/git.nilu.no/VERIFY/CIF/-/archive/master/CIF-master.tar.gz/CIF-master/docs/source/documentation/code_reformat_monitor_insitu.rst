The script below reads a netCDF monitor file in which some information are missing
and the date is used as the index and converts it to a fully usable monitor with the right index


.. literalinclude:: convert_monitor_insitu.py
    :linenos:
    :language: python

..
    :lines: 1, 3-5
    :start-after: 3
    :end-before: 5
