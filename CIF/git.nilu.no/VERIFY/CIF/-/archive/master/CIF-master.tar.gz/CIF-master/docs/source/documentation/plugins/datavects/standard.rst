#####################
Standard data vector
#####################

.. role:: bash(code)
   :language: bash

Description
===========

This is the standard pyCIF implementation of the :bash:`datavect` class.
Information about inputs are split into :bash:`component/parameter` categories.
:bash:`component/parameter` categories are fully flexible in terms of names,
but should be consistent with the rest of the configuration.

General :bash:`component` categories include for instance:

:concs: observed concentrations
:fluxes: emission fluxes
:inicond: initial conditions
:meteo: meteorological fields

For each :bash:`parameter`, multiple :bash:`parameters` can be defined depending
on diverse species, sectors, etc.






