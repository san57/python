import os
import numpy as np

from pycif.utils.datastores.empty import init_empty


def outputs2native(
        self, data2dump, input_type, di, df, runsubdir,
        mode="fwd", dump=True, onlyinit=False, **kwargs
):
    """Reads outputs to pycif objects.

    If the mode is 'fwd' or 'tl', only observation-like outputs are extracted.
    For the 'adj' mode, all outputs relative to model sensitivity are extracted.

    Dumps to a NetCDF file with output concentrations if needed

    Args:
        self (pycif.utils.classes.models.Model): Model object
        runsubdir (str): current sub-sumilation directory
        mode (str): running mode; one of: 'fwd', 'tl', 'adj'; default is 'fwd'

        dump (bool): dumping outputs or not; default is True
    Return:
        dict

    """

    ddi = min(di, df)
    ddf = max(di, df)

    if not hasattr(self, "dataobs"):
        self.dataobs = {spec: init_empty()
                        for spec in self.chemistry.acspecies.attributes}

    # Read simulated concentrations
    sim_file = "{}/obs_out.bin".format(runsubdir)
    obs_file = "{}/obs.bin".format(runsubdir)
    if not os.path.isfile(sim_file):
        return data2dump

    sim = np.fromfile(sim_file, dtype="float").reshape((-1, 4), order="F")
    obs = np.fromfile(obs_file, dtype="float").reshape((-1, 6), order="F")

    # Observations that were not extracted by LMDZ are set to NaN
    sim[sim == 0] = np.nan

    for trid in data2dump.datastore:
        spec = trid[1]
        dataloc = self.dataobs[spec]

        # Putting values to the local data store
        ind_spec = self.chemistry.acspecies.attributes.index(spec) + 1
        mask = np.floor(obs[:, -1]) == ind_spec
        sim = sim[mask]
        dataloc.loc[:, "sim"] = sim[:, 0]
        dataloc["pressure"] = sim[:, 2]
        dataloc["dp"] = sim[:, 3]

        if mode == "tl":
            dataloc.loc[:, "sim_tl"] = sim[:, 1]

        data2dump.datastore[("concs", spec)]["data"] = dataloc

    return data2dump


