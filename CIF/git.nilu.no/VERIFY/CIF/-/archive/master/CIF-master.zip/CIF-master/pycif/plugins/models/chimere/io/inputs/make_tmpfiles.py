from logging import info
import glob
import os
from pycif.utils import path


def make_tmpfiles(self, runsubdir, mode):
    if mode == "adj":
        if not hasattr(self, "adj_refdir"):
            info(
                "Adjoint CHIMERE couldn't be initialized "
                "with forward TMPconc files"
            )
            raise Exception

        else:
            list_files = glob.glob("{}/chain/TMPconc*".format(self.adj_refdir))

            for tmp_file in list_files:
                root = tmp_file.split("_")[0]
                source = "{}/chain/{}".format(self.adj_refdir, tmp_file)
                target = "{}/{}".format(runsubdir, root)

                path.link(source, target)
