#####################
Time averaging
#####################

.. automodule:: pycif.plugins.transforms.timeavg