###############
Platforms
###############


.. role:: bash(code)
   :language: bash


Available Platforms
=========================

The following :bash:`platforms` are implemented in pyCIF:

.. toctree::
    :maxdepth: 3

    lsce_obelix








