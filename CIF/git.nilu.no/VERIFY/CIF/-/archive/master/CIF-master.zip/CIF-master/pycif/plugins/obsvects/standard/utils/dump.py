import copy
import os
from pycif.utils.datastores.dump import dump_datastore


def dump(obsvect, dir_dump):
    

    datavect = obsvect.datavect
    
    # If no definition is specified for the control vector in the Yaml,
    # return empty control vector
    if not hasattr(datavect, "components"):
        return obsvect

    # Else, carry on initializing
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
    
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
    
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
        
            # Skip tracers that are not control variables
            tracer.isobs = (
                comp in ["concs", "insitu", "flasks", "satellites"]
                or tracer.isobs
            )
            
            if not tracer.isobs:
                continue
            
            ds = copy.deepcopy(tracer.datastore["data"])

            ds["obs"] = obsvect.yobs[tracer.ypointer:
                                     tracer.ypointer + tracer.dim]
            ds["obserror"] = obsvect.yobs_err[tracer.ypointer:
                                     tracer.ypointer + tracer.dim]
            ds["sim"] = obsvect.ysim[tracer.ypointer:
                                     tracer.ypointer + tracer.dim]
            ds["sim_tl"] = obsvect.dy[tracer.ypointer:
                                     tracer.ypointer + tracer.dim]
            
            file_monitor = "{}/{}/{}/monitor.nc".format(
                dir_dump, comp, trcr
            )
            
            dump_datastore(ds, file_monitor, mode="w")
