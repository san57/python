import numpy as np
import xarray as xr
import os

from logging import info, debug
from pycif.utils.path import init_dir
from pycif.utils.datastores.dump import dump_datastore, read_datastore
from .apply_AK import apply_ak
from .apply_AK import apply_ak_tl
from .vinterp import vertical_interp


def forward(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    """Aggregate simulations at the grid scale to total columns.
    Re-interpolate the model pressure levels to the satellite averaging kernel
    levels. Average using the averaging kernel formula

    """
    
    if onlyinit:
        return
    
    datastore = pipe.datastore
    ref_parameter = transf.parameter[0]
    ref_component = transf.component[0]
    
    ref_datastore = datastore[(transf.component[0], transf.parameter[0])]
    ref_ds = ref_datastore["data"]
    target_datastore = datastore[("concs", transf.parameter[0])]["data"]
    
    ddi = min(di, df)
    ref_indexes = ~target_datastore.duplicated(subset=["indorig"])
    y0 = target_datastore.loc[ref_indexes]

    # Building the extended dataframe
    iq1 = y0["station"]
    list_satIDs = iq1.unique()

    ds_p = target_datastore.set_index("indorig")[
        ["pressure", "dp", "airm", "hlay"]]
    for satID in list_satIDs:
        info("Processing satellite: {}".format(satID))
        satmask = iq1 == satID
        nobs = np.sum(satmask)
        # Stacking output datastore into levels * nobs
        native_ind_stack = (
            np.flatnonzero(ref_indexes)[satmask]
            + np.arange(transf.model.domain.nlev)[:, np.newaxis]
        )

        # If all nans in datasim, meaning that the species was not simulated
        sim = target_datastore.loc[:, "sim"].values[native_ind_stack]
        if not np.any(~np.isnan(sim)):
            continue

        # Grouping all data from this satellite
        datasim = xr.Dataset(
            {
                "pressure": (
                    ["level", "index"],
                    np.log(ds_p["pressure"].values[native_ind_stack]),
                ),
                "dp": (
                    ["level", "index"],
                    ds_p["dp"].values[native_ind_stack],
                ),
                "airm": (
                    ["level", "index"],
                    ds_p["airm"].values[native_ind_stack],
                ),
                "hlay": (
                    ["level", "index"],
                    ds_p["hlay"].values[native_ind_stack],
                ),
                "sim": (["level", "index"], sim),
            },
            coords={
                "index": np.arange(nobs),
                "level": np.arange(transf.model.domain.nlev),
            },
        )

        if mode == "tl":
            datasim["sim_tl"] = (
                ["level", "index"],
                target_datastore.loc[:, "sim_tl"].values[native_ind_stack],
            )

        # convert CHIMERE fields to the correct unit
        # from ppb to molec.cm-2 if the satellite product is a column
        if getattr(transf, "product", "level") == "column":
            keys = ["sim"] + (["sim_tl"] if mode == "tl" else [])
            for k in keys:
                datasim[k] *= datasim["hlay"] / (1e9 / datasim["airm"])

        # Check whether there is some ak
        dir_sat = ref_datastore["tracer"].dir
        file_sat = ref_datastore["tracer"].file
        file_aks = "{}/{}".format(dir_sat, file_sat)
        files_aks = ref_datastore["tracer"].input_files[ddi]
        info("Fetching satellite infos from file: {}".format(file_aks))
        
        try:
            colsat = ["qa0", "ak", "pavg0", "date"]
            all_sat_aks = []
            for file_aks in files_aks:
                sat_aks = \
                    read_datastore(file_aks,
                                   col2dump=colsat,
                                   keep_default=False,
                                   to_pandas=False)
                sat_aks["index"] = np.arange(sat_aks.dims["index"])
                if len(all_sat_aks) == 0:
                    all_sat_aks = sat_aks
                else:
                    all_sat_aks = xr.concat([all_sat_aks, sat_aks], "index")

            # Selecting only lines used in simulation
            mask = all_sat_aks["date"].isin(ref_ds["date"]) \
                   & all_sat_aks.index.isin(ref_ds.index)
            sat_aks = all_sat_aks.loc[{"index": mask}]

        except IOError:
            # Assumes total columns?
            raise IOError("Could not fetch "
                          "satellite info from {}".format(file_aks))
            # datastore['qdp'] = datastore['sim'] * datastore['dp']
            # groups = datastore.groupby(['indorig'])
            # y0.loc[:, 'sim'] += \
            #     groups['qdp'].sum().values / groups['dp'].sum().values
            #
            # if 'sim_tl' in datastore:
            #     datastore['qdp'] = datastore['sim_tl'] * datastore['dp']
            #     groups = datastore.groupby(['indorig'])
            #     y0.loc[:, 'sim_tl'] += \
            #         groups['qdp'].sum().values / groups['dp'].sum().values
            #    continue
        
        aks = sat_aks["ak"][:, ::-1].T

        if transf.pressure == "Pa":
            pavgs = sat_aks["pavg0"][:, ::-1].T
        else:
            pavgs = 100 * sat_aks["pavg0"][:, ::-1].T

        coords0 = {"index": np.arange(nobs),
                   "level": np.arange(aks.level.size + 1)}
        coords1 = {"index": np.arange(nobs),
                   "level": np.arange(aks.level.size)}
        dims = ("level", "index")

        pavgs = xr.DataArray(pavgs, coords0, dims).bfill("level")
        pavgs_mid = xr.DataArray(
            np.log(0.5 * (pavgs[:-1].values + pavgs[1:].values)),
            coords1, dims)
        dpavgs = xr.DataArray(np.diff(-pavgs, axis=0), coords1, dims)
        qa0 = sat_aks["qa0"][:, ::-1].T

        # Interpolating simulated values to averaging kernel pressures
        # Doing it by chunk to fasten the process
        # A single chunk overloads the memory,
        # while too many chunks do not take advantage
        # of scipy automatic parallelisation
        # 50 chunks seems to be fairly efficient
        sim_ak = 0.0 * pavgs_mid
        sim_ak_tl = 0.0 * pavgs_mid

        nchunks = getattr(transf, "nchunks", 50)
        chunks = np.linspace(0, nobs, num=nchunks, dtype=int)
        cropstrato = getattr(transf, "cropstrato", False)
        for k1, k2 in zip(chunks[:-1], chunks[1:]):
            debug("Compute chunk for satellite {}: {}-{}".format(satID, k1, k2))

            # Vertical interpolation
            xlow, xhigh, alphalow, alphahigh = vertical_interp(
                datasim["pressure"][:, k1:k2].values,
                pavgs_mid[:, k1:k2].values,
                cropstrato,
            )
            
            # Applying coefficients
            meshout = np.array(pavgs_mid.shape[0] * [list(range(k2 - k1))])
            sim = datasim["sim"][:, k1:k2].values
            sim_ak[:, k1:k2] = (
                alphalow * sim[xlow, meshout] + alphahigh * sim[xhigh, meshout]
            )
            
            if mode == "tl":
                sim_tl = datasim["sim_tl"][:, k1:k2].values
                sim_ak_tl[:, k1:k2] = (
                    alphalow * sim_tl[xlow, meshout]
                    + alphahigh * sim_tl[xhigh, meshout]
                )

        # Correction with the pressure thickness
        # WARNING: there is an inconsistency in the number of levels
        target_datastore["pthick"] = np.nan
        if transf.correct_pthick:
            scale_pthick = (datasim['dp'] * datasim['sim']).sum(axis=0).values \
                      / (dpavgs * sim_ak).sum(axis=0).values \
                      * dpavgs.sum(axis=0).values / datasim['dp'].sum(axis=0).values
            sim_ak *= scale_pthick
            if 'sim_tl' in datasim:
                sim_ak_tl *= scale_pthick
            
            target_datastore.iloc[
                np.flatnonzero(ref_indexes)[satmask],
                target_datastore.columns.get_loc("pthick")] = scale_pthick
            
        # Applying aks
        nbformula = transf.formula
        chosenlevel = getattr(transf, "chosenlev", 0)

        debug("product: {}".format(transf.product))
        debug("nbformula: {}".format(nbformula))
        debug("chosenlev: {}".format(chosenlevel))
        y0.loc[satmask, "sim"] = apply_ak(
            sim_ak, dpavgs, aks.values, nbformula, qa0.values, chosenlevel
        )

        if mode == "tl":
            y0.loc[satmask, "sim_tl"] = apply_ak_tl(
                sim_ak_tl,
                dpavgs,
                aks.values,
                nbformula,
                qa0.values,
                chosenlevel,
                sim_ak,
            )
            
    ref_datastore["data"] = y0
    
    # Save forward datastore for later use by adjoint
    dir_fwd = ddi.strftime("{}/chain/satellites".format(
        transf.model.adj_refdir))
    if not os.path.isdir(dir_fwd):
        init_dir(dir_fwd)
    
    file_monit = ddi.strftime(
        "{}/monit_%Y%m%d%H%M.nc"
            .format(dir_fwd)
    )
    dump_datastore(
        target_datastore,
        file_monit=file_monit,
        dump_default=False,
        col2dump=["pressure", "dp", "indorig", "hlay", "airm", "sim", "pthick"],
        mode="w",
    )
