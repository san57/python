######################
CHIMERE METEO.nc files
######################

.. automodule:: pycif.plugins.meteos.chimere_meteo
