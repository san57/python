import numpy as np
import copy

def sqrtbprod(cntrlv, chi, **kwargs):
    """Multiplies Chi by B**0.5.


    """
    
    datavect = cntrlv.datavect

    # Initializes output vector
    xout = np.zeros(cntrlv.dim)

    # Loop over components of the control vector
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
        
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
        
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
            
            if not tracer.iscontrol:
                continue
            
            x_pointer = tracer.xpointer
            x_dim = tracer.dim
            chi_dim = tracer.chi_dim
            chi_pointer = tracer.chi_pointer
            ndates = tracer.ndates

            # Dealing with non-diagonal spatial B
            if tracer.hresol == "hpixels" and hasattr(tracer, "hcorrelations"):
                corr = tracer.hcorrelations
                hsqrt_evalues = corr.sqrt_evalues
                hevectors = corr.evectors

                # Re-stacking chi to period stacks
                chi_tempstacks = (
                    chi[chi_pointer: chi_pointer + chi_dim]
                        .reshape(tracer.chi_tresoldim,
                                 tracer.chi_vresoldim,
                                 tracer.chi_hresoldim)
                )
                
                # Stack-multiplication of matrices
                # and flattening to control space
                chi_tmp = np.transpose(
                    np.matmul(
                        hevectors * hsqrt_evalues[np.newaxis, :],
                        np.transpose(chi_tempstacks,
                                     axes=(0, 2, 1))),
                    axes=(0, 2, 1)).flatten()
                
                tracer.horiz_chi_tmp = chi_tmp

            else:
                chi_tmp = chi[chi_pointer: chi_pointer + chi_dim]

            # Deals with non-diagonal temporal correlations
            if hasattr(tracer, "tcorrelations"):
                corr = tracer.tcorrelations
                tsqrt_evalues = corr.sqrt_evalues
                tevectors = corr.evectors

                # Re-stacking chi
                chi_horizstacks = (
                    chi_tmp.reshape(tracer.chi_tresoldim,
                                    tracer.chi_vresoldim,
                                    tracer.hresoldim)
                )
                
                # Stack-multiplication of matrices
                # and flattening to control space
                chi_tmp = np.transpose(
                    np.matmul(
                        tevectors * tsqrt_evalues[np.newaxis, :],
                        np.transpose(chi_horizstacks, axes=(1, 0, 2))),
                    axes=(1, 0, 2)).flatten()
                
            # TODO: deal with vertical resolution
            
            # Filling corresponding part in the control vector
            xout[x_pointer: x_pointer + x_dim] = chi_tmp

            tracer.hdx = copy.deepcopy(chi_tmp)

    return xout * cntrlv.std + cntrlv.xb


def sqrtbprod_ad(cntrlv, dx, **kwargs):

    datavect = cntrlv.datavect
    
    # Initializes output vector
    chiout = np.zeros(cntrlv.chi_dim)

    # Loop over components of the control vector
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)

        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
        
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)

            if not tracer.iscontrol:
                continue

            x_pointer = tracer.xpointer
            x_dim = tracer.dim
            chi_pointer = tracer.chi_pointer
            chi_dim = tracer.chi_dim
            ndates = tracer.ndates

            # x * std
            xstd = (
                dx[x_pointer: x_pointer + x_dim]
                * cntrlv.std[x_pointer: x_pointer + x_dim]
            )

            # Dealing with non-diagonal temporal B
            if hasattr(tracer, "tcorrelations"):
                corr = tracer.tcorrelations
                tsqrt_evalues = corr.sqrt_evalues
                tevectors = corr.evectors

                # Re-stacking x to period stacks
                x_horizstacks = (
                    xstd.reshape(ndates,
                                 tracer.vresoldim,
                                 tracer.hresoldim)
                )
                xstd = np.transpose(
                    np.matmul(
                        (tevectors * tsqrt_evalues[np.newaxis, :]).T,
                        np.transpose(x_horizstacks, axes=(1, 0, 2))),
                    axes=(1, 0, 2)).flatten()
                
            # Dealing with non-diagonal spatial B
            if tracer.hresol == "hpixels" and hasattr(tracer, "hcorrelations"):
                corr = tracer.hcorrelations
                hsqrt_evalues = corr.sqrt_evalues
                hevectors = corr.evectors

                # Re-stacking x to horizontal stacks
                x_tempstacks = xstd.reshape(
                    (tracer.hresoldim, tracer.vresoldim, tracer.chi_tresoldim),
                    order="F"
                )

                # Stack-multiplication of matrices
                # and flattening to control space
                xstd = np.transpose(
                    np.matmul(hevectors.T * hsqrt_evalues[:, np.newaxis],
                              np.transpose(x_tempstacks, axes=(1, 0, 2))),
                    axes=(1, 0, 2)).flatten(order="F")

            # Filling Chi
            chiout[chi_pointer: chi_pointer + chi_dim] = xstd

    return chiout
