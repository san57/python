def forward(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        do_simu=True,
        onlyinit=False,
        **kwargs
):
    if not onlyinit:
        transform.model.run(runsubdir, mode, workdir, do_simu=do_simu, **kwargs)
    
