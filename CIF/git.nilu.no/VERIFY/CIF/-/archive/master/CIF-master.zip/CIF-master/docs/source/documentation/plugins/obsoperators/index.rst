####################
Observation operator
####################

.. role:: bash(code)
   :language: bash


Observation operators compute the operation
:math:`\mathbf{x} \rightarrow \mathcal{H}(\mathbf{x})` and its adjoint
if necessary. This operation relies on simulations by the chosen
numerical model, which are automatically initialized, articulated and
chained with each other by the observation operator.



Available Observation operators
===============================

The following :bash:`obsoperator` are implemented in pyCIF:

.. toctree::

    standard

