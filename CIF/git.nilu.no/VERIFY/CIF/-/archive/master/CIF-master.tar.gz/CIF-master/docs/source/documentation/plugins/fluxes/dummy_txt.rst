#####################
CHIMERE - text
#####################

.. automodule:: pycif.plugins.fluxes.dummy_txt