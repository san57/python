from .execute import execute

from pycif.utils import path

_name = "EnKF"

requirements = {
    "obsvect": {
        "any": True,
        "empty": False,
        "name": "standard",
        "version": "std",
    },
    "controlvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "obsoperator": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "platform": {
        "any": True,
        "empty": True
    },
}

input_arguments = {
    "nsample": {
        "doc": "Number of random samples in the ensemble",
        "default": None,
        "accepted": int
    },

    "reload_results": {
        "doc": "Reload results from previous simulations",
        "default": False,
        "accepted": bool
    }

}


def ini_data(plugin, **kwargs):
    workdir = getattr(plugin, "workdir", "./")

    # Initializes the directory
    path.init_dir("{}/ensemble".format(workdir))
    path.init_dir("{}/ensemble/".format(workdir))
