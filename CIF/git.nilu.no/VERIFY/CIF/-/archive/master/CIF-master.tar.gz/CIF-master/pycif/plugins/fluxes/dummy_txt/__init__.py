from .fetch import fetch
from .make import make
from .read import read
from .write import write

_name = "dummy"
_version = "txt"

requirements = {"domain": {"name": "dummy", "version": "std", "empty": False}}


input_arguments = {
    "file": {
        "doc": "File format for the fluxes",
        "default": "dummy_flx.txt",
        "accepted": str
    }
}



