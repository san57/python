The yaml below defines a chemical scheme for the oxidation of methane by OH, O(1D) and Cl by Joël Thanwerdas.


.. literalinclude:: ch4_scheme.yml
    :linenos:
    :language: yaml


