import copy
import xarray as xr


def adjoint(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    
    xmod = pipe.datastore

    inputs = transf.parameters_in.names
    outputs = transf.parameters_out.names
    in_types = transf.component
    iso_mass = transf.parameters_out.iso_mass
    spec_mass = transf.parameters_out.spec_mass
    unit = transf.unit

    noutputs = len(outputs)
    out_types = noutputs * [transf.component[-1]]
    r_stds = {sign: getattr(transf.parameters_out, sign).standard for sign in inputs[:-1]}

    trid_out = (out_types[0], outputs[0])
    for trid in mapper["inputs"]:
        xmod[trid] = {k: xmod[trid_out][k] for k in xmod[trid_out]}
        if not onlyinit:
            xmod[trid]["adj_out"] = copy.deepcopy(xmod[trid_out]["adj_out"])

    if onlyinit:
        # Delete the useless inputs
        for trid in mapper["outputs"]:
            del xmod[trid]
        return
    
    # Fet fwd data
    file_fwd_dataset = ddi.strftime("{}/chain/{}_fwd_%Y%m%d%H%M.nc".
                                    format(transf.model.adj_refdir, transf.orig_name))

    fwd_dataset = xr.open_dataset(file_fwd_dataset)
    spec_data = fwd_dataset["spec"].values
    signatures = {sign: fwd_dataset[sign].values for sign in inputs[:-1]}

    a_factors = {sign: (1 + signatures[sign] / 1000) * r_stds[sign]
                 for sign in inputs[:-1]}
    isotopologue_adj = {output: xmod[(out_type, output)]["adj_out"]
                        for (out_type, output) in zip(out_types, outputs)}

    # Mass correction if units are in mass
    if unit == "mass":
        for i, iso in enumerate(isotopologue_adj.keys()):
            isotopologue_adj[iso] *= iso_mass[i] / spec_mass

    # Sensitivity to total
    total_sensitivity = 0 * xmod[(in_types[-1], inputs[-1])]["adj_out"]
    for ioutput, (out_type, output) in enumerate(zip(out_types, outputs)):
        total_multip = isotopologue_adj[output].copy()

        # multiplication terms for each signature
        for isign, sign in enumerate(inputs[:-1]):
            t = noutputs // (2 ** (isign + 1))
            num_group = ioutput // t

            if num_group % 2:
                total_multip *= a_factors[sign] / (1 + a_factors[sign])
            else:
                total_multip *= 1 / (1 + a_factors[sign])

        total_sensitivity += total_multip
    xmod[(in_types[-1], inputs[-1])]["adj_out"] = total_sensitivity.copy()

    # Sensitivity to signatures
    for isign, sign in enumerate(inputs[:-1]):
        signature_sensitivity = 0 * xmod[(in_types[0], sign)]["adj_out"]
        for ioutput, (out_type, output) in enumerate(zip(out_types, outputs)):
            total_multip = isotopologue_adj[output].copy()
            # multiplication terms for each signature increment
            for isign_times, sign_times in enumerate(inputs[:-1]):
                t = noutputs // (2 ** (isign_times + 1))
                num_group = ioutput // t
                if isign_times == isign:
                    if num_group % 2:
                        total_multip *= (
                                r_stds[sign_times]
                                / 1000
                                / (1 + a_factors[sign_times]) ** 2
                        )
                    else:
                        total_multip *= (
                            - r_stds[sign_times]
                            / 1000
                            / (1 + a_factors[sign_times]) ** 2
                        )
                else:
                    if num_group % 2:
                        total_multip *= (
                            a_factors[sign_times] / (1 + a_factors[sign_times])
                        )
                    else:
                        total_multip *= 1 / (1 + a_factors[sign_times])
            signature_sensitivity += total_multip * spec_data
        xmod[(in_types[0], sign)]["adj_out"] = signature_sensitivity.copy()

    # Delete the useless inputs
    for trid in mapper["outputs"]:
        del xmod[trid]
        
    pipe.datastore = xmod
