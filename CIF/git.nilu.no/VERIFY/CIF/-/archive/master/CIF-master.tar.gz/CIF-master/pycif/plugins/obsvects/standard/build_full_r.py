import numpy as np


def build_r(obsvect, **kwargs):
    
    datavect = obsvect.datavect
    rfull = np.eye(obsvect.dim)
    
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)

        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue

        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)

            # Skip tracers that are not control variables
            if not tracer.isobs:
                continue
            
            rfull[tracer.ypointer: tracer.ypointer + tracer.dim,
                  tracer.ypointer: tracer.ypointer + tracer.dim] *= \
                obsvect.yobs_err[tracer.ypointer:
                                 tracer.ypointer + tracer.dim] ** 2
            
    return rfull
            