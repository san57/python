import os
import errno # used in silent_remove
import sys
from datetime import datetime, timedelta
import shutil
import subprocess
import glob

# Logging functions in order of increasing severity:
#    debug, info, warning, error, critical
# A local logger instance is used in run(...) for development purposes, but
# it could also be initialised after the import statement. More info:
# *) https://docs.python.org/3.7/library/logging.html
# *) https://docs.python.org/3.7/howto/logging.html
# *) https://stackoverflow.com/a/48787602
import logging


def silent_remove(filename):
    """
    PURPOSE
    Delete a file without raising an exception if it doesn't exist.

    IN/OUT
    filename = string with the filename to remove.

    VERSION CHANGE HISTORY
    1.0 09-11-2020 by J.C.A. van Peet.
        Copied from https://stackoverflow.com/a/10840586, changed function
        name from silentremove to silent_remove.
    """
    try:
        os.remove(filename)
    except OSError as e: # this would be "except OSError, e:" before Python 2.6
        if e.errno != errno.ENOENT: # errno.ENOENT = no such file or directory
            raise # re-raise exception if a different error occurred
        # end if
    # end try-except

# end function silent_remove



def run(self, runsubdir, mode, workdir, **kwargs):
    """
    PURPOSE
    Call this function to run the TM5 model. I'm not sure which module does call
    this function...

    IN/OUT
    runsubdir = working directory for the current run (str)
    mode      = forward or backward                   (str)
    workdir   = pyCIF working directory               (str)

    KWARGS
    none

    ASSUMPTIONS
    none

    EXCEPTIONS
    When this function encounters a problem that it cannot solve,
    it will raise a RuntimeError. Pythons exeception handling will
    provide a traceback, including files, calls and line numbers.

    PYTHON VERSION
    3.7.6

    VERSION CHANGE HISTORY
    1.0 09-11-2020 by J.C.A. van Peet.
        Original code.
    """

    # Name of the program
    PROG_NAME = "run.py, run(...)"

    # Local logger
    # Logging functions in order of increasing severity:
    #    debug, info, warning, error, critical
    # See https://stackoverflow.com/a/48787602 and import statement above for
    # more info.
    # Notes:
    # *) you do not need a verbosity variable ("verb") anymore, nor
    #    "if( verb ):" statements.
    # *) to get the local level value and name, use
    #       logger.critical("Local logging level  = "+str(logger.level))
    #       logger.critical("Local logging name   = "+str(logging.getLevelName(logger.level)) )
    # *) to get the global level value and name, use
    #       logger.critical("Global logging level = "+str(logging.getLogger().level))
    #       logger.critical("Global logging name  = "+str(logging.getLevelName(logging.getLogger().level)) )
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG) # Lowest level possible
    #logger.setLevel(logging.getLogger().level) # Global logging level



    # ************************************
    # * NO MORE SETTINGS BELOW THIS LINE *
    # ************************************


    # Start message
    logger.debug("")
    logger.debug(PROG_NAME+" => start")

    # Print the Wall Time Before Run
    wtbr = datetime.now()
    logger.debug(PROG_NAME+" => wall time before run = "+wtbr.strftime("%Y-%m-%dT%H:%M:%S"))

    # Debug information
    logger.info   (PROG_NAME+" => info")
    logger.info   ("   runsubdir = %s" % (runsubdir) )
    logger.info   ("   mode      = %s" % (mode     ) )
    logger.info   ("   workdir   = %s" % (workdir  ) )
    logger.warning("Empty run method for model TM5")
    logger.critical("STOP THE PRESS!!!")

    # Remove already existing log and ok files
    silent_remove("{}/tm5.ok".format(runsubdir))
    silent_remove("{}/tm5.log".format(runsubdir))


    # Logging an exception?
    logger.exception("WHATEVER")
    # Google: python logging raise exception
    # see https://realpython.com/the-most-diabolical-python-antipattern/



    # Run TM5
    logger.info("Running sub-simulation in {}".format(runsubdir))
    with open("{}/tm5.log".format(runsubdir), "w") as log:
        process = subprocess.Popen(
            ["tm5.exe", "tm5.rc"],
            cwd=runsubdir,
            stdout=log,
            stderr=subprocess.PIPE
        )
        _, stderr = process.communicate()
    # end with

    # Raise exception if TM5 did not run successfully.
    if stderr != "" and not os.path.isfile("{}/tm5.ok".format(runsubdir)):
        logger.info("Exception in TM5")
        logger.info(str(stderr, "utf-8"))
        raise Exception(
            "TM5 did not run properly in {}".format(runsubdir)
        )
    # end if

    # Print the Wall Time After Run
    wtar = datetime.now()
    logger.debug(PROG_NAME+" => wall time after run = "+wtar.strftime("%Y-%m-%dT%H:%M:%S"))
    logger.debug(PROG_NAME+" => wall time delta     = %s" % (wtar-wtbr)                   )

    # Stop message
    logger.debug(PROG_NAME+" => stop")
    logger.debug("")

# end function run
