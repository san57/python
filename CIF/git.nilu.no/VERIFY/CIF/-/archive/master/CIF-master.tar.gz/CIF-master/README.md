
"pycif" is a Python package to compute inversions mainly 
with different inversion methods, models and data streams

To make your working copy known to your python session, you
can install a local development version using:

```
python setup.py develop --user
```

which will "compile" the code locally but creates a link in
your local library folder. The link can be removed with:

```
python setup.py develop --user -u
```
