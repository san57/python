input_arguments = {
    "autoflush": {
        "doc": "Cleans big temporary files when the simulation is done. "
               "Triggers the function ``flushrun`` of the model if available",
        "default": False,
        "accepted": bool
    }
}