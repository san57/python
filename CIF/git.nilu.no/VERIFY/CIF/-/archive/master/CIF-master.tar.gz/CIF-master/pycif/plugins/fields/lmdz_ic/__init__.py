from .read import read
from .write import write

_name = "LMDZ"
_version = "ic"

requirements = {"domain": {"name": "LMDZ", "version": "std", "empty": False}}
