#####################
EDGAR v5
#####################

.. automodule:: pycif.plugins.fluxes.edgar_v5