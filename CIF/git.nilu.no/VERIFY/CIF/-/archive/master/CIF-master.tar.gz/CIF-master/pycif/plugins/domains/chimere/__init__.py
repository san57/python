from .read_domain import read_grid

_name = "CHIMERE"

input_arguments = {
    "repgrid": {
        "doc": "Path to the directory where the COORD files are to be found",
        "default": None,
        "accepted": str
    },

    "domid": {
        "doc": "Name of the domain",
        "default": None,
        "accepted": str
    },

    "nlev": {
        "doc": "Number of vertical levels",
        "default": None,
        "accepted": int
    } ,

    "p1": {
        "doc": "Pressure at the top of the first layer",
        "default": None,
        "accepted": float
    },

    "pmax": {
        "doc": "Pressure at the top of the domain",
        "default": None,
        "accepted": float
    },

    "emissublayer": {
        "doc": "Use a sub-layer for surface emissions",
        "default": 0,
        "accepted": bool
    },
}


