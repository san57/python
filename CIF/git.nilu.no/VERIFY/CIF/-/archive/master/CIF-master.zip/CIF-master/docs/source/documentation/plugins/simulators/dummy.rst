#####################
Dummy cost function
#####################

.. automodule:: pycif.plugins.simulators.dummy