####################
Data vectors
####################

.. role:: bash(code)
   :language: bash

Description
===========

The :bash:`datavect` class in pyCIF contains all information
about the configuration inputs.
It includes observations, model inputs, emission fluxes, etc.

Available Data vectors
=========================

The following :bash:`datavects` are implemented in pyCIF:

.. toctree::

    standard

