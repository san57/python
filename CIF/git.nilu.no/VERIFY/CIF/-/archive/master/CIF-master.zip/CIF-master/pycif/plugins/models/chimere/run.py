import datetime
import os
import shutil
import subprocess
import glob

from logging import info


def run(self, runsubdir, mode, workdir, nbproc=1, do_simu=True, **kwargs):
    """Run the CHIMERE model in forward mode

    Args:
        self: the model Plugin
        runsubdir (str): working directory for the current run
        mode (str): forward or backward
        workdir (str): pyCIF working directory
        do_simu (bool): re-run or not existing simulation

    """
    
    # Resetting observation flag for updating obs.txt
    self.iniobs = False
    self.reset_obs = True
    
    if not do_simu:
        if mode in ["fwd", "tl"]:
            # Keeps the running directory in memory for later adjoint
            # simulations
            self.adj_refdir = "{}/../".format(runsubdir)
        return

    # Cleaning the directory
    shutil.rmtree("{}/mod.txt".format(runsubdir), ignore_errors=True)
    
    # Getting TMP files if required
    # if mode == "adj":
    #     os.system(
    #          "mv -f {}/TMPconc* {}".format(
    #                 runsubdir.replace('tor/adj_','tor/tl_'), runsubdir
    #           )
    #     )

    # Number of processors
    nbproc = str(self.nzdoms * self.nmdoms + 1)
    
    # Running the model
    info("Running sub-simulation in {}".format(runsubdir))
    with open("{}/chimere.log".format(runsubdir), "w") as log:
        process = subprocess.Popen(
            ["mpirun"]
            + getattr(self, "run_options")
            + ["-np", nbproc, "chimere.e"],
            cwd=runsubdir,
            stdout=log,
            stderr=subprocess.PIPE
        )
        _, stderr = process.communicate()

    if stderr != "" and not os.path.isfile("{}/all_good".format(runsubdir)):
        info("Exception in CHIMERE")
        info(str(stderr, "utf-8"))
        raise Exception(
            "CHIMERE did not run properly in {}".format(runsubdir)
        )

    # Process here initial conditions for the next simulation
    date = datetime.datetime.strptime(
        os.path.basename(runsubdir), "%Y-%m-%d_%H-%M"
    )
    nho = self.nho
    if mode in ["fwd", "tl"]:
        os.system(
            date.strftime(
                "mv -f {}/end.nc {}/../chain/end.%Y%m%d%H.{}.nc".format(
                    runsubdir, runsubdir, nho
                )
            )
        )

        # Keeps the running directory in memory for later adjoint simulations
        self.adj_refdir = "{}/../".format(runsubdir)

        # Saves TMP files if available
        if self.write_for_adjoint:
            list_file = glob.glob("TMPconc*")
            for tmp_file in list_file:
                shutil.move(
                    "{}/{}".format(runsubdir,tmp_file),
                    date.strftime(
                        "{}/../chain/{}_%Y%m%d%H%M".format(
                            runsubdir, tmp_file
                        )
                    ),
                )

