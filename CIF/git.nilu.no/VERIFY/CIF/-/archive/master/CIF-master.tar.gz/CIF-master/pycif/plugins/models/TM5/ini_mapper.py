def ini_mapper(model, inputs={}, outputs={}, backup_comps={}):
    """
    PURPOSE
    The ini_mapper function is mandatory to make a model work. It informs pycif
    about the inputs and outputs of the model. It should return a so-called
    "mapper". A mapper is a dictionary with two keys:
       *) inputs: all the inputs for the model (fluxes, meteo, chemical fields,
          executables, parameter files, etc)
       *) outputs: all the outputs; in our cases, concentrations (concs)

    Both inputs and outputs keys are them selves dictionaries. Their format is:
       *) ("type", "parameter"): {information dictionary}
    The pair ("type", "parameter") should cover all the necessary inputs
    and outputs. In the case when no "parameter" is relevant, and empty string
    can be specified.

    The information dictionary can include the following information, depending
    on your model:
       *) input_dates: all dates at which the model expects some inputs for the
          given type/parameter; e.g., if TM5 needs 3-hourly meteo fields,
          input_dates will be the list of all dates in the simulation period with
          a frequency of 3H; it is recommended to initiate this variable in the
          function ini_periods, that initiates all date related variables for your
          model
       *) domain: usually the same as the model domain
       *) force_dump: True if the given type/parameter should be dumped before
          running the model executable
       *) any other parameter that can be used in the native2inputs / outputs2native
       functions.

    IN/OUT
    none

    KWARGS
    none

    ASSUMPTIONS
    none

    EXCEPTIONS
    When this function encounters a problem that it cannot solve,
    it will raise a RuntimeError. Pythons exeception handling will
    provide a traceback, including files, calls and line numbers.

    PYTHON VERSION
    3.7.5

    VERSION CHANGE HISTORY
    1.0 18-09-2020 by J.C.A. van Peet.
        Original code.
    """

    # For now, define an empty mapper
    mapper = {
        "inputs": {},
        "outputs": {}
    }
    
    # Should look like something:
    # Input keys are used in io/mative2inputs
    # Output keys are used in io/output2native
    default_dict = {"input_dates": model.input_dates, "force_dump": True}
    dict_surface = dict(default_dict, **{"domain": model.domain})
    
    mapper = {
        "inputs": {
            ("exe", ""): default_dict,
            ("param", ""): default_dict, # Some parameter file?
            ("meteo", ""): default_dict, # Meteo files
            ("fluxes", "CH4"): default_dict, # emission file
            ("chemistry", "CH4"): default_dict, # Source/sink files
            ("inicond", "CH4"): default_dict, # Source/sink files
        },
        "outputs": {
            ("concs", s): {} for s in ["CH4"] # Make it more general later
        },
    }
    
    # Return the mapper
    return mapper

# end def ini_mapper

