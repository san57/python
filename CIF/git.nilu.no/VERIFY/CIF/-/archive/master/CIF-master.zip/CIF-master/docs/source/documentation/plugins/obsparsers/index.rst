#####################
Observation parsers
#####################

.. role:: bash(code)
   :language: bash


Available Observation Parsers
================================

The following :bash:`obsparsers` are implemented in pyCIF:

.. toctree::

    wdcgg
