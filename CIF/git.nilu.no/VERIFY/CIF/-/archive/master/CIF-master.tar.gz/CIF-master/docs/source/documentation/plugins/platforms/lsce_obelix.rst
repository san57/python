#####################
Obelix cluster at LSCE
#####################

.. automodule:: pycif.plugins.platforms.lsce_obelix
