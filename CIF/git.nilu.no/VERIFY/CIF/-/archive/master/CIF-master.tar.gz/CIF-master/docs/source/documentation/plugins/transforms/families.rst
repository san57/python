########################################
Species families or sectoral aggregation
########################################

.. automodule:: pycif.plugins.transforms.families