
.. code-block:: yaml

    verbose: 2
    workdir: /SOME/WORKING/DIRECTORY
    controlvect:
      plugin:
        name: standard
        version: std
      save_out_netcdf: true
      transform_pipe:
        trans1:
          component: fluxes
          parameter_out: CH4
          parameters_in:
          - CH4_ref
          - CH4_perturb
          plugin:
            name: families
            type: transform
            version: std
    datavect:
      components:
        concs:
          parameters:
            CH4:
              duration: 2H
              frequency: 1H22min
              nstations: 50
              plugin:
                name: random
                type: measurements
                version: param
              random_subperiod_shift: true
              seed: true
              zmax: 100
        fluxes:
          parameters:
            CH4:
              err: 1
              errtype: max
              file: flx_real.txt
              flx_formula: &id003
              - product:
                - sum:
                  - cos: null
                    period: 500
                    variable: zlat
                  - period: 1000
                    sin: null
                    variable: zlon
                - sum:
                  - period: 1000
                    square: null
                    variable: zlat
                  - period: 1000
                    square: null
                    variable: zlon
              hcorrelations:
                dump_hcorr: true
                evalmin: 0
                landsea: false
                sigma: 500
              hresol: hpixels
              nlev: 1
              period: 5D
              plugin: &id002
                name: dummy
                type: fluxes
                version: txt
              vresol: vpixels
            CH4_perturb:
              err: 1
              errtype: max
              file: flx_real.txt
              flx_formula:
              - sum:
                - cos: null
                  period: 200
                  variable: zlat
                - period: 300
                  sin: null
                  variable: zlon
              hcorrelations: *id001
              hresol: hpixels
              nlev: 1
              period: 5D
              plugin: *id002
              vresol: vpixels
              xb_scale: 0.2
            CH4_ref:
              err: 1
              errtype: max
              file: flx_real.txt
              flx_formula: *id003
              hcorrelations: *id001
              hresol: hpixels
              nlev: 1
              period: 5D
              plugin: *id002
              vresol: vpixels
        meteo:
          dir: CIF_ROOT/data/dummy_gauss/
          file: meteo2.csv
          plugin:
            name: dummy
            type: meteo
            version: csv
          resolution: 1H
          seed: true
      plugin:
        name: standard
        version: std
    datef: 2010-01-05
    datei: 2010-01-01
    domain:
      nlat: 15
      nlon: 30
      plugin:
        name: dummy
        version: std
      xmax: 2500
      xmin: 0
      ymax: 2000
      ymin: 0
    logfile: pycif.logtest
    mode:
      obserror: 0.01
      perturb_obsvect: true
      plugin:
        name: forward
        version: std
    model:
      chemistry:
        acspecies:
          CH4: null
      file_pg: CIT_ROOT/model_sources/dummy_gauss/Pasquill-Gifford.txt
      plugin:
        name: dummy
        version: std
    obsvect:
      dir_obsvect: WHERE/TO/DUMP/COMPARISON/TO/OBS
      dump_type: nc
      plugin:
        name: standard
        version: std
