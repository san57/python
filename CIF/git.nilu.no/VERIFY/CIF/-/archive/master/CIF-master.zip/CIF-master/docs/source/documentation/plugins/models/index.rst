###############
Models
###############

.. role:: bash(code)
   :language: bash


.. contents:: Contents
    :local:

Description
===========

The :bash:`model` class runs chemistry-transport models, process their outputs
and generates their inputs.
Please note that models are often computed with high-performance languages
such as Fortran or C.
In these case, the sources are included in the directory ``model_sources``
provided alongside pyCIF.


Available Models
================

The following :bash:`models` are implemented in pyCIF:

.. toctree::

    dummy
    chimere
    lmdz
    flexpart


Required parameters, dependencies and functions
===============================================

The following attributes, dependencies and functions should be defined for any :bash:`model`, as they are called by other plugins.
They can be parameters to define at the set-up step, functions to implement in the corresponding module, or dependencies to be attached to the :bash:`model` class.

Parameters and attributes
+++++++++++++++++++++++++

Initialization parameters
-------------------------

The following attributes are defined once for all at the initialization of the model,
they inform pyCIF about the temporal resolution of the model.
All the following objects are filled with `datetime.datetime <https://docs.python.org/fr/3/library/datetime.html>`__ objects.
To make the handling of lists easier, pyCIF requires lists to be implemented as `numpy.array <https://numpy.org/doc/stable/reference/generated/numpy.array.html>`__


:``subsimu_dates``: the list of simulation periods if the model simulation window is split into shorter sub-periods

:``tstep_dates``: the time-steps at which the model carries out its numerical computations; this argument is used by pyCIF to determine which observation to compare to what model time step.
        The shape of this argument is a dictionary, whose keys are ``subsimu_dates`` and entries are the lists of time-steps corresponding to each sub-period.

:``tstep_all``: the same as ``tstep_dates``; the difference is that ``tstep_all`` is a list containing ``all`` time steps of all simulation sub-periods instead of a dictionary split into sub-periods

:``input_dates``: dates at which the model expects some inputs; has the same shape as ``tstep_dates``

Please find below an illustration of the different time steps:

.. graphviz:: time_steps.dot
    :align: center

In the example, the model is run between January 1st, 2010 to February 28th, 2010.
Computations are carried out every hours and inputs are expected every 3 hours.
In that case, the temporal variables are:

.. code-block:: python

    import numpy as np

    subsimu_dates = np.array([datetime.datetime(2010, 1, 1), datetime.datetime(2010, 2, 1)])

    tstep_dates = {
        datetime.datetime(2010, 1, 1): np.array(
            [datetime.datetime(2010, 1, 1, 0), datetime.datetime(2010, 1, 1, 1),
             ..., datetime.datetime(2010, 1, 31, 23)]),
        datetime.datetime(2010, 2, 1): np.array(
            [datetime.datetime(2010, 2, 1, 0), datetime.datetime(2010, 2, 1, 1),
             ..., datetime.datetime(2010, 2, 28, 23)]),
    }

    tstep_all = np.array([
        datetime.datetime(2010, 1, 1, 0), datetime.datetime(2010, 1, 1, 1),
        ..., datetime.datetime(2010, 2, 28, 23)
    ])

    input_dates = {
        datetime.datetime(2010, 1, 1): np.array(
            [datetime.datetime(2010, 1, 1, 0), datetime.datetime(2010, 1, 1, 3),
             ..., datetime.datetime(2010, 1, 31, 21)]),
        datetime.datetime(2010, 2, 1): np.array(
            [datetime.datetime(2010, 2, 1, 0), datetime.datetime(2010, 2, 1, 3),
             ..., datetime.datetime(2010, 2, 28, 21)]),
    }

Online parameters
-----------------

The following variables are defined online during the computation of the model.

:``chain``: for a given model simulation, files from previous sub-periods necessary to run following sub-periods are stored in ``current_sim_directory/chain``;
        the ``chain`` variable stores the date of the previous sub-period that was computed;
        the variable is automatically updated by the :bash:`obsoperator`, but the files should be moved by the function :bash:`run` of the model.

:``adj_refdir``: this is the directory where forward simulations corresponding to the adjoint being run are stored; the variable should be updated when running a forward in the :bash:`run` function.

Dependencies
++++++++++++

Some other classes in pyCIF expect the :bash:`model` class to have a :bash:`domain` class attached to it, describing the model domain.
This way, :bash:`model.domain` can be called.

Functions
+++++++++

The following functions need to be implemented in any model to make it interact with other classes.
They must be imported at the root level of the corresponding python package, i.e. in the ``__init__.py`` file:

.. code-block:: python

    from XXXXX import ini_periods
    from XXXXX import run
    from XXXXX import native2inputs
    from XXXXX import native2inputs_adj
    from XXXXX import outputs2native
    from XXXXX import outputs2native_adj
    from XXXXX import compile
    from XXXXX import ini_mapper

It is recommended to include each function in a separate file to avoid very long
scripts.


ini_periods (optional)
----------------------

The function :bash:`ini_periods` is optional but very recommended.
It is used to define the temporal variables ``subsimu_dates``, ``input_dates``, ``tstep_dates`` and ``tstep_all``.
The function is automatically called at the initialization of the :bash:`model` class if available.
If not available, the temporal variables should be defined manually in the :bash:`ini_data` function (not recommended).

:bash:`ini_periods` is a class method that applies to the :bash:`model` plugin itself.
Therefore, the only expected argument is :bash:`self`.

.. code-block:: python

    def ini_periods(self, **kwargs):

        self.subsimu_dates = XXXX
        self.tstep_dates = XXXXX
        self.input_dates = XXXXX
        self.tstep_all = XXXXX

Click below to see an example of the :bash:`ini_periods` function for the model CHIMERE.

.. module:: pycif.plugins.models.chimere
    :noindex:

.. function:: ini_periods


run
---

The function :bash:`run` executes the model itself.
As models are often computationally expensive to run, they are not written in python.
Therefore, the :bash:`run` function calls an external executable compiled previously.

There are several ways to call system executables in python.
We recommend using the function `subprocess.Popen <https://docs.python.org/fr/3/library/subprocess.html#subprocess.Popen>`__ for that purpose.
It gives flexibility in logging and can capture errors during the execution of the external executable.

Other tasks carried out by the :bash:`run` function are:

* update the variable :bash:`self.adj_refdir` for later adjoint simulations
* update the variable :bash:`self.chain` for later sub-periods and move necessary files to that directory;
        these files include for instance concentration fields at the last time step of the period, to be used as initial conditions for the next period.

Arguments are:

:self: the model itself
:runsubdir: the sub-directory where the sub-period needs to be run
:mode: the running mode; one of ``fwd``, ``tl`` or ``adj`` for forward, tangent-linear and adjoint respectively
:workdir: the root working directory of the present CIF computation
:do_simu: carry out or not the simulation; pyCIF can read previously computed simulations and skip the execution of the code; this behaviour should be specified

The functions returns nothing.

Example of code:

.. code-block:: python

    import subprocess
    import os

    def run(self, runsubdir, mode, workdir, do_simu=True, **kwargs):

        if not do_simu:
            if mode in ["fwd", "tl"]:
                self.adj_refdir = "{}/../".format(runsubdir)
            return

        with open("{}/log.std".format(runsubdir), "w") as log:
            process = subprocess.Popen(
                "run my executable",
                cwd=runsubdir,
                stdout=log,
                stderr=subprocess.PIPE
            )
            _, stderr = process.communicate()

        if stderr != "":
            print("Deal with exception in executable")

        if mode in ["fwd", "tl"]:
            # Adj_refdir is not the runsubdir itself (which corresponds to a sub-simulation
            # But the level above, which is the full chained simulation
            self.adj_refdir = "{}/../".format(runsubdir)

        # Now move necessary files to the chain directory
        os.system("mv -f {runsubdir}/XXXXX {runsubdir}/../chain/XXX"
                  .format(runsubdir=runsubdir))

Click below for a full example of the :bash:`run` function for the model CHIMERE.

.. function:: run


native2inputs and native2inputs_adj
-----------------------------------

The functions :bash:`native2inputs` and :bash:`native2inputs_adj` generate inputs for the model executable
and reads sensitivity to the inputs as computed by the adjoint respectively.




outputs2native and outputs2native_adj
-------------------------------------

The functions :bash:`outputs2native` and :bash:`outputs2native_adj`
read outputs and generate sensitivity to the outputs respectively.


ini_mapper
----------


compile (optional)
------------------


flushrun (optional)
-------------------

The function :bash:`flushrun` is called at the end of a simulations.
It cleans all temporary files that take disk space and are not necessary afterwards.

Arguments are:

:self: the model itself
:rundir: the run directory (with all the sub-period simulations)
:mode: the running mode; one of ``fwd``, ``tl`` or ``adj``.

The function returns nothing.

Click below for a full example of the :bash:`flushrun` function for the model CHIMERE.

.. function:: flushrun






