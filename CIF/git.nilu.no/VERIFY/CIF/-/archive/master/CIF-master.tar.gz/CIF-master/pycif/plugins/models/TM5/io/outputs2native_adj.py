from .inputs.make_obs import make_obs


def outputs2native_adj(
        self, data2dump, input_type, di, df, runsubdir, mode="fwd",
        dump=True, onlyinit=False, do_simu=True, **kwargs
):
    """Produce the point_observation file prior to the simulation"""

    ddi = min(di, df)

    for trid in data2dump:
        mod_input = trid[0]
        trcr = trid[1]
        
        if mod_input != "concs":
            continue
        
        if "data" in data2dump[trid]:
            make_obs(self, data2dump[trid]["data"],
                     runsubdir, "fwd", trcr, do_simu)
