List of all available plugins and requirements for each class:


	 :doc:`minimizer<minimizers/index>`
		- :doc:`congrad, std<minimizers/congrad>`
			Requires:
				- :doc:`simulator<simulators/index>`:
					- name: gausscost
					- version: std
					- any: True
					- empty: True
		- :doc:`M1QN3, std<minimizers/m1qn3>`
			Requires:
				- :doc:`simulator<simulators/index>`:
					- name: gausscost
					- version: std
					- any: True
					- empty: True


	 :doc:`model<models/index>`
		- :doc:`TM5, std<models/TM5>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False
				- :doc:`chemistry<chemistries/index>`:
					- name: TM5
					- version: SINK-TIPP
					- any: False
					- empty: False
				- :doc:`fluxes<fluxes/index>`:
					- name: TM5
					- version: std
					- any: False
					- empty: True
				- :doc:`meteo<meteos/index>`:
					- name: TM5
					- version: std
					- any: False
					- empty: True
				- :doc:`inicond<fields/index>`:
					- name: TM5
					- version: ic
					- any: False
					- empty: True
		- :doc:`CHIMERE, std<models/chimere>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: CHIMERE
					- version: std
					- any: False
					- empty: False
				- :doc:`chemistry<chemistries/index>`:
					- name: CHIMERE
					- version: gasJtab
					- any: False
					- empty: False
				- :doc:`fluxes<fluxes/index>`:
					- name: CHIMERE
					- version: AEMISSIONS
					- any: False
					- empty: True
				- :doc:`biofluxes<fluxes/index>`:
					- name: CHIMERE
					- version: AEMISSIONS
					- any: False
					- empty: True
				- :doc:`meteo<meteos/index>`:
					- name: CHIMERE
					- version: std
					- any: False
					- empty: True
				- :doc:`latcond<fields/index>`:
					- name: CHIMERE
					- version: icbc
					- any: False
					- empty: True
				- :doc:`topcond<fields/index>`:
					- name: CHIMERE
					- version: icbc
					- any: False
					- empty: True
				- :doc:`inicond<fields/index>`:
					- name: CHIMERE
					- version: icbc
					- any: False
					- empty: True
		- :doc:`dummy, std<models/dummy>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False
				- :doc:`fluxes<fluxes/index>`:
					- name: dummy
					- version: nc
					- any: False
					- empty: True
				- :doc:`meteo<meteos/index>`:
					- name: dummy
					- version: csv
					- any: False
					- empty: True
		- :doc:`FLEXPART, std<models/flexpart>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: FLEXPART
					- version: std
					- any: False
					- empty: False
				- :doc:`fluxes<fluxes/index>`:
					- name: FLEXPART
					- version: nc
					- any: False
					- empty: True
		- :doc:`LMDZ, std<models/lmdz>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
				- :doc:`fluxes<fluxes/index>`:
					- name: LMDZ
					- version: sflx
					- any: False
					- empty: True
				- :doc:`chemistry<chemistries/index>`:
					- name: CHIMERE
					- version: gasJtab
					- any: False
					- empty: False
				- :doc:`emis_species<fluxes/index>`:
					- name: LMDZ
					- version: bin
					- any: False
					- empty: True
				- :doc:`meteo<meteos/index>`:
					- name: LMDZ
					- version: mass-fluxes
					- any: False
					- empty: True
				- :doc:`inicond<fields/index>`:
					- name: LMDZ
					- version: ic
					- any: False
					- empty: True
				- :doc:`prescrconcs<fields/index>`:
					- name: LMDZ
					- version: prescrconcs
					- any: False
					- empty: True
				- :doc:`prodloss3d<fields/index>`:
					- name: LMDZ
					- version: prodloss3d
					- any: False
					- empty: True


	 :doc:`datavect<datavects/index>`
		- :doc:`standard, std<datavects/standard>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`components<fields/index>`:
					- name:
					- version:
					- any: True
					- empty: True


	 :doc:`simulator<simulators/index>`
		- :doc:`dummy_txt, std<simulators/dummy>`
			Requires:
				- :doc:`controlvect<controlvects/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`gausscost, std<simulators/gausscost>`
			Requires:
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: False
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`gausscost, FLEXPART<simulators/gausscost_flexpart>`
			Requires:
				- :doc:`controlvect<controlvects/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True


	 :doc:`meteo<meteos/index>`
		- :doc:`CHIMERE, std<meteos/chimere_meteo>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: CHIMERE
					- version: std
					- any: False
					- empty: False
		- :doc:`dummy, csv<meteos/dummy_csv>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False
		- :doc:`LMDZ, mass-fluxes<meteos/lmdz_massflx>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
		- :doc:`TM5, std<meteos/tm5_meteo>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False


	 :doc:`transform<transforms/index>`
		- :doc:`conc2ratio, std<transforms/conc2ratio>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`dump2inputs, std<transforms/dump2inputs>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`families, std<transforms/families>`
		- :doc:`fromcontrol, std<transforms/fromcontrol>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`init_datastore, std<transforms/init_datastore>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`isotopes, std<transforms/isotopes>`
		- :doc:`loadfromoutputs, std<transforms/loadfromoutputs>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`ratio2conc, std<transforms/ratio2conc>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`regrid, std<transforms/regrid>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`run_model, std<transforms/run_model>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`satellites, std<transforms/satellites>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`time_interpolation, std<transforms/time_interpolation>`
		- :doc:`timeavg, std<transforms/timeavg>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`toobsvect, std<transforms/toobsvect>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`unit_conversion, std<transforms/unit_conversion>`
		- :doc:`vertical_interpolation, std<transforms/vertical_interpolation>`


	 :doc:`obsvect<obsvects/index>`
		- :doc:`standard, std<obsvects/standard>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`datavect<datavects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True


	 :doc:`obsparser<obsparsers/index>`
		- :doc:`WDCGG, std<obsparsers/wdcgg>`


	 :doc:`fluxes<fluxes/index>`
		- :doc:`CHIMERE, AEMISSIONS<fluxes/chimere>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: CHIMERE
					- version: std
					- any: False
					- empty: False
				- :doc:`chemistry<chemistries/index>`:
					- name: CHIMERE
					- version: gasJtab
					- any: False
					- empty: False
		- :doc:`dummy, nc<fluxes/dummy_nc>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False
		- :doc:`dummy, txt<fluxes/dummy_txt>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False
		- :doc:`EDGAR, v5<fluxes/edgar_v5>`
		- :doc:`FLEXPART, nc<fluxes/flexpart>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: FLEXPART
					- version: std
					- any: False
					- empty: False
		- :doc:`LMDZ, bin<fluxes/lmdz_bin>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
		- :doc:`LMDZ, sflx<fluxes/lmdz_sflx>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
		- :doc:`TM5, std<fluxes/tm5>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False


	 :doc:`fields<fields/index>`
		- :doc:`CHIMERE, icbc<fields/chimere_icbc>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: CHIMERE
					- version: std
					- any: False
					- empty: False
		- :doc:`ECMWF, grib2<fields/grib2_ecmwf>`
		- :doc:`LMDZ, ic<fields/lmdz_ic>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
		- :doc:`LMDZ, prescrconcs<fields/lmdz_prescrconcs>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
		- :doc:`LMDZ, prodloss3d<fields/lmdz_prodloss3d>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: LMDZ
					- version: std
					- any: False
					- empty: False
		- :doc:`NOAA, glob_avg<fields/noaa_glob_avg>`
		- :doc:`TM5, ic<fields/tm5_ic>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name: dummy
					- version: std
					- any: False
					- empty: False


	 :doc:`domain<domains/index>`
		- :doc:`CHIMERE, std<domains/chimere>`
		- :doc:`dummy, std<domains/dummy>`
		- :doc:`FLEXPART, std<domains/flexpart>`
		- :doc:`LMDZ, std<domains/lmdz>`


	 :doc:`measurements<measurements/index>`
		- :doc:`random, std<measurements/random>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`random, param<measurements/random_perparam>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name:
					- version:
					- any: True
					- empty: False
		- :doc:`standard, std<measurements/standard>`


	 :doc:`controlvect<controlvects/index>`
		- :doc:`standard, std<controlvects/standard>`
			Requires:
				- :doc:`domain<domains/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`components<fields/index>`:
					- name:
					- version:
					- any: True
					- empty: True
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`datavect<datavects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True


	 :doc:`mode<modes/index>`
		- :doc:`adj-tl_test, std<modes/adjtl_test>`
			Requires:
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: False
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`analytic, std<modes/analytic>`
			Requires:
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: False
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`platform<platforms/index>`:
					- name:
					- version:
					- any: True
					- empty: True
		- :doc:`EnKF, std<modes/enkf>`
			Requires:
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: False
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`platform<platforms/index>`:
					- name:
					- version:
					- any: True
					- empty: True
		- :doc:`footprint, std<modes/footprint>`
		- :doc:`forward, std<modes/forward>`
			Requires:
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: False
					- empty: True
		- :doc:`post-proc, std<modes/postproc>`
			Requires:
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`4dvar, std<modes/variational>`
			Requires:
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: False
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`obsoperator<obsoperators/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`minimizer<minimizers/index>`:
					- name: m1qn3
					- version: std
					- any: True
					- empty: True
				- :doc:`simulator<simulators/index>`:
					- name: gausscost
					- version: std
					- any: True
					- empty: True


	 :doc:`obsoperator<obsoperators/index>`
		- :doc:`FLEXINVERT, std<obsoperators/fp>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
		- :doc:`standard, std<obsoperators/standard>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: False
				- :doc:`obsvect<obsvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`controlvect<controlvects/index>`:
					- name: standard
					- version: std
					- any: True
					- empty: True
				- :doc:`platform<platforms/index>`:
					- name:
					- version:
					- any: True
					- empty: True


	 :doc:`platform<platforms/index>`
		- :doc:`TGCC-CCRT, AMD<platforms/ccrt_amd>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: True
		- :doc:`LSCE, obelix<platforms/lsce_obelix>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: True
		- :doc:`TGCC-CCRT, std<platforms/tgcc_ccrt>`
			Requires:
				- :doc:`model<models/index>`:
					- name:
					- version:
					- any: True
					- empty: True


	 :doc:`chemistry<chemistries/index>`
		- :doc:`TM5, SINK-TIPP<chemistries/TM5>`
		- :doc:`CHIMERE, gasJtab<chemistries/chimere>`


