#####################
CHIMERE - NetCDF
#####################

.. automodule:: pycif.plugins.fluxes.dummy_nc