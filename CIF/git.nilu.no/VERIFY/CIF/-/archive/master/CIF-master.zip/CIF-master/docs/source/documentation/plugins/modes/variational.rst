######################
Variational inversions
######################


.. automodule:: pycif.plugins.modes.variational
