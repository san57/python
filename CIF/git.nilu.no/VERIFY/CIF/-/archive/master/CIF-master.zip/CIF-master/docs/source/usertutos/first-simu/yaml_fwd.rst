.. code-block:: yaml
    :linenos:

    #####################
    # PYCIF config file #
    #####################

    # Define here all parameters for PYCIF following Yaml syntax
    # For details on Yaml syntax, please see:
    # http://docs.ansible.com/ansible/latest/YAMLSyntax.html

    # For non-specified parameters, one can either comment the corresponding line
    # or give the value "null"

    # Some parameters are switches that need to be activated or not.
    # PYCIF expects a boolean True/False
    # Yaml accepts the following syntax to be converted to booleans:
    # y|Y|yes|Yes|YES|n|N|no|No|NO|true|True|TRUE|false|False|FALSE|on|On|ON|off|Off|OFF
    # This offers flexibility, but one should stick to a style for consistency

    #####################################################################
    #####################################################################
    # PYCIF parameters

    # Verbose level
    # 1 = Basic information
    # 2 = Debugging
    verbose: 1

    # Log file (to be saved in $wordkir)
    logfile: pycif.logtest

    # Execution directory
    workdir : ${CIF_OUTPUT}/CIF_dummy_test/

    # Initial date
    # Use the following compatible format for the date:
    # YYYY-mm-dd or YYYY-mm-dd HH:mm
    datei : 2010-01-01

    # End date (same as for the initial date)
    datef : 2010-01-05
    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    # To-Do for initializing PYCIF
    # Can be commented if running PYCIF directly
    #todo_init: [measurements]
    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    # Running mode for PYCIF
    mode:
      plugin:
        name: forward
        version: std
    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    # Transport model
    # Accepts any model registered in pycif.models
    model :
      plugin:
        name    : dummy
        version : std

      # H matrix
      file_pg : ${CIF_ROOT}/model_sources/dummy_gauss/Pasquill-Gifford.txt

      # Chemical scheme
      chemistry:
        acspecies:
          CH4:
    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    # How to build your observation vector and observation uncertainties if needed
    # Also projects information from the observation to the model space
    # - file_obsvect: observation vector from previous simulations
    obsvect:
      plugin:
        name: standard
        version: std
    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    controlvect:
      plugin:
        name: standard
        version: std
      save_out_netcdf: true
    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    # Arguments to define the state vector
    # These are specifi to the state vector and inversion method you chose
    # Please refer to the documentation to know what to include here
    # For the standard LMDZ, include the following:
    # - filelsm: land-sea mask (must be consistent with LMDZ grid)
    # - correl: Use correlation or not in B
    # - dircorrel: path to pre-computed correlations
    # - sigma_land: spatial correlation length for prior errors over land (km)
    # - sigma_sea: spatial correlation length for prior errors over ocean (km)
    # - tracers: list of tracers to put in the state vector (with definition arguments):
    #     - calcstd: calculate global standard deviation
    #     - hresol: resolution at which fields are scaled
    #            (choice = bands,regions,pixels;
    #             if regions, provide a netcdf file fileregion
    #             if bands, define a list of latitudes as band limits (n+1 for n bands)
    #     - periodflux: period of variation for increments within a month (days)
    #     - glob_err (optional) = uncertainty on global budget
    datavect:
      plugin:
        name: standard
        version: std
      components:
        fluxes:
          parameters:
            CH4 :
              plugin:
                name: 'dummy'
                version: 'txt'
                type: 'fluxes'
              hresol : hpixels
              type : physical
              errtype : max
              err : 1
              period : '5D'
              flx_formula:
              - product:
                  - sum:
                    - cos: null
                      period: 500
                      variable: zlat
                    - sin: null
                      period: 1000
                      variable: zlon
                  - sum:
                    - square: null
                      period: 1000
                      variable: zlat
                    - square: null
                      period: 1000
                      variable: zlon
        meteo :
          plugin :
            name : dummy
            version : csv
            type: meteo
          resolution: '1H'
          seed: True
        concs:
          parameters:
            CH4:
              plugin:
                name: random
                type: measurements
                version: param
              duration: 2H
              frequency: 1H22min
              nstations: 50
              random_subperiod_shift: true
              seed: true
              zmax: 100


    #####################################################################
    #####################################################################


    #####################################################################
    #####################################################################
    # Domain definition
    domain :
      plugin :
        name : dummy
        version : std
      xmin: 0
      xmax: 2500
      nlon: 30
      ymin: 0
      ymax: 2000
      nlat: 15
    #####################################################################
    #####################################################################