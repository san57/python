import numpy as np

import pandas as pd
from pycif.utils.datastores.empty import init_empty


def make_obs(self, datastore, runsubdir, mode, tracer):
    # If empty datastore, do nothing
    if datastore.size == 0:
        return

    # Otherwise, crop the datastore to active species
    if not hasattr(self, "dataobs"):
        self.dataobs = {spec: init_empty()
                        for spec in self.chemistry.acspecies.attributes}

    self.dataobs[tracer] = datastore
    
    col2extract = "obs_incr" if mode == "adj" else "obs"

    # Include only part of the datastore
    data = self.dataobs[tracer][
        ["tstep", "dtstep", "i", "j", col2extract, "level"]
    ].values

    # Converts level, tstep, i, j to fortran levels
    data[:, [0, 2, 3, 5]] += 1

    # Assumes that stations with no level are in first level
    # TODO: make it general
    data[np.isnan(data[:, -1]), -1] = 1
    data[data[:, -1] <= 0, -1] = 1
    data[:, -1] /= 100.0

    # Attribute ID to each species
    for k, s in enumerate(self.chemistry.acspecies.attributes):
        mask = (self.dataobs[tracer]["parameter"].str.lower()
                == s.lower()).values
        data[mask, -1] += k + 1
    
    # Update binary file if necessary
    if getattr(self, "update_obs", False):
        nobs_orig = \
            int(open("{}/obs.txt".format(runsubdir), "r").readlines()[0])
        obs_orig = (
            np.fromfile("{}/obs.bin".format(runsubdir), dtype="float")
            .reshape((-1, 6), order="F")
        )
        data = np.append(data, obs_orig, axis=0)
    
    # Write in a binary
    obs_file = "{}/obs.bin".format(runsubdir)
    data.T.tofile(obs_file)
    with open("{}/obs.txt".format(runsubdir), "w") as f:
        f.write(str(len(data)))
    
    # Keep in mind that obs.bin already exists and should be updated if
    # another tracer is added
    self.update_obs = True
    