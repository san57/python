        INTEGER nfilun, nfilus, nfilvn, nfilvs
       PARAMETER (nfilun=16, nfilus=15, nfilvn=16, nfilvs=16)
