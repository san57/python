Summary

(Summarize the mistake or missing info concisely)

What section?

(Where can it be found in the documentation)

Suggestions?

(What information or correction is needed to improve the documentation)
