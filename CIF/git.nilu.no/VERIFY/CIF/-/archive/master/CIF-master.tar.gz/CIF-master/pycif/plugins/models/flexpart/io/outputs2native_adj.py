import copy

from pycif.utils.datastores.empty import init_empty


def outputs2native_adj(
        self, data2dump, input_type,
        di, df, runsubdir, mode='fwd',
        dump=True, onlyinit=False, do_simu=True, **kwargs):
    """Reads outputs to pycif objects.
       
       Does nothing for now as we instead read FLEXPART output 
       inside loop over observations in obsoper.py 

    """
    
    ddi = min(di, df)

    # Otherwise, crop the datastore to active species
    if not hasattr(self, "dataobs") or getattr(self, "reset_obs", True):
        self.dataobs = {list(data2dump.keys())[0][1]: init_empty()}

    for trid in data2dump:
        mod_input = trid[0]
        trcr = trid[1]

        if mod_input != "concs":
            continue

        if "data" in data2dump[trid]:
            self.dataobs[trcr] = copy.deepcopy(data2dump[trid]["data"])