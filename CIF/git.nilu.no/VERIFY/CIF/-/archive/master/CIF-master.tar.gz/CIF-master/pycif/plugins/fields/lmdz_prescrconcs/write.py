from pycif.utils.classes.fluxes import Fluxes
import numpy as np


def write(self, prescr_file, prescr, mode="a"):
    """Write prescribed species files for LMDZ

    Args:
        self (Fluxes): the Fluxes plugin
        prescr_file (str): the file where to write fluxes
        prescr (xarray.DataArray): prescribed species data to write
        mode (str): 'w' to overwrite, 'a' to append
        """

    prescr_fwd = prescr["fwd"].values
    prescr_tl = prescr["tl"].values
    np.transpose([prescr_fwd, prescr_tl], axes=(0, 4, 3, 2, 1)).T.tofile(prescr_file)

