""" Routines for reading FLEXPART output

"""

import os
import numpy as np

from scipy.io import FortranFile
import datetime
from logging import info


def read_flexpart_grid(subdir, file_name, fp_header, **kwargs):
    """ Reads FLEXPART grid_time file.
    Convert s.m3/kg to s.m2/kg
    

    Inputs:
        file_name - full path name to file name
        fp_header - a Flexpartheader object

    Returns:
        grid_fp: Array (nlon, nlat, ntime) of footprints
        gtime  : Array (maxngrid) of file dates
    
    """

    # Numeric scaling factor
    numscale = np.float(kwargs.get("numscale", 1.E12))
        
    file_dates = os.path.join(subdir, 'dates')
    path_file = os.path.join(subdir, file_name)

    scaleconc = 1.e12
    
    days = []
    times = []
    counts_i = []
    counts_r = []
    sparse_i = []
    sparse_r = []
    with FortranFile(path_file, 'r') as f:
        # Looping until the end of the binary file
        while True:
            try:
                yyyymmdd = f.read_ints('i4')[0].astype(str)
                hhmmss = '{0:06d}'.format(f.read_ints('i4')[0])
                i = f.read_ints('i4')
                spi = f.read_ints('i4')
                r = f.read_ints('i4')
                spr = f.read_reals('f4')
                
                days.append(yyyymmdd)
                times.append(hhmmss)
                counts_i.extend(i)
                sparse_i.extend(spi)
                counts_r.extend(r)
                sparse_r.extend(spr)
    
            except TypeError:
                break

    gtime_dt = [datetime.datetime.strptime('{}{}'.format(d, h), '%Y%m%d%H%M%S')
                for d, h in zip(days, times)][::-1]
    ngrid = len(gtime_dt)
    grid_fp = np.zeros((fp_header.numx, fp_header.numy, ngrid + 2))
    
    if len(sparse_r) > 0:
        sign = np.sign(sparse_r)
        cum_counts = np.unique(np.cumsum(counts_r) % sign.size)
        signchange = ((np.roll(sign, 1) - sign) != 0)
        signchange[cum_counts] = True
        
        inds_out = np.zeros((len(sparse_r)), dtype=np.int)
        inds_out[signchange] = sparse_i
        
        mask = inds_out == 0
        idx = np.where(~mask, np.arange(mask.size), 0)
        np.maximum.accumulate(idx, out=idx)
        inds_out = inds_out[idx] + np.arange(mask.size) \
                   - idx - fp_header.numx * fp_header.numy
        jy, jx = np.unravel_index(inds_out, (fp_header.numy, fp_header.numx))
        
        jt = np.zeros((len(sparse_r)), dtype=np.int)
        jt[cum_counts] = np.arange(ngrid)[np.array(counts_r) > 0]
        np.maximum.accumulate(jt, out=jt)
        jt = ngrid - jt - 1
        grid_fp[jx, jy, jt] = np.abs(sparse_r) * scaleconc
    
    # grid_fp, ngrid, gtime = mod_flexpart.read_grid(
    #     path_file, file_dates, fp_header.numx, fp_header.numy,
    #     fp_header.maxngrid, fp_header.xshift,  fp_header.ndgrid, fp_header.trajdays)

    # Convert from ppt to ppmv or ppbv

    # Convert s.m3/kg to s.m2/kg and apply numerical scaling
    grid_fp = grid_fp / (fp_header.outheight[0] * numscale)

#     # Convert grid times to datetime format
#     gtime_dt = []
#     for i in range(len(gtime)):
# #        gtime_dt[i] = flexpart_header.Flexpartheader.j2d(gtime[i])
#         if gtime[i] == 0.:
#             break
#
# #        gtime_dt.append(fp_header.j2d(gtime[i]))
#         gtime_dt.append(j2d(gtime[i]))
    
    return grid_fp, gtime_dt, ngrid


def read_flexpart_gridinit(subdir, filename, fp_header,
                           scaleconc=1, **kwargs):
    
    path_file = os.path.join(subdir, filename)
    with FortranFile(path_file, 'r') as f:
        yyyymmdd = f.read_ints('i4')[0].astype(str)
        hhmmss = '{0:06d}'.format(f.read_ints('i4')[0])
        sp_count_i = f.read_ints('i4')[0]
        sparse_i = f.read_ints('i4')
        sp_count_r = f.read_ints('i4')[0]
        sparse_r = f.read_reals('f4')
    
    nx = fp_header.numx
    ny = fp_header.numy
    nz = (fp_header.outheight != 0.).sum()
    grid_init = np.zeros((nx, ny, nz))

    if len(sparse_r) > 0:
        sign = np.sign(sparse_r)
        cum_counts = np.unique(np.cumsum(sp_count_r) % sign.size)
        signchange = ((np.roll(sign, 1) - sign) != 0)
        signchange[cum_counts] = True
    
        inds_out = np.zeros((len(sparse_r)), dtype=np.int)
        inds_out[signchange] = sparse_i
        
        mask = inds_out == 0
        idx = np.where(~mask, np.arange(mask.size), 0)
        np.maximum.accumulate(idx, out=idx)
        inds_out = inds_out[idx] + np.arange(mask.size) \
                   - idx - fp_header.numx * fp_header.numy
        jz, jy, jx = np.unravel_index(inds_out,
                                      (nz, fp_header.numy, fp_header.numx))

        grid_init[jx - 1, jy - 1, jz] = np.abs(sparse_r) * scaleconc

    return grid_init


def get_spec(subdir, **kwargs):
    """ Get species name from simulation output

    """

    with open(os.path.join(subdir, 'header_txt'), 'r') as f:
        txt = f.readlines()

    spec = txt[20].split()[1]

    info("species", spec)
    return spec
