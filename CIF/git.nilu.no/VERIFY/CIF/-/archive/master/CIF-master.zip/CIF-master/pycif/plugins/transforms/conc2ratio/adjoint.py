import copy
import xarray as xr
import numpy as np
import pandas as pd
from pycif.utils.datastores.dump import read_datastore


def adjoint(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    
    inputs = transf.parameters_in.names
    outputs = transf.parameters_out.names
    components_in = transf.component
    components_out = len(outputs) * [transf.component[-1]]
    
    datastore = pipe.datastore
    
    # Concatenate input datastores
    dfout = pd.concat(
        [datastore[(comp, trcr)]["data"].assign(parameter_ref=trcr.lower())
         for comp, trcr in zip(components_in, inputs)])
    
    # Initializes output dataframe from available total concentrations
    # Implicitly includes the adjoint of the sum of isotopologues
    for comp, trcr in zip(components_out, outputs):
        datastore[(comp, trcr)]["data"] = \
            copy.deepcopy(dfout.assign(parameter=trcr.lower()))
    
    # Stop here if do not need to compute the full adjoint
    if onlyinit:
        return
    
    # Retrieve fwd data
    for comp, spec in zip(components_out, outputs):
        file_fwd_data = \
            ddi.strftime(
                "{}/chain/isotopes/{}_fwd_obsvect_{}_{}_%Y%m%d%H%M.nc".format(
                    transf.model.adj_refdir, transf.orig_name, comp, spec))
        ds = read_datastore(file_fwd_data, reorder=False,
                            col2dump=["parameter", "parameter_ref",
                                      "sim", "sim_tl"])
        datastore[(comp, spec)]["data"]\
            .loc[:, ["parameter", "parameter_ref", "sim", "sim_tl"]] = ds.values
        
    
    # Compute
    df_all_isos_fwd = {trid[1]: datastore[trid]["data"]
                       for trid in zip(components_out, outputs)}
    df0_fwd = df_all_isos_fwd[outputs[0]]
    
    spec_ref = inputs[-1]
    sub_inputs = [(sign, spec_ref) for sign in inputs[:-1]]
    for sub_input in sub_inputs:
        sign_id = sub_input[0]
        spec_id = sub_input[1]
        sign_attr = getattr(transf.parameters_out, sign_id)
        r_std = sign_attr.standard
        refs = sign_attr.refs
        isotopologues = sign_attr.isotopologues

        # Retrieve specific forward data
        ref_sims_fwd = sum([df_all_isos_fwd[ref]["sim"]
                            for ref in refs])
        isotopologue_sims_fwd = sum([df_all_isos_fwd[iso]["sim"]
                                     for iso in isotopologues])

        mask_sign = df0_fwd["parameter_ref"] == sign_id.lower()
        ref_fwd = ref_sims_fwd.loc[mask_sign]
        isotopologue_fwd = isotopologue_sims_fwd.loc[mask_sign]
        
        comp_in = components_in[inputs.index(sign_id)]
        dfout = datastore[(comp_in, sign_id)]["data"]
        
        # Compute obs_incr
        for ref in refs:
            comp_ref = components_out[outputs.index(ref)]
            df_ref = datastore[(comp_ref, ref)]["data"]
            mask_sign_ref = df_ref["parameter_ref"] == sign_id.lower()
            incr_ref = df_ref.loc[mask_sign_ref, "obs_incr"]
            df_ref.loc[mask_sign_ref, "obs_incr"] = \
                - isotopologue_fwd / ref_fwd ** 2 * incr_ref * 1000 / r_std
            
        for iso in isotopologues:
            comp_iso = components_out[outputs.index(iso)]
            df_iso = datastore[(comp_iso, iso)]["data"]
            mask_sign_iso = df_iso["parameter_ref"] == sign_id.lower()
            incr_iso = df_iso.loc[mask_sign_iso, "obs_incr"]
            df_iso.loc[mask_sign_iso, "obs_incr"] = \
                1 / ref_fwd * incr_iso * 1000 / r_std
            