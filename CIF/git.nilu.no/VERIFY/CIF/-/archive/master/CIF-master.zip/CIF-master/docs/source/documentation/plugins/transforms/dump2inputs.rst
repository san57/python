###############################
Dump pyCIF data to model inputs
###############################

.. automodule:: pycif.plugins.transforms.dump2inputs