from .create_domain import create_domain
from .read_domain import read_grid

_name = "FLEXPART"

unstructured_domain = True
