def read(
    self,
    name,
    tracdir,
    tracfile,
    varnames,
    dates,
    interpol_flx=False,
    comp_type=None,
    **kwargs
):

    raise Exception(
        "I am not supposed to read CHIMERE meteo files " "at the moment"
    )
