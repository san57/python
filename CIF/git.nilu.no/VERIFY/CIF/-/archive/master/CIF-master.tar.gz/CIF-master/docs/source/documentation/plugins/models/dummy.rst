#####################
Toy Gaussian model
#####################

.. automodule:: pycif.plugins.models.dummy

