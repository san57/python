from .utils import add_default


def init_model(transfs_ids, transforms,
               all_inputs, all_outputs, backup_comps, mapper):
    run_id = "run_model"
    if "run_model" not in transfs_ids:
        yml_dict = {
            "plugin": {
                "name": "run_model",
                "version": "std",
                "type": "transform",
            }
        }
        run_transf, run_id = \
            add_default(
                transforms,
                yml_dict,
                position="last",
                init=True,
                mapper=mapper,
                inputs=all_inputs,
                outputs=all_outputs
            )
        transf_mapper = run_transf.mapper

    else:
        run_transf = getattr(transforms, "run_model")
        run_id = "run_model"
        
        # Updating the general mapper, and creates a local one
        transf_mapper = run_transf.ini_mapper(
            inputs=all_inputs,
            outputs=all_outputs,
            backup_comps=backup_comps,
        )
        run_transf.mapper = transf_mapper
        mapper[run_id] = transf_mapper
    
        all_inputs.update(transf_mapper["inputs"])
        all_outputs.update(transf_mapper["outputs"])
    
    transforms.model_transf_id = run_id
    
    # Force dumping inputs
    for trid in transf_mapper["inputs"]:
        if transf_mapper["inputs"][trid].get("force_dump", False):
            # Adding a dump transformation before the present transform
            yml_dict = {
                "plugin": {
                    "name": "dump2inputs",
                    "version": "std",
                    "type": "transform",
                },
                "component": [trid[0]],
                "parameter": [trid[1]],
            }
            add_default(
                transforms,
                yml_dict,
                position="start",
                mapper=mapper,
                init=True,
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps
            )

    # Force loading outputs
    for trid in transf_mapper["outputs"]:
        # Adding a dump transformation before the present transform
        yml_dict = {
            "plugin": {
                "name": "loadfromoutputs",
                "version": "std",
                "type": "transform",
            },
            "component": [trid[0]],
            "parameter": [trid[1]],
        }
        add_default(
            transforms,
            yml_dict,
            position="last",
            mapper=mapper,
            init=True,
            inputs=all_inputs,
            outputs=all_outputs,
            backup_comps=backup_comps
        )

        # Applying time averaging to outputs
        yml_dict = {
            "plugin": {
                "name": "timeavg",
                "version": "std",
                "type": "transform",
            },
            "component": [trid[0]],
            "parameter": [trid[1]]
        }
        add_default(
            transforms,
            yml_dict,
            position="last",
            mapper=mapper,
            init=True,
            inputs=all_inputs,
            outputs=all_outputs,
            backup_comps=backup_comps,
        )