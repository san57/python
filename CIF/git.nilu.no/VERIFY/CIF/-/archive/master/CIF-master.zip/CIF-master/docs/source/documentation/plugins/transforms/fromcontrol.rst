#############################
Variable from control vector
#############################

.. automodule:: pycif.plugins.transforms.fromcontrol