import pandas as pd

from pycif.utils import path
from .inputs.make_fluxes import make_fluxes
from .inputs.make_inicond import make_inicond
from .inputs.make_chemistry import make_chemistry
from .inputs.make_meteo import make_meteo
from .inputs.params import make_config


def native2inputs(
        self, datastore, input_type, datei, datef, runsubdir, mode="fwd",
        onlyinit=False, do_simu=True, **kwargs
):
    """Converts data at the model data resolution to model compatible input
    files. Input types should be consistent with the ones specified in the
    mapper.
    Calls sub-functions dealing with individual input types

    The datastore provided to this function is a pyCIF Plugin, whose main
    interesting attribute is "datastore.datastore".
    This attribute is a dictionary of which each key is a tuple (input_type, parameter).
    Associated values are the following:
        - spec: an xarray.Dataset including the corresponding input data
        - incr: same for increments
        - dirorig: directory where to find original files for that input
        - fileorig: file format for that input


    Args:
        self: the model Plugin
        input_type (str): one of 'fluxes'
        datastore (Plugin): data to convert
        datei, datef: date interval of the sub-simulation
        mode (str): running mode: one of 'fwd', 'adj' and 'tl'
        runsubdir (str): sub-directory for the current simulation
        workdir (str): the directory of the whole pyCIF simulation


    """

    ddi = min(datei, datef)
    ddf = max(datei, datef)

    # Hour steps of the sub-run
    hour_dates = pd.date_range(ddi, ddf, freq="1H")

    if datastore is None:
        datastore = {}

    sdc = ddi.strftime("%Y%m%d%H")

    # If mode is "fwd" or "tl" but onlyinit is True,
    # it means that we are initializing an adjoint by running backward
    # the adjoint pipeline
    if mode in ["tl", "fwd"] and onlyinit:
        mode = "adj"

    if not do_simu:
        return

    # Choose the right executable
    if input_type == "exe":
        # JvP 20201103: Updated link statement
        #path.link(
        #    "{}/model/tm5.f90".format(self.workdir),
        #    "{}/tm5.f90".format(runsubdir),
        #)
        path.link(
            "{}/model/tm5.exe".format(self.workdir),
            "{}/tm5.exe".format(runsubdir),
        )
    # end if

    # JvP 20201109: replaced "nml file" (probably a Chimere term) with
    # config file. The function make_config can be found in ./io/params.py.
    # Deals with the config file (for TM5: rc file).
    if input_type == "param":
        make_config(self, runsubdir, sdc, mode)

    # Deals with other inputs
    if input_type in "fluxes":
        make_fluxes(self, datastore, runsubdir, ddi, mode)

    if input_type == "inicond":
        make_inicond(self, datastore, runsubdir, mode, ddi, ddf)

    if input_type == "chemistry":
        make_chemistry(self, datastore, runsubdir, mode, ddi, ddf)

    if input_type == "meteo":
        make_meteo(self, runsubdir, sdc)
