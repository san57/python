import numpy as np
import xarray as xr
from .utils.get_weights import get_weights


def adjoint(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    # Stop here if do not need to compute the full adjoint
    if onlyinit:
        return

    xmod = pipe.datastore

    for trid in mapper["inputs"]:
        wgt_file = mapper["inputs"][trid]["weight_file"]

        # Inputs domain from the present tracer
        nlon_in = xmod[trid]["tracer"].domain.nlon
        zlon_in = xmod[trid]["tracer"].domain.zlon
        zlonc_in = xmod[trid]["tracer"].domain.zlonc
        nlat_in = xmod[trid]["tracer"].domain.nlat
        zlat_in = xmod[trid]["tracer"].domain.zlat
        zlatc_in = xmod[trid]["tracer"].domain.zlatc

        # Outputs domain from the mapper
        is_lbc = mapper["outputs"][trid].get("is_lbc", False)
        domain_out = mapper["outputs"][trid]["domain"]

        if is_lbc:
            nlon_out = domain_out.nlon_side
            nlat_out = domain_out.nlat_side

        else:
            nlat_out, nlon_out = domain_out.zlat.shape

        # Getting weights
        weights = get_weights(
            transf,
            wgt_file,
            nlon_in,
            nlat_in,
            zlon_in,
            zlat_in,
            zlonc_in,
            zlatc_in,
            domain_out,
            is_lbc)

        xmod[trid]["adj_out"] = do_regridding_adj(
            xmod[trid]["adj_out"], nlat_in, nlon_in, weights,
            min_weight=transf.min_weight
        )

    pipe.datastore = xmod

    return pipe


def do_regridding_adj(data, nlat_in, nlon_in, weights, min_weight=1e-10):

    # Applying weights
    nlev = len(data.lev)
    ntimes = len(data.time)
    nlat_out = len(data.lat)
    nlon_out = len(data.lon)
    var_in = np.zeros((ntimes, nlev, nlat_in, nlon_in))
    var_out = data.values
    for k, wgt in enumerate(weights):
        iout, jout = np.unravel_index(k, (nlat_out, nlon_out), order="F")
        wgt_filtered = list(zip(*[w for w in zip(*wgt) if w[2] > min_weight]))
        var_in[..., wgt_filtered[1], wgt_filtered[0]] += \
            var_out[..., iout, jout, np.newaxis] * wgt_filtered[2]

    times = data.time.values

    return xr.DataArray(
        var_in, coords={"time": times}, dims=("time", "lev", "lat", "lon")
    )

