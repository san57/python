import datetime
import glob
import os

import numpy as np
import xarray as xr
import pandas as pd

from pycif.utils.datastores.empty import init_empty
from .inputs.obs import make_obs


def outputs2native_adj(
        self, data2dump, input_type, datei, datef, runsubdir, mode="fwd",
        dump=True, onlyinit=False, do_simu=True, **kwargs
):
    """Reads outputs to pycif objects.

    If the mode is 'fwd' or 'tl', only observation-like outputs are extracted.
    For the 'adj' mode, all outputs relative to model sensitivity are extracted.

    Dumps to a NetCDF file with output concentrations if needed

    Args:
        self (pycif.utils.classes.models.Model): Model object
        runsubdir (str): current sub-sumilation directory
        mode (str): running mode; one of: 'fwd', 'tl', 'adj'; default is 'fwd'

        dump (bool): dumping outputs or not; default is True
    Return:
        dict

    """
    ddi = min(datei, datef)
    ddf = max(datei, datef)

    # Hour steps of the sub-run
    hour_dates = pd.date_range(ddi, ddf, freq="1H")
    
    for trid in data2dump:
        mod_input = trid[0]
        trcr = trid[1]
        
        if mod_input != "concs":
            continue
        
        if "data" in data2dump[trid]:
            if onlyinit:
                make_obs(self, data2dump[trid]["data"], runsubdir, "fwd", trcr)
            else:
                make_obs(self, data2dump[trid]["data"], runsubdir, "adj", trcr)
