import os
import subprocess
#
# JvP 20201103: the copytree function from the shutil module only works if the
# destination directory does not exist. If it does exist, an error will be
# issued. Since you will be copying multiple source directories to a single
# target directory (i.e. the different TM5 projects), this is undesired
# behaviour. So I googled around, and found a replacement for copytree that
# apparently also works if the destination directory exists. To be on the
# safe side, I removed copytree from the import statement below.
#
#from shutil import copytree, ignore_patterns, rmtree, copy
from shutil import ignore_patterns, rmtree, copy
#
from logging import info, debug


# >>> JvP 20201103: copied the following code from
# https://stackoverflow.com/a/22331852, changed indentation from 2 to 4 spaces,
# and added some "end if" comments (not required, but clearer IMHO). According
# to the stackoverflow page this function has the following characteristics:
# *) Same behavior as shutil.copytree, with symlinks and ignore parameters
# *) Create directory destination structure if non existant
# *) Will not fail if dst already exists

import shutil
import stat
def copytree(src, dst, symlinks = False, ignore = None):
    if not os.path.exists(dst):
        os.makedirs(dst)
        shutil.copystat(src, dst)
    # end if
    lst = os.listdir(src)
    if ignore:
        excl = ignore(src, lst)
        lst = [x for x in lst if x not in excl]
    # end if
    for item in lst:
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if symlinks and os.path.islink(s):
            if os.path.lexists(d):
                os.remove(d)
            # end if
            os.symlink(os.readlink(s), d)
            try:
                st = os.lstat(s)
                mode = stat.S_IMODE(st.st_mode)
                os.lchmod(d, mode)
            except:
                pass # lchmod not available
            # end try
        elif os.path.isdir(s):
            copytree(s, d, symlinks, ignore)
        else:
            shutil.copy2(s, d)
        # end if symlinks
    # end for item
# end function copytree

# <<< JvP 20201103



def compile(self):
    """
    PURPOSE
    Compile the TM5 source tree into an executable

    IN/OUT
    none

    KWARGS
    none

    ASSUMPTIONS
    none

    EXCEPTIONS
    When this function encounters a problem that it cannot solve,
    it will raise a RuntimeError. Pythons exeception handling will
    provide a traceback, including files, calls and line numbers.

    PYTHON VERSION
    3.7.6

    VERSION CHANGE HISTORY
    1.0 03-11-2020 by J.C.A. van Peet.
        Original code, based on an example by A. Berchet.
    """

    # EXAMPLE CODE
    #comp_dir = "{}/model".format(self.workdir)
    #
    #if not getattr(self, "auto-recompile"):
    #    source = "{}/tm5.f90".format(self.direxec)
    #    copy(source, comp_dir)
    #
    #    return
    #
    ## Otherwise, re-compile
    ## Copying sources locally; overwrite folder if exists
    #if os.path.isdir("{}/sources".format(comp_dir)):
    #    rmtree("{}/sources".format(comp_dir))
    #
    #copytree(
    #    self.direxec,
    #    "{}/sources".format(comp_dir),
    #    ignore=ignore_patterns("*.a"),
    #)
    #
    ## Now compiling


    # Name of program
    PROG_NAME = "compile.py"

    # Compilation directory (?) Copied variable name from original code
    comp_dir = "{}/model".format(self.workdir)

    # Print some debug statements
    # ************************************************************************
    # * NOTE: You specified workdir with a trailing slash in the YAML file,  *
    # *       and it is printed like that at the top of the output when      *
    # *       running pycif.                                                 *
    # *       However, the trailing slash is somehow stripped when you print *
    # *       workdir here as self.workdir.                                  *
    # ************************************************************************
    #print("*"*30)
    #print(PROG_NAME+" => DEBUG:")
    #print("   self           = ", self)
    #print("   dir(self)      = ", ("\n"+" "*21).join( [ ', '.join(dir(self)[i:i+5]) for i in range(0,len(dir(self)),5) ] )   )
    #print("   self.workdir   = ", self.workdir       )
    #print("   self.direxec   = ", self.direxec       )
    #print("   comp_dir       = ", comp_dir           )
    #print("   auto_recompile = ", self.auto_recompile)
    #print("   make_clean     = ", self.make_clean    )
    #print("*"*30)

    # Compile (or recompile) tm5 executable?
    # In general, do not use minus signs in variable names!
    # In this case, variables like 'direxec' and 'auto-recompile' will become
    # attributes to the model TM5. You should be able to get the value of these
    # attributes by using either of:
    #    1) self.auto-recompile
    #    2) getattr(self, 'auto-recompile')
    # Note that the first method won't work, because python will interpret that
    # as 'get the value for self.auto and subtract the variable recompile'. That
    # will yield an AttributeError, since there is no attribute called 'auto'.
    # To prevent that error from occuring, I replaced auto-recompile with
    # auto_recompile. See .../pycif/plugins/models/TM5/{__init__,compile}.py
    # and the yaml file (e.g. config_TM5_forward.yml) for the use of
    # auto_recompile.
    if( (self.auto_recompile) or (not os.path.isfile( "{}/tm5.exe".format(comp_dir) ) ) ):

        # Copy source tree
        print(PROG_NAME+" => Copy source tree.")
        copytree( "{}/src".format(self.direxec), "{}/src".format(comp_dir), ignore=ignore_patterns("*.a") )

        # Copy makefile
        print(PROG_NAME+" => Copy makefile.")
        copy( "{}/makefile".format(self.direxec), comp_dir )

        # Remove existing obj, mod and exe files?
        if( self.make_clean ):
            print(PROG_NAME+" => Make clean.")
            with open("{}/tm5_compile.log".format(comp_dir), "w") as log:
                print(PROG_NAME+" => Make clean.", file=log, flush=True)
                process = subprocess.Popen(
                    "make clean",
                    shell=True,
                    stdout=log,
                    cwd="{}".format(comp_dir),
                    stderr=subprocess.PIPE,
                )
                _, stderr = process.communicate()
                debug("\n".join("".join(stderr.decode("ascii"))))
            # end with
        # end if

        # Now compiling.
        print(PROG_NAME+" => Compiling.")
        with open("{}/tm5_compile.log".format(comp_dir), "a") as log:
            print("\n"*3,                     file=log, flush=True)
            print(PROG_NAME+" => Compiling.", file=log, flush=True)
            process = subprocess.Popen(
                "make",
                shell=True,
                stdout=log,
                cwd="{}".format(comp_dir),
                stderr=subprocess.PIPE,
            )
            _, stderr = process.communicate()
            debug("\n".join("".join(stderr.decode("ascii"))))
        # end with

    # end if

    #raise RuntimeError

# end function compile
