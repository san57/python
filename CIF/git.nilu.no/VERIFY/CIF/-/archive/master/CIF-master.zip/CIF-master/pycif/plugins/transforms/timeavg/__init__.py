import numpy as np
import pandas as pd
import copy
from logging import debug

_name = "timeavg"

requirements = {"model": {"any": True, "empty": False}}

default_values = {"global_dtsteps": {}}


def adjoint(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        **kwargs
):

    datastore = pipe.datastore

    tracer_ids = mapper["outputs"]

    # Loop over type of outputs
    for tracer_id in tracer_ids:
        mod_input = tracer_id[0]
        trcr = tracer_id[1]
        
        if "data" not in datastore.get(tracer_id, {}):
            continue

        ds = datastore[tracer_id]
        dataloc = ds["data"]

        # Increments are scaled according to dtstep in the adjoint
        # This assumes that obs values are averages from sub-step values
        # TODO: more complex operations might be considered in the future:
        #  e.g., interpolation, gradients, etc.
        #  These should anyway be dealt with
        #  with another transform and not here
        if "obs_incr" in dataloc:
            dataloc.loc[:, "obs_incr"] /= dataloc["dtstep"]

        # Observations overlapping two simulation sub-periods are dealt with
        model = transf.model
    
        subsimu_dates = model.subsimu_dates
        tstep_dates = model.tstep_dates
        tstep_all = model.tstep_all
        
        # Saving global tstep and dtstep to the transform for later use
        transf.global_dtsteps[tracer_id] = \
            copy.deepcopy(dataloc.loc[:, ["tstep", "dtstep"]])
    
        # Cropping observations starting before the sub-simulation
        mask = dataloc["date"] < ddi
        dataloc.loc[mask, "tstep"] = 0
        dataloc.loc[mask, "dtstep"] -= (
            np.argmax(tstep_all == ddi) - dataloc.loc[mask, "tstep_glo"]
        )
    
        # Cropping observations ending after the sub-simulation
        if dataloc.size > 0:
            mask = dataloc["date"] \
                   + pd.to_timedelta(dataloc["duration"], unit="h") > ddf
            dataloc.loc[mask, "dtstep"] = (
                np.argmax(tstep_all == ddf) - dataloc.loc[mask, "tstep_glo"]
            )
    
            # For observations from several sub-periods back in time,
            # cropping to the full sub-period extend
            dataloc.loc[mask, "dtstep"] = np.minimum(
                dataloc.loc[mask, "dtstep"], len(tstep_dates[ddi]) - 1
            )
    
        # Change type to integer
        dataloc.loc[~np.isnan(dataloc["tstep"]), "tstep"] = \
            dataloc["tstep"][~np.isnan(dataloc["tstep"])].astype(int)
        dataloc.loc[~np.isnan(dataloc["dtstep"]), "dtstep"] = \
            dataloc["dtstep"][~np.isnan(dataloc["dtstep"])
        ].astype(int)
        

def forward(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        **kwargs
):

    datastore = pipe.datastore

    tracer_ids = mapper["outputs"]

    # Loop over type of outputs
    for tracer_id in tracer_ids:
        mod_input = tracer_id[0]
        trcr = tracer_id[1]
        
        if tracer_id not in datastore \
                or datastore.get(tracer_id, None).get("data", None) is None:
            debug("Trying to apply timeavg to {} but is not available in "
                  "datastore".format(tracer_id))
            continue
        
        ds = datastore[tracer_id]
        dataloc = ds["data"]
        
        # TODO: add in a general way extra columns
        columns = ["sim", "sim_tl", "pressure", "dp", "airm", "hlay"]
        for col in columns:
            if col in dataloc:
                dataloc.loc[:, col] /= \
                    transf.global_dtsteps[tracer_id].loc[:, "dtstep"]
        
        # Replacing tstep by original ones
        dataloc.loc[:, "tstep"] = \
            transf.global_dtsteps[tracer_id].loc[:, "tstep"]


def ini_mapper(
    transf, inputs={}, outputs={}, backup_comps={}
):
    """Initialize mapper for time cropping.
    Does not need to change the mapper as cropping time keep similar
    names and dimensions"""
    
    inout = {(cmp, prm): outputs[(cmp, prm)]
             for cmp, prm in zip(transf.component, transf.parameter)}
    mapper = {"inputs": inout,
              "outputs": inout}
    
    return mapper
