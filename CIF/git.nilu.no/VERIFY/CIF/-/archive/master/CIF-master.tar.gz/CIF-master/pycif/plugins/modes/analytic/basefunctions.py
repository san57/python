import copy
import os
import glob
import re
import time
from pycif.utils import path
from logging import info
from pycif.utils.yml import ordered_dump


def check_base_functions(base_dir, statedim):
    list_monitor = glob.glob("{}/obsvect_*".format(base_dir))
    list_monitor.sort()
    
    regex = re.compile(os.path.join(base_dir,
                                    "obsvect_([0-9]*)"))
    list_IDs = [int(regex.findall(m)[0]) for m in list_monitor]
    return [i for i in range(statedim) if i not in list_IDs]


def compute_base_functions(self, controlvect, list_base_functions):
    workdir = controlvect.workdir
    platform = self.platform
    
    # Save Xb for later
    controlvect.xb_ref = copy.deepcopy(controlvect.xb)
    
    # Loop over state vector dimensions
    list_jobs = []
    for idim in list_base_functions:
        controlvect.xb[:] = 0.
        controlvect.xb[idim] = 1.
        
        # Dumps Dirac controlvect
        base_dir = "{}/base_functions/base_{:04d}/".format(workdir, idim)
        path.init_dir(base_dir)

        controlvect.dump(
            "{}/controlvect.pickle".format(base_dir),
        )
        
        # Updating configuration dictionary
        yml_dict = \
            self.from_yaml(self.reference_instances["reference_setup"].def_file)
        yml_dict.update(
            {"workdir": base_dir,
             "mode": {"plugin": {"name": "forward", "version": "std"}},
             "controlvect": {
                 "plugin": {"name": "standard", "version": "std"},
                 "reload_xb": True,
                 "reload_file": "{}/controlvect.pickle".format(base_dir),
                 "save_out_netcdf": self.dump_nc_base_control
             }
             }
        )
        
        # Dumps new yml file
        yml_file = "{}/config_base_{:04d}.yml".format(base_dir, idim)
        
        with open(yml_file, "w") as outfile:
            ordered_dump(outfile, yml_dict)
        
        # Run the base function as an independent process
        job_file = os.path.join(base_dir, "job_pycif_base_{:04d}".format(idim))
        
        info("Submitting base function {} from {}"
             .format(idim, len(list_base_functions)))
        
        job_id = platform.submit_job(
            "{} -m pycif {}".format(platform.python, yml_file),
            job_file
        )
        
        list_jobs.append(job_id)
    
    # Check that jobs are over
    while not platform.check_jobs(list_jobs):
        time.sleep(platform.sleep_time)
    
    # Move monitors
    for idim in list_base_functions:
        base_dir = "{}/base_functions/base_{:04d}/".format(workdir, idim)
        os.system("mv {basedir}/obsoperator/fwd_0000/obsvect "
                  "{basedir}/../H_matrix/obsvect_{:04d}"
                  .format(idim, basedir=base_dir))

