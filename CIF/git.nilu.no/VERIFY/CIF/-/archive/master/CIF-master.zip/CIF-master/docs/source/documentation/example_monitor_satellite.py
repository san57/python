from netCDF4 import Dataset
from pycif.utils.datastores import dump
from pycif.utils.netcdf import readnc
from pycif.utils.datastores import empty
from pycif.utils.datastores.dump import dump_datastore
import calendar
import os
import pandas as pd
import datetime
import numpy as np
import xarray as xr


##### raw data to read
year = 2011
maindir = '/home/chimereicos/ipison/IASI_Toulouse/'
month_name = [ 'janvier', 'fevrier', 'mars', 'avril', 'mai', 'juin', 'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre' ]
# get the satellite's vertical grid from the prior profile description
prior_profile_file = 'TN2OR_N2O_apriori.nc'
prior_prof = readnc(prior_profile_file, ['n2o_apriori'] )
fixed_nlevels = len(prior_prof)
# satellite formula = XXX
# take level at 308 hPa = the 5th one 
# retained_lev begins at 0
retained_lev = 4

##### datastore to dump in netcdf file for use by the CIF
# list of infos required for any type of obs
list_basic_cols = [ 'date', 'duration', 'station' , 'network', 'parameter', 'lon', 'lat', 'obs', 'obserror' ]
# fixed information for station, network and parameter + duration columns
stationID = 'IASI'
networkID = 'Toulouse'
spec = 'N2O'
obsduration = 1./60. # following Audrey's recommendation for sat data in general
# associated infos for satellites
list_prior_cols = [ ('qa0lu', k) for k in range(fixed_nlevels -1 )]
list_pres_cols = [('pavg', k) for k in range(fixed_nlevels)]
list_ak_cols = [('ak', k) for k in range(fixed_nlevels - 1 )]

# loop over the available files
for mm in range(12):
    month = '{0:02d}'.format(mm + 1)  
    for dd in range(calendar.mdays[mm + 1]):
        day = '{0:02d}'.format(dd + 1) 
        filein = '{}N2O_{}_{yy}_netcdf/iasi_ret_L2_n2o_ch4_{yy}_{}_{}.nc'.format(maindir, month_name[mm], month, day, yy = year)
        if not os.path.exists(filein): continue
        ### fill in sub-datastore for the current file
        subdata = pd.DataFrame( columns = list_basic_cols )
    
        ## check number of levels 
        pressure_lev = readnc(filein, ['level'] )
        nlevels_max = len(pressure_lev) + 1
        if ( nlevels_max != fixed_nlevels) : 
            print('ERROR NUMBER OF LEVELS')
            break

        ##date: starting date
        # must be a datetime object
        hh, mn, ms = readnc(filein, ['hour', 'minute', 'millisecs'] )
        dates = [datetime.datetime( year = year, month = mm +1 , day = dd + 1, hour = h, minute = m, second = int(s/1000) ) for h, m, s in zip(hh, mn, ms)]
        subdata['date'] = dates
        ## duration    duration in hours
        subdata = subdata.assign(duration = obsduration) 
        ## lon    longitude of the measurement
        ## lat    latitude of the measurement
        subdata['lon'] = readnc(filein, ['lon'])
        subdata['lat'] = readnc(filein, ['lat'])
        ## obs    observed value
        subdata['obs'] = readnc(filein, ['n2o_retrieval'])[:,retained_lev]
        ## obserror  error on the observation
        subdata['obserror' ]= readnc(filein, ['n2o_error'])[:,retained_lev]
        ## station    station ID
        ## network    network name 
        ## parameter    name of the observed parameter or species
        subdata = subdata.assign(station = stationID)
        subdata = subdata.assign(network = networkID)
        subdata = subdata.assign(parameter = spec)

        ## pressure levels: 
        # particular case of IASI Toulouse:
        # must put the surface in the right level and NaN lower
        ## same for prior profile
        pressures = pd.DataFrame(columns = [ 'surf_lev', 'surf_P']  )
        pressures[ 'surf_lev' ] = readnc(filein, ['Surf_P_id'])
        pressures[ 'surf_P' ] = readnc(filein, ['Surf_P'])
        # array with the right values of pressure: from top to the surface + NaN lower
        nrows = len(pressures)
        pavg = np.zeros((nrows, nlevels_max))
        qa0 = np.zeros((nrows, nlevels_max - 1 ))
        pavg[range(len(pressures)), pressures["surf_lev"]] = pressures["surf_P"]
        indj, indi = np.meshgrid(range(nlevels_max), range(nrows))
        indjj, indii = np.meshgrid(range(nlevels_max - 1 ), range(nrows))
        pavg[indj > pressures["surf_lev"][:, np.newaxis]] = np.nan
        qa0[indjj >= pressures["surf_lev"][:, np.newaxis]] = np.nan # no prior conc at the surface: TO CHECK
        mask = indj < pressures["surf_lev"][:, np.newaxis]
        pavg[mask] = pressure_lev[indj[mask]]
        mask = indjj < pressures["surf_lev"][:, np.newaxis]
        qa0[mask] = prior_prof[indjj[mask]]
        ## averaging kernels
        ak = pd.DataFrame(readnc(filein, ['n2o_AVK'] )[:, retained_lev,:-1], columns = list_ak_cols)
        ## put everything in a xarray
        # satellite specific info
        ds = xr.Dataset({'qa0': (['index', 'level'], qa0),
                     'ak': (['index', 'level'], ak.values),
                     'pavg0': (['index', 'level_pressure'], pavg)},
                     coords={'index': subdata.index,
                             'level': range(fixed_nlevels - 1),
                              'level_pressure': range(fixed_nlevels)})
        # put together basic info and satellite info
        subdata = subdata.to_xarray()
        subdata = xr.merge([ds, subdata])
        
        ## filtering according to information provided with data
        # filter on daytime/nigthttime, chi2 and land in the tropical band
        subfilter = pd.DataFrame(columns = ['day_night', 'chi2', 'land_sea'])
        subfilter['day_night'] =  readnc(filein, ['day_night_index'])
        subfilter['chi2'] =  readnc(filein, ['xhi2'])
        subfilter['land_sea'] = readnc(filein, ['land_sea_index'])
        # plus beware of surface level: Surf_P_id must be > retained_lev
        # (both indices begin at 0)
        subfilter['nb_surf_lev'] = readnc(filein, ['Surf_P_id'])
        mask = np.where((subfilter['day_night'] == 1) & (subfilter['chi2'] < 5) & ( subfilter['nb_surf_lev'] > retained_lev ))[0]
        subdata = subdata.isel(index=mask)
        
        ## index = number of the observation among the remaining ones 
        subdata["index"] = np.arange(len(subdata["index"]))         
        ## dump to netCDF - here, one per month to keep size not too large
        subdata.to_netcdf('~/monitor_{}{}_{}_{}{}.nc'.format(stationID, networkID, spec, year, month))
    

