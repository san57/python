#####################
Random measurements
#####################

.. automodule:: pycif.plugins.measurements.random_perparam