#######################################
Contributing to the documentation
#######################################

.. role:: bash(code)
   :language: bash

The documentation is written in `reStructuredText <https://docutils.sourceforge.io/rst.html>`__ (rst)
and built using the Python tool `Sphinx <https://www.sphinx-doc.org/en/master/>`__.
Sources for the documentation are provided within the `CIF Git repository <https://git.nilu.no/VERIFY/CIF>`__.

Locally compiling the documentation
-----------------------------------

Requirements
============

To contribute to the documentation the following softwares need to be install on your system:

* `Sphinx <https://www.sphinx-doc.org/en/master/>`__ : automatic generation of html pages from rst files
* `Graphviz <https://www.graphviz.org/>`__ : embed graphics in the documentation
* pycif : the CIF python package needs to be properly installed on your system to automatically build from modules

Compiling commands
==================

Once Sphinx and Graphviz installed, you should be able to compile the documentation source files into html locally.
To do so, type:

.. code-block:: bash

    cd CIF_ROOT/docs
    make html

Then, you can simply open html files generated in :bash:`CIF_ROOT/docs/build/html/` in any web browser.


Adding new files in the documentation
-------------------------------------

New files should be added in relevant sections and link to the corresponding table of content.
Tables of contents are generally placed in the :bash:`index.rst` file in each sub-folders of the documentation.
Therein, the file name should be added below the command :bash:`.. toctree::` alongside existing files
(the rst extension is not mandatory in that command).

When documentating a new plugin in pyCIF, please find a template of the corresponding documentation file below:

.. code-block::

    #####################
    My awesome plugin
    #####################

    .. automodule:: pycif.plugins.the_type_of_plugin.my_awesome_plugin


This allows the documentation to build the documentation automatically from the code of the plugin (see below).

Automatic construction from codes
---------------------------------

The documentation is designed to include information in the pycif plugins directly and automatically.
To allow this feature to work properly, the :bash:`__init__.py` file of the plugin being documented should include:

* a docstring header: i.e. some rst compatible text at the very top of the file, embraced by `"""`:

  .. code-block:: python

      """
      This is a short description of my awesome plugin.

      I can use rst syntax in there, which will automatically compile in the documentation
      """

  the result will be inserted in a `Description` section of the corresponding entry of the documentation

* a dictionary :bash:`input_arguments`: this dictionary is both used to define default values and document arguments
  that are needed in the configuration file; for each entry, you can add a :bash:`"doc"` entry, including a string describing the corresponding argument:

  .. code-block:: python

      input_arguments = {
          "some_argument": {
              "doc": "some description",
              "default": None if mandatory else a default value,
              "accepted": a python type that the argument should fit
          }
      }


Proposing tutorials
-------------------

Tutorials are critical for new users and developers to start working with the CIF efficiently.
They should encompass as many situations as possible.
Experienced users/developers are encouraged to share their experience and explain how to tackle some specific difficulties they met in using the system.

Rules
=====

* Tutorials should be dedicated to a very specific problem (coding one type of Plugins, using one feature, etc.)
* Tutorials should be concise and precise
* Illustrations are worth a thousand words: include examples of codes, Yaml, etc.;
  when doing so, include long pieces of code or Yaml in separate files and use the command:

  .. code-block::

     .. literalinclude:: example_of_code.py
         :linenos:
         :language: python


* Tutorials should remain up-to-date: their contributors are encouraged to check that past tutorials they wrote are still valid;
  in any case, please provide at least the last version of the CIF for which they where tested and/or a corresponding date
*


