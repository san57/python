from .forward import forward
from .adjoint import adjoint

_name = "dump2inputs"

requirements = {"model": {"any": True, "empty": False}}


def ini_mapper(
    transform, inputs={}, outputs={}, backup_comps={}
):
    # Keeps same info from the tracer
    trid = (transform.component[0], transform.parameter[0])
    mapper = {
        "inputs": {trid: {
            **inputs.get(trid, {}),
            **{"force_dump": False}}},
        "outputs": {trid: inputs.get(trid, {})},
    }

    return mapper
