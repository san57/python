#####################
Test of the adjoint
#####################


.. automodule:: pycif.plugins.modes.adjtl_test
