import numpy as np


def rinvprod(obsvect, dy):

    # At the moment, this is valid for diagonal observation matrices only
    # TODO: Include these lines into rinvprod.py, with option for
    # non-diagonal matrices, eventually
    err = np.where(obsvect.yobs_err == 0, np.nan, obsvect.yobs_err)
    
    return dy / err ** 2
