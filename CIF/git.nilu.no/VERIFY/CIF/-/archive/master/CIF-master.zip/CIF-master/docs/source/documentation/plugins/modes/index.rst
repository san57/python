#################
Computation modes
#################


.. role:: bash(code)
   :language: bash


.. contents:: Contents
    :local:

Description
===========

The :bash:`mode` class executes computation modes in pyCIF.
This is the highest level class in pyCIF.
At the execution of pyCIF, the specified :bash:`mode` is executed and
all the rest of the configuration is derived from it.

Available Modes
===============

The following :bash:`modes` are implemented in pyCIF:

.. toctree::

    forward
    adjtl_test
    analytic
    enkf
    variational


Required parameters, dependencies and functions
===============================================

As the highest level class in pyCIF, the :bash:`mode` class is never called by any other pyCIF class.
Thus, it only needs the following function to be made available in the module:

execute
-------

The function :bash:`execute` executes the computation mode.

Arguments are:

:self: the mode itself

The function does not need to return objects explicitly.
However, it is recommended to make it return an object characterizing the output.
For instance, for the test of the adjoint, the function :bash:`execute` returns the error of the test;
for the forward mode, it returns the observation vectors with comparison between original observations and simulations.