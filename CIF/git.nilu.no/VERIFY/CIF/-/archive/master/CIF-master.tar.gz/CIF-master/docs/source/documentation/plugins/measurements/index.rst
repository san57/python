######################
Measurement generators
######################

.. role:: bash(code)
   :language: bash


Available Measurements generators
=================================

The following :bash:`measurements` are implemented in pyCIF:

.. toctree::

    standard
    random

