#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This is the repository where all plugins are stored"""


from . import register
