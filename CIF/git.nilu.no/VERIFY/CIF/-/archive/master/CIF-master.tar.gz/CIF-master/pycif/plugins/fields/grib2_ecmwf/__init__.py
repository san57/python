from .fetch import fetch
from .get_domain import get_domain
from .read import read

_name = "ECMWF"
_version = "grib2"