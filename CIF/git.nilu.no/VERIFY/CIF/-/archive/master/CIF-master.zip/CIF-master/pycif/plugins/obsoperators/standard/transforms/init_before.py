from .utils import add_default
from pycif.utils.classes.transforms import Transform


def init_before(self,
                controlvect,
                all_inputs, all_outputs,
                backup_comps, mapper):
    
    # Initializes the overall transform pipe
    if not hasattr(controlvect, "transform_pipe"):
        controlvect.transform_pipe = Transform.from_dict({})

    all_transforms = self.transform_pipe
    transforms = controlvect.transform_pipe
    transfs_ids = getattr(transforms, "attributes", [])

    components = controlvect.datavect.components
    comps = components.attributes
    
    # Loops backwards on available transformations and update inputs/outputs
    # According to model inputs
    itransf = len(transfs_ids)
    while itransf > 0:
        itransf -= 1
        ntransf_loc = 0
        transform = "{}_before".format(transfs_ids[itransf])

        # Initializes mapper if not already done
        if transform not in mapper:
            # Replacing the transform by a transform class
            # if not already initialized
            transf = getattr(transforms, transfs_ids[itransf])
            if transf is None:
                transf = Transform.from_dict({}, orig_name=transform)
            
            setattr(all_transforms, transform, transf)
            all_transforms.attributes.insert(0, transform)

            # Updating the general mapper, and creates a local one
            transf_mapper = transf.ini_mapper(
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )
            transf.mapper = transf_mapper
            mapper[transform] = transf_mapper

            all_inputs.update(transf_mapper["inputs"])
            all_outputs.update(transf_mapper["outputs"])

        else:
            transf_mapper = mapper[transform]

        for trid in transf_mapper["inputs"]:
            if transf_mapper["inputs"][trid].get("force_dump", False):
                # Adding a dump transformation before the present transform
                yml_dict = {
                    "plugin": {
                        "name": "dump2inputs",
                        "version": "std",
                        "type": "transform",
                    },
                    "component": [trid[0]],
                    "parameter": [trid[1]],
                }
                add_default(
                    all_transforms,
                    yml_dict,
                    position="index",
                    index=itransf,
                    mapper=mapper,
                    init=True,
                    inputs=all_inputs,
                    outputs=all_outputs,
                    backup_comps=backup_comps,
                )
                ntransf_loc += 1
                itransf += 1
                continue

    # Add default transformations prior to other transforms
    itransf = 0
    for trid in all_inputs:
        prm = trid[1]
        cmp = trid[0]

        cmp_in = cmp if cmp in comps else backup_comps.get(cmp, None)
        if cmp_in is None:
            continue

        cmp_plg = getattr(components, cmp_in)

        # Fetch parameters
        # If no parameters, handle the component as a whole
        if not hasattr(cmp_plg, "parameters"):
            params = cmp_plg
            parameters = [""]
        else:
            params = cmp_plg.parameters
            parameters = params.attributes[:]

        param = getattr(params, prm, cmp_plg)

        # Temporal re-indexing if any
        if hasattr(param, "time_interpolation"):
            tinterp = param.time_interpolation
            yml_dict = {
                "plugin": {
                    "name": "time_interpolation",
                    "version": "std",
                    "type": "transform",
                },
                "method": getattr(tinterp, "method", "bilinear"),
                "component": [cmp],
                "parameter": [prm],
            }
            add_default(
                all_transforms,
                yml_dict,
                position="index",
                index=itransf,
                mapper=mapper,
                init=True,
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )

        # Vertical re-gridding if any
        if hasattr(param, "vertical_interpolation"):
            vinterp = param.vertical_interpolation
            yml_dict = {
                "plugin": {
                    "name": "vertical_interpolation",
                    "version": "std",
                    "type": "transform",
                },
                "method": getattr(vinterp, "method", "linear"),
                "psurf": getattr(vinterp, "psurf", 1013.25),
                "fill_nans": getattr(vinterp, "fill_nans", False),
                "coord_out": getattr(vinterp, "coord_out", "pres"),
                "component": [cmp],
                "parameter": [prm],
            }
            add_default(
                all_transforms,
                yml_dict,
                position="index",
                index=itransf,
                mapper=mapper,
                init=True,
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )

        # Regridding if any
        if hasattr(param, "regrid"):
            yml_dict = {
                "plugin": {
                    "name": "regrid",
                    "version": "std",
                    "type": "transform",
                },
                "dir_wgt": getattr(param.regrid, "dir_wgt", ""),
                "method": getattr(param.regrid, "method", "bilinear"),
                "component": [cmp],
                "parameter": [prm],
            }
            add_default(
                all_transforms,
                yml_dict,
                position="index",
                index=itransf,
                mapper=mapper,
                init=True,
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )

        # Rescaling if any
        if hasattr(param, "unit_conversion"):
            yml_dict = {
                "plugin": {
                    "name": "unit_conversion",
                    "version": "std",
                    "type": "transform",
                },
                "scale": getattr(param.unit_conversion, "scale", 1),
                "component": [cmp],
                "parameter": [prm],
            }
            add_default(
                all_transforms,
                yml_dict,
                position="index",
                index=itransf,
                mapper=mapper,
                init=True,
                inputs=all_inputs,
                outputs=all_outputs,
                backup_comps=backup_comps,
            )

        # Initializing the transformation chain for this parameter
        # Create a random name to identify the current transformation
        yml_dict = {
            "plugin": {
                "name": "fromcontrol",
                "version": "std",
                "type": "transform",
                "newplg": True,
            },
            "component": [cmp],
            "parameter": [prm],
            "orig_parameter_plg": param,
            "orig_component_plg": cmp_plg,
        }
        add_default(
            all_transforms,
            yml_dict,
            position="index",
            index=itransf,
            mapper=mapper,
            init=True,
            inputs=all_inputs,
            outputs=all_outputs,
            backup_comps=backup_comps,
        )

        # Initializing the transformation chain for this parameter
        # Create a random name to identify the current transformation
        yml_dict = {
            "plugin": {
                "name": "init_datastore",
                "version": "std",
                "type": "transform",
                "newplg": True,
            },
            "component": [cmp],
            "parameter": [prm],
            "orig_parameter_plg": param,
            "orig_component_plg": cmp_plg,
        }
        add_default(
            all_transforms,
            yml_dict,
            position="index",
            index=itransf,
            mapper=mapper,
            init=True,
            inputs=all_inputs,
            outputs=all_outputs,
            backup_comps=backup_comps,
        )
