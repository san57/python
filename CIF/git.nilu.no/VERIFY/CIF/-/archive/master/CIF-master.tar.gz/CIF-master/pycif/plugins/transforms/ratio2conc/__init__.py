import copy
import pandas as pd
from .adjoint import adjoint
from .forward import forward

_name = "ratio2conc"

requirements = {"model": {"any": True, "empty": False}}


def ini_mapper(transform, inputs={}, outputs={}, **kwargs):
    """ Re-arrange the mapper depending on the isotopic transforms to carry out


    :param self:
    :param transform:
    :param mapper:
    :param transform_type:
    :return:
    """
    
    names_in = transform.parameters_in.names
    names_out = transform.parameters_out.names
    components_in = transform.component
    components_out = len(names_out) * [transform.component[-1]]

    inputs_data = {}
    for trid_out in zip(components_out, names_out):
        inputs_data.update(inputs.get(trid_out, {}))

    loc_outputs = {(component, param):
                       dict(inputs_data,
                            **{'force_dump': False})
                   for (component, param) in zip(components_out, names_out)}

    loc_inputs = {(component, param):
                      dict(inputs_data,
                           **{'force_dump': False, 'force_read': True})
                  for (component, param) in zip(components_in, names_in)}

    mapper = {'inputs': loc_inputs, 'outputs': loc_outputs}

    for trid_out in zip(components_out, names_out):
        if trid_out in inputs:
            del inputs[trid_out]

    return mapper

