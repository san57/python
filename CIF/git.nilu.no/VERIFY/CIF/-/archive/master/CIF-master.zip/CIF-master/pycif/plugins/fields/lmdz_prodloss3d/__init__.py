from .read import read
from .write import write

_name = "LMDZ"
_version = "prodloss3d"

requirements = {"domain": {"name": "LMDZ", "version": "std", "empty": False}}
