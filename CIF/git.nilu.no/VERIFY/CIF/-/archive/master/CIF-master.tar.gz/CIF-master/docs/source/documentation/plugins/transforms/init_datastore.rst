###############################
Initialize transform data store
###############################

.. automodule:: pycif.plugins.transforms.init_datastore