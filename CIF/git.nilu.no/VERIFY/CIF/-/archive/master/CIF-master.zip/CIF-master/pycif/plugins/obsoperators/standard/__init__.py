from pycif.utils import path
from logging import info
from .obsoper import obsoper
from .transforms import init_transform
from .transforms.do_transforms import do_transforms

_name = "standard"

requirements = {
    "model": {"any": True, "empty": False},
    "obsvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "controlvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "platform": {"any": True, "empty": True},
}

input_arguments = {
    "autorestart": {
        "doc": "if interrupted, computations restart from the last simulated period. WARNING: the CIF cannot detect whether this period has been correctly written or is corrupt: it is necessary to check in the relevant directories and remove the last simulated period if a file has not been correctly written.",
        "default": False,
        "accepted": bool
    },

    "onlyinit": {
        "doc": "only generate the inputs for all periods, do not run the actual model",
        "default": False,
        "accepted": bool
    },
}

def ini_data(plugin, **kwargs):
    """Initializes the observation operator

    Args:
        plugin (dict): dictionary defining the plugin
        **kwargs (dictionary): possible extra parameters

    """

    info("Initializing the observation operator")

    workdir = plugin.workdir

    # Initializes the directory
    path.init_dir("{}/obsoperator".format(workdir))

    # Initializes transforms
    init_transform(plugin)
    
    # Re-compile model if necessary
    if hasattr(plugin.model, "compile"):
        plugin.model.compile()

    return plugin
