import os
import numpy as np
import pandas as pd
from logging import debug

from .read import read_flexpart_gridinit


def inicond_contribution(self, mode, subdir, dataobs,
                         fp_header_init):
    for obs_i, row in enumerate(dataobs.itertuples()):
        row = dataobs.iloc[obs_i]
        station = row.station

        runsubdir_init = os.path.join(
            self.run_dir_bg, station.upper(), subdir)
        file_date = row.date.strftime('%Y%m%d%H%M%S')
        file_name = 'grid_initial_{}_001'.format(file_date)

        if not os.path.isfile(os.path.join(runsubdir_init, file_name)):
            return

        debug("Reading {} for station {}".format(file_name, station))
        grid_init = read_flexpart_gridinit(
            runsubdir_init, file_name, fp_header_init)

        # Multiply 3-D sensitivity to background concentrations
        # WARNING: do not deal with temporal and vertical dimension yet
        nz = (fp_header_init.outheight != 0.).sum()
        ini_sensit = grid_init.T.reshape(nz, -1)
        inicond = {"sim": list(self.datainicond.values())[0]["spec"]}
        if mode == "tl" and "incr" in list(self.datainicond.values())[0]:
            inicond["sim_tl"] = list(self.datainicond.values())[0]["incr"]

        for data_id in inicond:
            dataini = inicond[data_id]
            ini_dates = pd.DatetimeIndex(
                dataini.time.values).to_pydatetime()
            inds_inicond = \
                np.argmin(np.abs(np.array([row.date])[:, np.newaxis]
                                 - ini_dates[np.newaxis, :]), axis=1)
            ini_sim = (
                dataini[inds_inicond, :,
                        self.domain.zlon_in.size:, 0].values
                * ini_sensit
            ).sum()

            # Filling simulation
            sim_col = dataobs.columns.get_indexer([data_id])
            dataobs.iloc[obs_i, sim_col] += ini_sim
