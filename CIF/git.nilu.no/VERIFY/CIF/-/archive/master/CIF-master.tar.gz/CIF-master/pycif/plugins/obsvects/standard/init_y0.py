import os
import numpy as np

from .utils import init_param


def init_y0(obsvect, **kwargs):
    """Initializes the observation vector. In most cases the observation
    vector is similar to the measurement vector but there is no reason
    for it to be the same, especially when super-observations are used
    (e.g. daily or afternoon averages, gradients, etc.)

    Args:
        obsvect (Plugin): the observation vector with all its attributes
        measurements (Plugin): the pre-loaded measurements

    Returns:
        obsvect, updated with horizontal and vertical coordinates,
        as well as model time steps

    """

    datei = getattr(obsvect, "datei")
    datef = getattr(obsvect, "datef")

    obsvect.dim = 0
    obsvect.yobs = np.ones(0)
    obsvect.yobs_err = np.ones(0)

    datavect = obsvect.datavect

    # If no definition is specified for the control vector in the Yaml,
    # return empty control vector
    if not hasattr(datavect, "components"):
        return obsvect

    # Else, carry on initializing
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
    
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
        
        component.isobs = comp in obsvect.default_obstypes
        
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
        
            # Skip tracers that are not control variables
            tracer.isobs = (
                comp in obsvect.default_obstypes
                or tracer.isobs
            )
            
            if not tracer.isobs:
                continue
            
            # Keeping a pointer to the correct location in the whole control
            tracer.ypointer = obsvect.dim
            
            # Initializing data for tracer if needed
            obsvect.dir_obsvect = \
                getattr(obsvect,
                        "dir_obsvect",
                        os.path.join(obsvect.workdir, "obsvect"))
            file_ref = "{}/{}/{}/monitor.nc".format(
                obsvect.dir_obsvect, comp, trcr
            )
            init_param(obsvect, tracer, trcr, file_ref)
            
            # Updating dimension and y0
            obs = tracer.datastore["data"]
            tracer.dim = len(obs)
            obsvect.dim += tracer.dim
            
            obsvect.yobs = np.append(obsvect.yobs, obs.loc[:, "obs"])
            
            # Appending errors
            to_append = obs.loc[:, "obserror"] if "obserror" in obs \
                else np.zeros(len(obs))
            obsvect.yobs_err = np.append(obsvect.yobs_err, to_append)
            
    obsvect.ysim = np.zeros((obsvect.dim))
    obsvect.dy = np.zeros((obsvect.dim))

    return obsvect
