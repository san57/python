######################
Gaussian cost function
######################

.. automodule:: pycif.plugins.simulators.gausscost