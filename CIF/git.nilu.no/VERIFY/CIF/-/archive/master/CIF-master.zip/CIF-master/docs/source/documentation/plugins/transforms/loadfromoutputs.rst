#####################
Load model outputs
#####################

.. automodule:: pycif.plugins.transforms.loadfromoutputs