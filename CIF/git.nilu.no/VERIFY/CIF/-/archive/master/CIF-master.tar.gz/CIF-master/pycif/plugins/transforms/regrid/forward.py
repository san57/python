import os

import numpy as np
import xarray as xr
import copy
from scipy.interpolate import RectBivariateSpline

from .utils.get_weights import get_weights

try:
    import cPickle as pickle
except ImportError:
    import pickle


def forward(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    # Stop here if do not need to compute the full adjoint
    if onlyinit:
        return

    xmod = pipe.datastore
    
    for trid in mapper["inputs"]:
        wgt_file = mapper["inputs"][trid]["weight_file"]
        
        # Inputs domain from the present tracer
        nlon_in = xmod[trid]["tracer"].domain.nlon
        zlon_in = xmod[trid]["tracer"].domain.zlon
        zlonc_in = xmod[trid]["tracer"].domain.zlonc
        nlat_in = xmod[trid]["tracer"].domain.nlat
        zlat_in = xmod[trid]["tracer"].domain.zlat
        zlatc_in = xmod[trid]["tracer"].domain.zlatc
        
        # Outputs domain from the mapper
        is_lbc = mapper["outputs"][trid].get("is_lbc", False)
        domain_out = mapper["outputs"][trid]["domain"]
        
        if is_lbc:
            nlon_out = domain_out.nlon_side
            nlat_out = domain_out.nlat_side
        
        else:
            nlat_out, nlon_out = domain_out.zlat.shape

        # Getting weights
        weights = get_weights(
            transf,
            wgt_file,
            nlon_in,
            nlat_in,
            zlon_in,
            zlat_in,
            zlonc_in,
            zlatc_in,
            domain_out,
            is_lbc)

        toregrid = copy.deepcopy(xmod[trid]["spec"])
        xmod[trid]["spec"] = do_regridding(
            toregrid, nlat_out, nlon_out, weights,
            min_weight=transf.min_weight
        )

        if mode == "tl":
            toregrid = xmod[trid].get("incr", 0. * toregrid)
            xmod[trid]["incr"] = do_regridding(
                toregrid, nlat_out, nlon_out, weights,
                min_weight=transf.min_weight)
    
    pipe.datastore = xmod
    
    return pipe


def do_regridding(data, nlat_out, nlon_out, weights, min_weight=1e-10):

    # Applying weights
    nlev = len(data.lev)
    ntimes = len(data.time)
    var_out = np.empty((ntimes, nlev, nlat_out, nlon_out))
    var_in = data.values
    for k, wgt in enumerate(weights):
        iout, jout = np.unravel_index(k, (nlat_out, nlon_out), order="F")
        wgt_filtered = list(zip(*[w for w in zip(*wgt) if w[2] > min_weight]))
        var_out[..., iout, jout] = np.sum(
            var_in[..., wgt_filtered[1], wgt_filtered[0]] * wgt_filtered[2], axis=2
        )

    times = data.time.values

    return xr.DataArray(
        var_out, coords={"time": times}, dims=("time", "lev", "lat", "lon")
    )
