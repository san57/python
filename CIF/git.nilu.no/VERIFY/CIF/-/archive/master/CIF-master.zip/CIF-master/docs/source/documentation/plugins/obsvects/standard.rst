#####################
Standard
#####################

.. automodule:: pycif.plugins.obsvects.standard