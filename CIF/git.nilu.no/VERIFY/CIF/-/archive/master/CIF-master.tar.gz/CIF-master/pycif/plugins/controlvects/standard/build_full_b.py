import numpy as np


def build_b(cntrlv, **kwargs):
    
    datavect = cntrlv.datavect
    bfull = np.eye(cntrlv.dim)
    
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)

        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue

        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)

            # Skip tracers that are not control variables
            if not hasattr(tracer, "hresol"):
                continue

            if hasattr(tracer, "hcorrelations") and tracer.hresol == "hpixels":
                corr = tracer.hcorrelations
                sqrt_evalues = corr.sqrt_evalues
                evectors = corr.evectors
                btmp = evectors.dot(np.diag(sqrt_evalues ** 2)).dot(evectors.T)

                for id in range(tracer.ndates):
                    slc = slice(
                        tracer.xpointer + id * tracer.hresoldim,
                        tracer.xpointer + (id + 1) * tracer.hresoldim)
                    bfull[slc, slc] = btmp

            # TODO: deal with temporal correlations
            # Deals with non-diagonal temporal correlations
            if hasattr(tracer, "tcorrelations"):
                corr = tracer.tcorrelations
                sqrt_evalues = corr.sqrt_evalues
                evectors = corr.evectors

            bfull[tracer.xpointer: tracer.xpointer + tracer.dim,
                  tracer.xpointer: tracer.xpointer + tracer.dim] *= \
                cntrlv.std[tracer.xpointer: tracer.xpointer + tracer.dim, np.newaxis] \
                * cntrlv.std[tracer.xpointer: tracer.xpointer + tracer.dim]

    return bfull
