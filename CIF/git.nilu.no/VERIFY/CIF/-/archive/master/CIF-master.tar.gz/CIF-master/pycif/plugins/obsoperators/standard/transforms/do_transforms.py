from logging import debug


def do_transforms(
    self,
    transform_pipe,
    mapper,
    controlvect,
    obsvect,
    di,
    df,
    mode,
    runsubdir,
    workdir,
    do_simu=True,
    onlyinit=False,
    **kwargs
):
    
    if not hasattr(transform_pipe, "datastore"):
        transform_pipe.datastore = {}
    
    # Making an dry-run in the reverse order for all transform to propagate
    # required informations back to the start
    if not onlyinit:
        do_transforms(
            self,
            transform_pipe,
            mapper,
            controlvect,
            obsvect,
            di,
            df,
            "adj" if mode in ["fwd", "tl"] else "tl",
            runsubdir,
            workdir,
            do_simu=do_simu,
            onlyinit=True,
            **kwargs
        )
        
    # Reversing dates if adjoint run
    ddi = min(di, df)
    ddf = max(di, df)
    
    # Re-ordering the tranformations if not in fwd mode
    transf_attributes = transform_pipe.attributes[:]
    if mode == "adj":
        transf_attributes = transf_attributes[::-1]

    for transform in transf_attributes:
        transf_mapper = mapper[transform]
        transf = getattr(transform_pipe, transform)
        debug('\n'.join(
            [
                "Doing transform {}: {} in {} mode".format(
                    transform, transf.plugin.name, mode
                ),
                "From inputs: {}".format(transf_mapper["inputs"].keys()),
                "To outputs: {}".format(transf_mapper["outputs"].keys()),
            ]
        )
        )
        
        apply_transform = transf.forward if mode in ["fwd", "tl"] \
            else transf.adjoint
        
        apply_transform(
            transform_pipe,
            controlvect,
            obsvect,
            mapper[transform],
            ddi,
            ddf,
            mode,
            runsubdir,
            workdir,
            do_simu=do_simu,
            onlyinit=onlyinit,
        )