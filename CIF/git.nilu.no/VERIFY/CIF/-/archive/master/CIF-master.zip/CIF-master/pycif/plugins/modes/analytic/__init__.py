from .execute import execute

from pycif.utils import path

_name = "analytic"

requirements = {
    "obsvect": {
        "any": True,
        "empty": False,
        "name": "standard",
        "version": "std",
    },
    "controlvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "obsoperator": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "platform": {
        "any": True,
        "empty": True
    },
}

input_arguments = {
    "dump_nc_base_control": {
        "doc": "Dumps elementary control vectors used to build the base "
               "functions as NetCDF format; this helps diagnosing whether "
               "base functions are computed based on e.g., fluxes consistent"
               " with the user expectations",
        "default": False,
        "accepted": bool
    }
}


def ini_data(plugin, **kwargs):
    workdir = getattr(plugin, "workdir", "./")

    # Initializes the directory
    path.init_dir("{}/base_functions".format(workdir))
    path.init_dir("{}/base_functions/H_matrix/".format(workdir))
