import numpy as np

from logging import info
from pycif.utils.datastores.dump import dump_datastore


def execute(self, **kwargs):
    """Runs the model in forward mode

    Args:
        setup (Plugin): definition of the full set-up

    """

    # Working directory
    workdir = self.workdir

    # Observation operator
    obsoper = self.obsoperator

    # Control vector
    controlvect = obsoper.controlvect

    # Simulation window
    datei = self.datei
    datef = self.datef

    # Some verbose
    info("Running a direct run")

    # Putting x at xb value if available
    if hasattr(controlvect, "xb"):
        controlvect.x = controlvect.xb

    # Running the observation operator
    obsvect = obsoper.obsoper(
        controlvect, obsoper.obsvect,
        "fwd", datei=datei, datef=datef, workdir=workdir,
        reload_results=self.reload_results,
        **kwargs
    )
    
    # Perturbs the output monitor if required in the Yaml
    if self.perturb_obsvect:
        # Altering obsvect and save data
        obserror = self.obserror * obsvect.ysim.std()

        obsvect.yobs = (
            np.random.normal(
                loc=0, scale=obserror, size=obsvect.ysim.size
            )
            + obsvect.ysim
        )
        obsvect.yobs_err[:] = obserror
        
        # Dumping the datastore with reference data
        obsvect.dump("{}/obsvect/".format(workdir))

    return obsvect
