from .fetch import fetch
from .read import read

_name = "LMDZ"
_version = "mass-fluxes"

requirements = {"domain": {"name": "LMDZ", "version": "std", "empty": False}}
