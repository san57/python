from pycif.utils.datastores.empty import init_empty


def outputs2native(
        self, data2dump, input_type, di, df, runsubdir, mode="fwd",
        dump=True, onlyinit=False, do_simu=True,
        **kwargs
):
    """Reads outputs to pycif objects.

    If the mode is 'fwd' or 'tl', only onservation-like outputs are extracted.
    For the 'adj' mode, all outputs relative to model sensitivity are extracted.

    Dumps to a NetCDF file with output concentrations if needed"""

    if mode in ["tl", "fwd"]:
        if not hasattr(self, "dataobs"):
            self.dataobs = {spec: init_empty()
                            for spec in self.chemistry.acspecies.attributes}

        # Read simulated concentrations
        # In classical model, this should correspond to reading output files
        # Here the observations are already stored in the model object
        datastore = self.dataobs

        # Loop over species in data2dump
        for trid in data2dump.datastore:
            if trid not in datastore:
                continue
            
            dsloc = datastore[trid]["data"]
            
            # Re-aggregate observations spanning several time steps
            # Obsvect divides by number of tstep at higher level
            # (in case the observation spans several periods)
            ds = dsloc.groupby(level=0).sum()
            ds = ds[["sim", "sim_tl"]]

            data2dump.datastore[trid]["data"] = ds

    return data2dump

    
