####################
Minimizers
####################

.. role:: bash(code)
   :language: bash


Available Minimizers
================================

The following :bash:`minimizers` are implemented in pyCIF:

.. toctree::

    congrad
    m1qn3