##############################################################
Contributing to the code development and reporting/fixing bugs
##############################################################

.. role:: bash(code)
   :language: bash

General coding rules
====================

* Write in a concise and precise manner
* Document your code
* Avoid using too specific packages to maintain the CIF in a state as generic as possible
* Include tutorials for new features
* Write in English only in your codes (including comments and variable names)
* Follow the general PEP8 and affiliated community standards


Reporting bugs or cleaning/reviewing the code
=============================================

Despite efforts by developers to maintain the code stable, bugs can remain undetected and/or can appear only in specific applications of the CIF.
Similarly, the code is writen in a manner as clean as possible, but improvements are always possible.

In both cases, you are encouraged to report such issues in the `GitLab interface <https://git.nilu.no/VERIFY/CIF/-/issues>`__.
A login is necessary to do so. If you don't have one, please request one by sending an email
to `help@community-inversion.eu <help@community-inversion.eu>`__.
If for some reason, you consider that you should not open a login, please directly report issues to the same mail address.

When fixing bugs yourself, you are encouraged to create a new dedicated branch locally.

.. code-block:: bash

    cd /where/you/have/the/sources
    git checkout -b [name_of_your_new_branch]


Fix and improve the code in the way you consider relevant, test it and commit your changes.
If you have a login, you can push your new branch to the GitLab server.
Once pushed to the GitLab server, please submit a merge request `here <https://git.nilu.no/VERIFY/CIF/merge_requests>`__
Otherwise, consider generating a git patch and sending to `help@community-inversion.eu <help@community-inversion.eu>`__.

To generate a patch from the branch :bash:`my_bug_fix_branch` to the main branch :bash:`master`, use the following commands:

.. code-block:: bash

   git checkout master
   git pull origin master
   git format-patch my_bug_fix_branch -o <target directory>


Implementing new features in the CIF
====================================

New features are welcome to the CIF.
However, before starting new developments, make sure than your specific feature is not already implemented as a specific application of more general capabilities of the system.
Feel free to contact the `development team <help@community-inversion.eu>`__.
If you have a GitLab login at NILU, please propose new features in the `GitLab interface <https://git.nilu.no/VERIFY/CIF/-/issues>`__ directly.
It allows the rest of the devolopers to follow what you are doing and possibly to propose solutions to your needs.

New features to implement in the CIF should not be application specific. They need to follow the general philosophy of the CIF
of avoiding redundant developments and coding in the most possible general way.


Testing your code
=================

Testing is an integral part of the coding process.
No branch should be merged to the main branch without proper testing.
The GitLab main repository is designed to run default tests whenever a branch is pushed.
These default tests are designed to detect unexpected side effects of a given development.
Any branch not passing these default tests will not be allowed to merge to the master branch.

However, these default tests are only simple tests and do not encompass all possible use of the system.
Therefore, merging a branch should not be requested without a proper testing of the newly developed feature.
Developers are encouraged to test their own developments on their systems and provide necessary data
and configuration files to the core development team to help reviewing and validating new codes.


