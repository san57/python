import numpy as np
import pandas as pd
import copy
import xarray as xr
import os
from pycif.utils.path import init_dir
from pycif.utils.datastores.dump import dump_datastore


def forward(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    
    if onlyinit:
        return
    
    inputs = transf.parameters_in.names
    outputs = transf.parameters_out.names
    components_in = transf.component
    components_out = len(outputs) * [transf.component[-1]]
    
    datastore = pipe.datastore
    
    # Save data for later use by adjoint
    dir_fwd = data = ddi.strftime("{}/../chain/isotopes".format(runsubdir))
    if not os.path.isdir(dir_fwd):
        init_dir(dir_fwd)
    
    for comp, spec in zip(components_out, outputs):
        file_fwd_data = \
            ddi.strftime(
                "{}/../chain/isotopes/{}_fwd_obsvect_{}_{}_%Y%m%d%H%M.nc"
                    .format(runsubdir, transf.orig_name, comp, spec))
        dump_datastore(
            datastore[(comp, spec)]["data"],
            file_monit=file_fwd_data,
            dump_default=False,
            col2dump=["parameter", "parameter_ref", "sim", "sim_tl"],
            mode="w",
        )

    # Starts reshaping the datastore
    df_all_isos = {trid[1]: datastore[trid]["data"]
                   for trid in zip(components_out, outputs)}
    dfspec = df_all_isos[outputs[0]]
    spec = inputs[-1]
    
    sub_inputs = [(sign, spec) for sign in inputs[:-1]]
    for sub_input in sub_inputs:
        sign_id = sub_input[0]
        spec_id = sub_input[1]
        sign_attr = getattr(transf.parameters_out, sign_id)
        r_std = sign_attr.standard
        refs = sign_attr.refs
        isotopologues = sign_attr.isotopologues
        
        ref_sims = sum([df_all_isos[ref][["sim", "sim_tl"]]
                        for ref in refs])
        isotopologue_sims = sum([df_all_isos[iso][["sim", "sim_tl"]]
                                 for iso in isotopologues])
        
        mask_sign = dfspec["parameter_ref"] == sign_id.lower()

        ref_sim = ref_sims.loc[mask_sign, "sim"]
        isotopologue_sim = isotopologue_sims.loc[mask_sign, "sim"]

        sign_sim = isotopologue_sim / ref_sim
        sign_sim /= r_std
        sign_sim = (sign_sim - 1) * 1000
        
        comp_in = components_in[inputs.index(sign_id)]
        dfout = datastore[(comp_in, sign_id)]["data"]
        
        dfout.loc[:, "sim"] = sign_sim

        # Applying tangent-linear
        if mode == "tl":
            ref_sim_tl = ref_sims.loc[mask_sign, "sim_tl"]
            isotopologue_sim_tl = isotopologue_sims.loc[mask_sign, "sim_tl"]

            sign_sim_tl = (isotopologue_sim_tl / ref_sim -
                           isotopologue_sim / ref_sim ** 2 * ref_sim_tl)

            sign_sim_tl /= r_std / 1000

            dfout.loc[:, "sim_tl"] = sign_sim_tl

    spec_sims = sum([df_all_isos[s][["sim", "sim_tl"]] for s in outputs])
    spec_id = inputs[-1]
    comp = components_in[-1]
    mask_spec = dfspec["parameter_ref"] == spec_id.lower()
    dfout = datastore[(comp, spec_id)]["data"]
    dfout.loc[:, "sim"] = spec_sims.loc[mask_spec, "sim"]

    if mode == "tl":
        dfout.loc[:, "sim_tl"] = spec_sims.loc[mask_spec, "sim_tl"]

