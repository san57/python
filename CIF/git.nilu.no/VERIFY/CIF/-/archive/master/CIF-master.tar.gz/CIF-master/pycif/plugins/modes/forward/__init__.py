from .execute import execute

_name = "forward"

requirements = {
    "controlvect": {
        "name": "standard", "version": "std", "empty": True, "any": True
    },
    "obsoperator": {"name": "standard", "version": "std", "empty": True},
}

input_arguments = {
    "perturb_obsvect": {
        "doc": "If True, perturbs the output observation vector "
               "to generate truth in OSSEs. The formula used for "
               "the perturbations is "
               ":math:`\delta y \sim \mathcal{N}(0, \sigma_\epsilon)`,"
               " with :math:`\sigma_\epsilon = \sigma_\mathbf{y} \;.\; \delta`; "
               ":math:`\delta` is the value specified in ${obserror}. "
               "Perturbed simulations are saved in the ``obs`` column of "
               "the output ``monitor.nc`` file; :math:`\sigma_\mathbf{y} \;.\; \delta`"
               "is stored in the column ``yobs_err``",
        "default": False,
        "accepted": bool
    },

    "obserror": {
        "doc": "The scale used to generate perturbation on the errors.",
        "default": 0.,
        "accepted": float
    },

    "reload_results": {
        "doc": "Reload results from previous simulations. "
               "If True does not recomputed already computed simulations",
        "default": False,
        "accepted": bool
    }
}
