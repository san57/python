
from .read import read
from .read_glob import read_glob
from .write import write
from .fetch import fetch

_name = "FLEXPART"
_version = "nc"

requirements = {'domain': {'name': 'FLEXPART', 'version': 'std', 'empty': False}}

default_values = {
    "latname_flx": "latitude",
    "lonname_flx": "longitude",
    "timename_flx": "time"
}