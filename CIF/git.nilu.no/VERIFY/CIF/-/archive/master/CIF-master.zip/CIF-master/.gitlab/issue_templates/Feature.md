Summary

(Summarize missing feature you want to have in pycif)

What is the purpose of the new feature and how many users might benefit?

(Is it a general improvement? Do you need it for a specific project?)

Possible solutions

(If you have any idea, please make suggestion)

