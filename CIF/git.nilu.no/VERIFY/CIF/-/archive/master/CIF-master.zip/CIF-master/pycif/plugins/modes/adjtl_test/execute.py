
import copy

import numpy as np

from logging import info


def execute(self, **kwargs):
    """Runs the model in forward mode

    Args:
        self (Plugin): the mode Plugin with all set-up arguments

    """

    # Working directory
    workdir = self.workdir

    # Control vector
    controlvect = self.controlvect

    # Observation operator
    obsoper = self.obsoperator
    
    # Obsvervation vector
    obsvect = self.obsvect

    # Simulation window
    datei = self.datei
    datef = self.datef
    
    # Check that the observation vector is not empty
    if len(obsvect.yobs) == 0:
        raise Exception(
            "WARNING: trying to run a test of the adjoint with no "
            "observation points! Please check your monitor file"
        )
    
    # Increments in x
    increments = self.increments
    incrmode = self.incrmode
    testspace = self.testspace

    if incrmode == "rand":
        np.random.seed(self.random_seed)

    if testspace == "control":
        if incrmode == "cst":
            controlvect.dx = \
                increments * controlvect.std * np.sign(controlvect.xb)

        elif incrmode == "rand":
            controlvect.dx = (
                np.random.normal(0, increments, controlvect.dim)
                * controlvect.std
            )

    elif testspace == "chi":
        if incrmode == "cst":
            controlvect.chi[:] = increments

        elif incrmode == "rand":
            controlvect.chi = np.random.normal(0, increments,
                                               controlvect.chi_dim)

        controlvect.dx = (
            controlvect.sqrtbprod(controlvect.chi, **kwargs) - controlvect.xb
        )

    if testspace not in ["control", "chi"] or incrmode not in ["cst", "rand"]:
        info(
            "The increment mode you specified can't be parsed: {}".format(
                incrmode
            )
        )
        info(
            "Please check the definition of the running mode "
            "in your Yaml file"
        )
        raise Exception
    
    controlvect.x = copy.deepcopy(controlvect.xb)
    controlvect.xb += controlvect.dx

    # Some verbose
    info("Computing the test of the adjoint")

    # Get the machine accuracy
    accuracy = np.finfo(np.float64).eps
    
    # Running the tangent linear code of the model
    obsvect = obsoper.obsoper(
        controlvect,
        obsvect,
        "tl",
        datei=datei,
        datef=datef,
        workdir=workdir,
        reload_results=self.reload_results,
        **kwargs
    )

    # Computing < H.dx, H.dx >
    scaleprod1 = np.nansum(np.power(obsvect.dy, 2))

    # Putting increments in the observation vector
    obsvect.dy = np.where(np.isnan(obsvect.dy), 0, obsvect.dy)
    
    # Running the observation operator
    controlvect = obsoper.obsoper(
        controlvect,
        obsvect,
        "adj",
        datei=datei,
        datef=datef,
        workdir=workdir,
        reload_results=self.reload_results,
        **kwargs
    )
    
    # Computing < dx, H*(H.dx) >
    if testspace == "control":
        scaleprod2 = ((controlvect.xb - controlvect.x) * controlvect.dx).sum()

    elif testspace == "chi":
        scaleprod2 = (
            controlvect.sqrtbprod_ad(controlvect.dx, **kwargs) * controlvect.chi
        ).sum()

    else:
        scaleprod2 = np.nan

    # Final verbose
    info("Machine accuracy: {}".format(accuracy))
    info("< H.dx, H.dx >   = {:.17E}".format(scaleprod1))
    info("< dx, H*(H.dx) > = {:.17E}".format(scaleprod2))
    info(
        "The difference is {:.1E} times the machine accuracy".format(
            np.floor(np.abs(scaleprod2 / scaleprod1 - 1) / accuracy)
        )
    )
    
    # Return test
    return np.floor(np.abs(scaleprod2 / scaleprod1 - 1) / accuracy)
