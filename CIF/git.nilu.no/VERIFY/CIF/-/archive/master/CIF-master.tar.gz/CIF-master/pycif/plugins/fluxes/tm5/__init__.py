from .fetch import fetch
from .read import read
from .write import write

_name = "TM5"

requirements = {
    "domain": {"name": "dummy", "version": "std", "empty": False}
}

