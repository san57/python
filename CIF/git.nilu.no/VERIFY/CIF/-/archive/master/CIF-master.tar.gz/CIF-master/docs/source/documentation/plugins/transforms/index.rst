####################
Transformations
####################

.. role:: bash(code)
   :language: bash


Available Transformations
=========================

The following :bash:`transforms` are implemented in pyCIF:

.. toctree::

    run_model
    init_datastore
    fromcontrol
    toobsvect
    dump2inputs
    loadfromoutputs
    timeavg
    satellites
    families
    conc2ratio
    ratio2conc
    unit_conversion
    regrid
    vertical_interpolation



