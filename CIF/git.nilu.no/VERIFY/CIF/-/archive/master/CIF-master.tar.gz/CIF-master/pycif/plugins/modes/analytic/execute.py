import copy
import os
import glob
import re
import pandas as pd
import numpy as np
import scipy
import pickle
from logging import info
from pycif.utils.datastores.dump import read_datastore
from .basefunctions import compute_base_functions, check_base_functions
from .build_H import build_H


def execute(self, **kwargs):
    """Performs an analytical inversions, including computation of base
    functions"""
    
    # Working directory
    workdir = self.workdir

    # Control vector
    controlvect = self.controlvect
    xb_ref = copy.deepcopy(controlvect.xb)
    
    # Observation operator
    obsoper = self.obsoperator
    
    # Observation vector
    obsvect = self.obsvect

    # Simulation window
    datei = self.datei
    datef = self.datef

    # Some verbose
    towrite = """
        Running an analytical inversion with the following modules:
            Observation operator: {}
            Model: {}
        """.format(
        obsoper.plugin.name, obsoper.model.plugin.name
    )
    info(towrite)
    
    # Check if H already computed
    base_dir = "{}/base_functions/H_matrix/".format(workdir)
    H_file = os.path.join(base_dir, "H.pickle")
    try:
        with open(H_file, "rb") as f:
            harray = pickle.load(f)
    
    except IOError:
        # Check base functions and re-compute if necessary
        missing_base_functions = \
            check_base_functions(base_dir, controlvect.dim)
        compute_base_functions(self, controlvect, missing_base_functions)
        
        # Re-construct the H operator
        harray = build_H(controlvect, obsvect, base_dir)
    
    # Do analytical inversion
    # Xa = Xb + K(y-Hx)
    # K = BH*(R + HBH*)-1
    # Pa = B - KHB
    controlvect.xb[:] = xb_ref[:]
    dy = obsvect.yobs - np.dot(harray, controlvect.xb)
    bfull = controlvect.build_b(controlvect)
    rfull = obsvect.build_r(obsvect)

    srm = scipy.linalg.inv(rfull + harray.dot(bfull.dot(harray.T)))
    kmatrix = bfull.dot(harray.T.dot(srm))

    xa = xb_ref + kmatrix.dot(dy)
    pa = bfull - kmatrix.dot(harray.dot(bfull))

    # Saving posterior vector
    controlvect.x = xa
    
    dir_control = "{}/controlvect/".format(workdir)
    file_xa = "{}/controlvect_post.pickle".format(dir_control)
    controlvect.dump(file_xa, to_netcdf=True, dir_netcdf=dir_control)
    
    # Saving posterior simulations
    obsvect.ysim = np.dot(harray, xa)
    dir_dump = "{}/obsvect/".format(workdir)
    obsvect.dump(dir_dump)
    