import copy
import os
from pycif.utils.datastores.dump import read_datastore


def read(obsvect, dir_dump):
    
    datavect = obsvect.datavect
    
    # If no definition is specified for the control vector in the Yaml,
    # return empty control vector
    if not hasattr(datavect, "components"):
        return obsvect

    # Else, carry on initializing
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
    
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
    
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
        
            # Skip tracers that are not control variables
            tracer.isobs = (
                comp in ["concs", "insitu", "flasks", "satellites"]
                or tracer.isobs
            )
            
            if not tracer.isobs:
                continue

            file_monitor = "{}/{}/{}/monitor.nc".format(
                dir_dump, comp, trcr
            )
            ds = read_datastore(file_monitor)
            
            tracer.datastore["data"] = ds

            obsvect.ysim[tracer.ypointer: tracer.ypointer + tracer.dim] = \
                ds["sim"]
            obsvect.dy[tracer.ypointer: tracer.ypointer + tracer.dim] = \
                ds["sim_tl"]
            obsvect.yobs[tracer.ypointer: tracer.ypointer + tracer.dim] = \
                ds["obs"]
            obsvect.yobs_err[tracer.ypointer: tracer.ypointer + tracer.dim] = \
                ds["obserror"]
