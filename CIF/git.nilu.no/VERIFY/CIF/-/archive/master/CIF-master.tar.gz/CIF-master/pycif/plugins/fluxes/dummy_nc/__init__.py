from .read import read
from .write import write

_name = "dummy"
_version = "nc"

requirements = {"domain": {"name": "dummy", "version": "std", "empty": False}}
