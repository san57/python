#####################
Standard
#####################

.. automodule:: pycif.plugins.controlvects.standard