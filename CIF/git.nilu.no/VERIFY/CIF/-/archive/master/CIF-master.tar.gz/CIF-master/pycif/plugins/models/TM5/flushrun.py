from glob import glob

from pycif.utils import path


def flushrun(self, rundir, mode):
    """Cleaning the simulation directories to limit space usage"""

    list_subdirs = glob("{}/*/".format(rundir))

    # Removing big files in TM5 directories
    for subdir in list_subdirs:
        path.remove("{}/somefilesXXXXX".format(subdir))
