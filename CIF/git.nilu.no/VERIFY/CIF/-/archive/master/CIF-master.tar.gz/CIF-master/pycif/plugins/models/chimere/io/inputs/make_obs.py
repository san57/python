import numpy as np
import pandas as pd

from pycif.utils.datastores.empty import init_empty


def make_obs(self, datastore, runsubdir, mode, tracer, do_simu=True):

    # If empty datastore, do nothing
    if datastore.size == 0:
        return

    # Otherwise, crop the datastore to active species
    if not hasattr(self, "dataobs") or getattr(self, "reset_obs", True):
        self.dataobs = {spec: init_empty()
                        for spec in self.chemistry.acspecies.attributes}

    self.dataobs[tracer] = pd.concat([self.dataobs[tracer], datastore],
                                     axis=0, sort=False)

    # If do not need to do CHIMERE simulation, just update obs datastore
    if not do_simu:
        return
    
    mask = (
        self.dataobs[tracer]["parameter"]
        .str.upper()
        .isin(self.chemistry.acspecies.attributes)
    )
    data2write = self.dataobs[tracer].loc[mask]
    
    # For adjoint, check that there is no NaN values
    if mode == "adj":
        if not np.all(~np.isnan(data2write.loc[:, "obs_incr"])):
            raise Exception("WARNING: pycif will drive CHIMERE adjoint "
                            "with NaNs values! Check prior informations")
    
    # Include only part of the datastore
    val = "obs_incr" if mode == "adj" else "obs"
    
    # Load previous obs if exists
    obs_file = "{}/obs.txt".format(runsubdir)
    if getattr(self, "iniobs", False):
        raise Exception("Warning! TODO: implement update of obs.txt")
    
    # Write in a txt file
    with open(obs_file, "w") as f:
        # total number of model's values that are necessary
        nbobs = len(data2write)
        nbdatatot = data2write["dtstep"].sum()

        # write header
        f.write(str(nbobs) + " " + str(nbdatatot) + "\n")

        # write data
        for d in data2write.iterrows():
            ddata = d[1]
            spec = ddata["parameter"].upper()

            # convert level to fortran
            ddata["level"] += 1

            # TODO: deal with altitude
            if np.isnan(ddata["level"]) or ddata["level"] <= 0:
                ddata["level"] = 1

            # Otherwise, loop over required time steps
            for dt in np.arange(ddata["dtstep"]):
                nbtstepglo = int(ddata["tstep_glo"] + dt)
                nh = self.nhour[nbtstepglo]
                tstep = self.subtstep[nbtstepglo]
                toprint = "{} {} {:.0f} {:.0f} {:.0f} {}".format(
                    nh - 1, tstep, ddata["i"], ddata["j"], ddata["level"], spec
                )

                # Append increment value in adjoint mode
                if mode == "adj":
                    toprint += " {:23.19e}".format(ddata[val])

                f.write(toprint + "\n")

    self.iniobs = True
    self.reset_obs = False