###############
Metos
###############



.. toctree::
    :maxdepth: 3

    toygauss







