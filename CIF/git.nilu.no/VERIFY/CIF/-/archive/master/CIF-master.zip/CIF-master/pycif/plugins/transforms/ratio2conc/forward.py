import numpy as np
import pandas as pd
import copy
import xarray as xr


def forward(
        transf,
        pipe,
        controlvect,
        obsvect,
        mapper,
        ddi,
        ddf,
        mode,
        runsubdir,
        workdir,
        **kwargs
):
    xmod = pipe.datastore

    inputs = transf.parameters_in.names
    outputs = transf.parameters_out.names
    in_types = transf.component
    iso_mass = transf.parameters_out.iso_mass
    spec_mass = transf.parameters_out.spec_mass
    unit = transf.unit

    noutputs = len(outputs)
    out_types = noutputs * [transf.component[-1]]
    r_stds = {sign: getattr(transf.parameters_out, sign).standard
              for sign in inputs[:-1]}

    keys = ['spec']
    if mode == 'tl':
        keys.append('incr')

    trid = (in_types[-1], inputs[-1])
    for trid_out in mapper["outputs"]:
        xmod[trid_out] = {k: xmod[trid][k] for k in xmod[trid]}
        xmod[trid_out]["spec"] = copy.deepcopy(xmod[trid]["spec"])
        if mode == 'tl':
            xmod[trid_out]["incr"] = copy.deepcopy(xmod[trid]["incr"])

    signatures = {sign: xmod[(in_types[0], sign)]['spec'] for sign in inputs[:-1]}
    spec_data = xmod[(in_types[-1], inputs[-1])]['spec']
    a_factors = {sign: (1 + signatures[sign] / 1000) * r_stds[sign] for sign in inputs[:-1]}

    # Save signature and data for later use by adjoint
    file_fwd_dataset = ddi.strftime(
        "{}/../chain/{}_fwd_%Y%m%d%H%M.nc"
            .format(runsubdir, transf.orig_name))

    fwd_dataset = spec_data.to_dataset(name="spec")
    for sign in inputs[:-1]:
        fwd_dataset[sign] = signatures[sign]
    fwd_dataset.to_netcdf(file_fwd_dataset)

    # Compute fwd spec
    for ioutput, (out_type, output) in enumerate(zip(out_types, outputs)):
        for isign, sign in enumerate(inputs[:-1]):
            t = noutputs // (2 ** (isign + 1))
            num_group = ioutput // t
            if num_group % 2:
                xmod[(out_type, output)]['spec'] *= a_factors[sign] / (1 + a_factors[sign])
            else:
                xmod[(out_type, output)]['spec'] *= 1 / (1 + a_factors[sign])

    # Applying tangent linear
    if mode == 'tl':
        signatures_tl = {sign: xmod[(in_types[0], sign)]['incr'] for sign in inputs[:-1]}
        spec_data_tl = xmod[(in_types[-1], inputs[-1])]['incr']

        for ioutput, (out_type, output) in enumerate(zip(out_types, outputs)):
            total_sum = spec_data_tl.copy()

            # spec_data increment
            for isign, sign in enumerate(inputs[:-1]):
                t = noutputs // (2 ** (isign + 1))
                num_group = ioutput // t
                if num_group % 2:
                    total_sum *= a_factors[sign] / (1 + a_factors[sign])
                else:
                    total_sum *= 1 / (1 + a_factors[sign])

            # signatures increment
            for isign_plus, sign_plus in enumerate(inputs[:-1]):
                total_multip = signatures_tl[sign_plus].copy()

                # multiplication terms for each signature increment
                for isign_times, sign_times in enumerate(inputs[:-1]):
                    t = noutputs // (2 ** (isign_times + 1))
                    num_group = ioutput // t

                    if isign_times == isign_plus:
                        if num_group % 2:
                            total_multip *= r_stds[sign_times] / 1000\
                                            / (1 + a_factors[sign_times]) ** 2
                        else:
                            total_multip *= - r_stds[sign_times] / 1000\
                                            / (1 + a_factors[sign_times]) ** 2
                    else:
                        if num_group % 2:
                            total_multip *= a_factors[sign_times] / (1 + a_factors[sign_times])
                        else:
                            total_multip *= 1 / (1 + a_factors[sign_times])

                total_sum += total_multip * spec_data
            xmod[(out_type, output)]['incr'] = copy.deepcopy(total_sum)

    # Mass correction if units are in mass
    if unit == 'mass':
        for i, (out_type, output) in enumerate(zip(out_types, outputs)):
            xmod[(out_type, output)]['spec'] *= \
                (iso_mass[i] / spec_mass)

        if mode == 'tl':
            for i, (out_type, output) in enumerate(zip(out_types, outputs)):
                xmod[(out_type, output)]['incr'] *= \
                    (iso_mass[i] / spec_mass)


    # Delete the useless inputs
    for trid in mapper["inputs"]:
        del xmod[trid]

    pipe.datastore = xmod
