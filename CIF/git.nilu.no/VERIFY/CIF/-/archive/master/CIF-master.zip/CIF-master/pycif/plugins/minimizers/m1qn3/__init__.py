"""

M1QN3 is a quasi-Newtonian optimization algorithm originally developed at
`INRIA <https///who.rocq.inria.fr/Jean-Charles.Gilbert/modulopt/optimization-routines/m1qn3/m1qn3.html>`__
to minimize functions with a very high number of variables.
The algorithm is described in `Gilbert and Lemaréchal, 1989
<https///link.springer.com/article/10.1007/BF01589113>`__.
The original code was written in Fortran;
F. Chevallier translated it to Python in 2005.


M1QN3 is ditributed under the `GNU General Public License <http://www.gnu.org/copyleft/gpl.html>`__
and listed in the `Free Software Directory <http://directory.fsf.org/project/m1qn3>`__.


"""

from types import MethodType

from .aux import mlis0
from .check import check_options
from .minimize import minimize
from .opt import m1qn3

_name = "M1QN3"

requirements = {
    "simulator": {
        "any": True,
        "empty": True,
        "name": "gausscost",
        "version": "std",
    },
}


input_arguments = {
    "niter": {
        "doc": "maximum number of iterations",
        "optional": True,
        "accepted": int
    },
    "nsim": {
        "doc": "maximum number of simulations",
        "optional": True,
        "accepted": int
    },
    "maxiter": {
        "doc": "maximum number of iterations; if one of the two previous"
               "is missing, :bash:`niter` is set to "
               ":bash:`maxiter` and :bash:`nsim` to 2 times :bash:`maxiter`",
        "default": 1,
        "accepted": int
    },
    "dxmin": {
        "doc": "absolute precision on x; optional",
        "default": 1e-20,
        "accepted": float
    },
    "df1": {
        "doc": "expected decrease for f",
        "default": 0.01,
        "accepted": float
    },
    "epsg": {
        "doc": "relative precision on the gradient",
        "default": 1e-20,
        "accepted": float
    },
    "mode": {
        "doc": "mode more M1QN3; for expert users only; see "
               "`M1QN3 documentation "
               "<https://who.rocq.inria.fr/Jean-Charles.Gilbert/modulopt/optimization-routines/m1qn3/m1qn3.pdf>`__"
               " for further details",
        "default": 0,
        "accepted": int
    },
    "nupdates": {
        "doc": "number of updates; for experts only",
        "default": 5,
        "accepted": int
    },

}

def ini_data(plugin, **kwargs):
    """Initializes M1QN3.

    Args:
        plugin (Plugin): options for the variational inversion

    Returns:
        updated plugin

    """

    # Function to check the consistency of options and arguments
    plugin.check_options = MethodType(check_options, plugin)

    # M1QN3 itself
    plugin.m1qn3 = MethodType(m1qn3, plugin)
    plugin.mlis0 = MethodType(mlis0, plugin)

    return plugin
