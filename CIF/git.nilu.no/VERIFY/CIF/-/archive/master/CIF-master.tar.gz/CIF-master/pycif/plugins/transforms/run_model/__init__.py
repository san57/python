from .forward import forward
from .adjoint import adjoint

_name = "run_model"

requirements = {"model": {"any": True, "empty": False}}


def ini_mapper(
    transform, inputs={}, outputs={}, backup_comps={}
):

    return transform.model.ini_mapper(
        inputs, outputs, backup_comps
    )
