####################
Fluxes
####################

.. role:: bash(code)
   :language: bash

Available Fluxes
=========================

The following :bash:`fluxes` are implemented in pyCIF:

.. toctree::
    :maxdepth: 3

    dummy_nc
    dummy_txt
    edgar_v5
    flexpart
    chimere
    lmdz_bin
    lmdz_sflx








