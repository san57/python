from pycif.utils.path import init_dir
from .dump import dump, load
from .init_bprod import init_bprod
from .init_xb import init_xb
from .sqrtbprod import sqrtbprod, sqrtbprod_ad
from .build_full_b import build_b

_name = "standard"

# It is necessary to initialize a domain, fluxes and the model itself
requirements = {
    "domain": {"any": True, "empty": False},
    "model": {"any": True, "empty": False},
    "components": {"any": True, "empty": True, "type": "fields"},
    "obsvect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
    "datavect": {
        "any": True,
        "empty": True,
        "name": "standard",
        "version": "std",
    },
}

input_arguments = {
    "save_out_netcdf": {
        "doc": "Save NetCDF format in addition to pickle "
               "when saving the control vector",
        "default": False,
        "accepted": bool
    }
}


def ini_data(plugin, **kwargs):
    """Initializes the state vector from information in the Yaml file

    Args:
        plugin (pycif.classes.plugins): the plugin to initialize

    """

    # Initializes reference directories if needed
    init_dir("{}/controlvect/".format(plugin.workdir))

    # Initializes the control vector
    plugin.init_xb(plugin, **kwargs)

    # Initializing the product of chi by B^(1/2), only if components specified
    if hasattr(plugin.datavect, "components"):
        plugin.init_bprod(plugin, **kwargs)
