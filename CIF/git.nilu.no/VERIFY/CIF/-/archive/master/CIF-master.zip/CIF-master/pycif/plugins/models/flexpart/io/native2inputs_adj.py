import numpy as np
import datetime
import os
import pandas as pd
import xarray as xr

from logging import info, debug

from ..utils.flexpart_header import read_header
from pycif.plugins.models.flexpart.io.inputs.read import read_flexpart_grid, read_flexpart_gridinit


def native2inputs_adj(
        self, data2dump, input_type,
        di, df, runsubdir, mode='fwd', **kwargs):
    """Reads outputs to pycif objects.

       Does nothing for now as we instead read FLEXPART output 
       inside loop over observations in obsoper.py 

    """

    ddi = min(di, df)

    dataobs = list(self.dataobs.values())[0]
    nobs = len(dataobs)
    subdir = ddi.strftime("%Y%m")

    # Initialize header
    fp_header_glob = read_header(
        os.path.join(self.run_dir_glob,
                     dataobs.head(1)['station'][0].upper(),
                     subdir, 'header'))

    fp_header_nest = None
    if self.nested:
        fp_header_nest = read_header(
            os.path.join(self.run_dir_nest,
                         dataobs.head(1)['station'][0].upper(),
                         subdir, 'header_nest'))

    fp_header_init = None
    if self.read_background:
        fp_header_init = read_header(
            os.path.join(self.run_dir_bg,
                         dataobs.head(1)['station'][0].upper(),
                         subdir, 'header'))

    # Nest domain definition
    ix1 = self.domain.ix1
    ix2 = self.domain.ix2
    iy1 = self.domain.iy1
    iy2 = self.domain.iy2

    # Save to datastore for debugging purposes
    obs_ghg = np.nan * np.empty(nobs)
    obs_bkg = np.nan * np.empty(nobs)
    obs_sim = np.nan * np.empty(nobs)
    obs_model = np.nan * np.empty(nobs)
    obs_check = np.nan * np.empty(nobs)
    obs_bkgerr = np.nan * np.empty(nobs)
    obs_err = np.nan * np.empty(nobs)

    info("di, df: {}, {}, {}".format(di, df, datetime.datetime.now()))

    # Initialize output sensitivity
    nlat, nlon = self.domain.zlat.shape
    flx_sensit = np.zeros((len(self.input_dates[ddi]), 1, nlat, nlon))

    nz = (fp_header_init.outheight != 0.).sum()
    ini_dates = pd.DatetimeIndex(
        list(self.datainicond.values())[0]["spec"].time.values
    ).to_pydatetime()
    inicond_sensit = np.zeros((len(ini_dates), nz, nlat, nlon))

    for obs_i, row in enumerate(dataobs.itertuples()):
        station = row.station
        file_date = row.date.strftime('%Y%m%d%H%M%S')

        if input_type == "fluxes":
            # Find time stamps in dataflx to compare with grid
            # TODO: deal with several species
            fluxes = {"sim": list(self.dataflx.values())[0]["spec"]}

            dataflx = list(self.dataflx.values())[0]["spec"]
            flx_dates = pd.DatetimeIndex(
                dataflx.time.values).to_pydatetime()

            # Read nested grids
            runsubdir_nest = os.path.join(
                self.run_dir_nest, station.upper(), subdir)
            file_name = 'grid_time_nest_{}_001'.format(file_date)

            debug("Reading {} for station {}".format(file_name, station))

            if not os.path.isfile(os.path.join(runsubdir_nest, file_name)):
                continue

            grid_nest, gtime, ngrid = read_flexpart_grid(
                runsubdir_nest, file_name, fp_header_nest,
                numscale=self.numscale)

            # Conversion of footprints
            grid_nest *= self.coeff * self.mmair / self.molarmass

            # Nest sensitivity
            nest_sensit = grid_nest.T[:ngrid].reshape(ngrid, -1)
            inds_flx = \
                np.argmin(np.abs(np.array(gtime)[:, np.newaxis]
                                 - flx_dates[np.newaxis, :]), axis=1)

            zeros = np.zeros((inds_flx.size, self.domain.zlon_in.size),
                             dtype=np.int)
            np.add.at(
                flx_sensit,
                (inds_flx.reshape(-1, 1),
                 zeros,
                 np.arange(self.domain.zlon_in.size)[np.newaxis, :],
                 zeros),
                nest_sensit * row.obs_incr,
            )

            # Read global footprints
            # TODO read correction factor dry air)
            runsubdir_glob = os.path.join(
                self.run_dir_glob, station.upper(), subdir)
            file_name = 'grid_time_{}_001'.format(file_date)

            if not os.path.isfile(os.path.join(runsubdir_glob, file_name)):
                continue

            grid_glob, gtime_glob, ngrid_glob = \
                read_flexpart_grid(
                    runsubdir_glob, file_name, fp_header_glob,
                    numscale=self.numscale)

            # Conversion of footprints
            grid_glob *= self.coeff * self.mmair / self.molarmass

            # Global sensitivity
            glob_sensit = \
                grid_glob.T[:ngrid_glob].reshape(ngrid_glob, -1)
            glob_sensit[:, self.domain.raveled_indexes_glob] = 0.

            inds_flx_glob = \
                np.argmin(np.abs(np.array(gtime_glob)[:, np.newaxis]
                                 - flx_dates[np.newaxis, :]), axis=1)

            zeros = np.zeros((inds_flx.size,
                              nlat - self.domain.zlon_in.size),
                             dtype=np.int)
            np.add.at(
                flx_sensit,
                (inds_flx_glob.reshape(-1, 1),
                 zeros,
                 np.arange(self.domain.zlon_in.size, nlat)[np.newaxis, :],
                 zeros),
                glob_sensit * row.obs_incr,
            )

        elif input_type == "inicond":
            # Sensitivity to background
            if not self.read_background:
                continue

            runsubdir_init = os.path.join(
                self.run_dir_bg, station.upper(), subdir)
            file_name = 'grid_initial_{}_001'.format(file_date)

            if not os.path.isfile(os.path.join(runsubdir_init, file_name)):
                continue

            debug("Reading {} for station {}".format(file_name, station))

            grid_init = read_flexpart_gridinit(
                runsubdir_init, file_name, fp_header_init)

            # Multiply 3-D sensitivity to background concentrations
            # WARNING: do not deal with temporal and vertical dimension yet
            ini_sensit = grid_init.T.reshape(nz, -1)
            inds_inicond = \
                np.argmin(np.abs(np.array([row.date])[:, np.newaxis]
                                 - ini_dates[np.newaxis, :]), axis=1)[0]

            inicond_sensit[inds_inicond, :, self.domain.zlon_in.size:, 0] \
                += ini_sensit * row.obs_incr

    outkey = (input_type, "CH4")

    if input_type == "fluxes":
        data2dump[outkey]["adj_out"] = xr.DataArray(
            flx_sensit,
            coords={"time": self.input_dates[ddi]},
            dims=("time", "lev", "lat", "lon"))

    elif input_type == "inicond":
        data2dump[outkey]["adj_out"] = xr.DataArray(
            inicond_sensit,
            coords={"time": ini_dates},
            dims=("time", "lev", "lat", "lon"))

    return data2dump

