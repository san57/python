from .fetch import fetch
from .read import read
from .write import write

_name = "LMDZ"
_version = "sflx"

requirements = {"domain": {"name": "LMDZ", "version": "std", "empty": False}}
