
import datetime

import numpy as np
import pandas as pd


from pycif.utils.dates import date_range
from pycif.utils.netcdf import readnc


def ini_periods(self, **kwargs):
    datei = self.datei
    datef = self.datef

    # List of sub-simulation windows
    # Only one for TM5
    self.subsimu_dates = [datei, datef]

    # simulation time steps (used to extract concentrations
    # To test every hours
    self.tstep_dates = {datei: pd.date_range(datei, datef, freq="H")}
    
    self.tstep_all = np.array(self.tstep_dates[datei][:])

    # when inputs are needed; 12H frequency for test
    self.input_dates = {datei: pd.date_range(datei, datef, freq="12H")}

