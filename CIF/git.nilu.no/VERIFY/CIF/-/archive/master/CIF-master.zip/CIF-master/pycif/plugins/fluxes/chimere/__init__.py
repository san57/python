from .fetch import fetch
from .read import read
from .write import write

_name = "CHIMERE"
_version = "AEMISSIONS"

requirements = {
    "domain": {"name": "CHIMERE", "version": "std", "empty": False},
    "chemistry": {"name": "CHIMERE", "version": "gasJtab", "empty": False},
}

input_arguments = {
    "dir": {
       "doc": "directory where the AEMISSIONS.nc or BEMISSIONS.nc files are located",
       "default": None,
       "accepted": str
    },
    "file": {
       "doc": "form of the name of the files to use"
              " if different from A/B EMISSIONS.YYYYMMDDHH.hh.nc",
       "default": "{A_or_B_type}EMISSIONS.%Y%m%d%H.{nho}.nc",
       "accepted": str
    },
    "emis_type": {
        "doc": "type of emission files",
        "default": "anthro",
        "accepted": {
            "anthro": "AEMISSIONS.nc",
            "bio": "BEMISSIONS.nc"
        }
    }
}


def ini_data(plugin, **kwargs):
    """Initializes the control vector from information in the Yaml file

    Args:
        plugin (pycif.classes.plugins): the plugin to initialize

    Return:
        - xb (explicitly and stored)
        - B (std and covariance definition), not stored
        - projectors and adjoints
        - product with B1/2


    """

    # Default file names for CHIMERE: AEMISSIONS
    class SafeDict(dict):
        def __missing__(self, key):
            return '{' + key + '}'
    
    plugin.file = plugin.file.format_map(SafeDict(
        A_or_B_type="A" if plugin.emis_type == "anthro" else "B"))
    