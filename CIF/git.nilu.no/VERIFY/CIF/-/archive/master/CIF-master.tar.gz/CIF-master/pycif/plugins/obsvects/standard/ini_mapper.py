def ini_mapper(obsvect, inputs={}, outputs={}, backup_comps={}):

    # Output dictionary
    obs_outputs = {}
    components = obsvect.datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
    
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
    
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
            
            if tracer.isobs:
                obs_outputs[(comp, trcr)] = {"isobs": True}

    # Executable
    mapper = {
        "inputs": {},
        "outputs": obs_outputs,
    }

    return mapper
