import pandas as pd
import os
import pickle
import numpy as np
from pycif.utils.datastores.dump import read_datastore


def build_H(controlvect, obsvect, base_dir):
    datavect = obsvect.datavect
    
    # If no definition is specified for the control vector in the Yaml,
    # return empty control vector
    if not hasattr(datavect, "components"):
        raise Exception("Computing H operator with no observations")
    
    # Else, carry on initializing
    harray = np.zeros((obsvect.dim, controlvect.dim))
    jacobian = {}
    components = datavect.components
    for comp in components.attributes:
        component = getattr(components, comp)
        
        # Skip if component does not have parameters
        if not hasattr(component, "parameters"):
            continue
        
        for trcr in component.parameters.attributes:
            tracer = getattr(component.parameters, trcr)
            
            # Skip tracers that are not control variables
            tracer.isobs = (
                    comp in obsvect.default_obstypes
                    or tracer.isobs
            )
            
            if not tracer.isobs:
                continue
            
            ds = tracer.datastore["data"]
            hloc = pd.DataFrame(columns=range(controlvect.dim),
                                index=ds.index)
            for idim in range(controlvect.dim):
                monitor_file = \
                    "{}/obsvect_{:04d}/{}/{}/monitor.nc"\
                        .format(base_dir, idim, comp, trcr)
                data = read_datastore(monitor_file)
                hloc.loc[:, idim] = data.loc[:, "sim"].values
                
            jacobian[(comp, trcr)] = hloc
            harray[tracer.ypointer: tracer.ypointer + tracer.dim, :] = \
                hloc

    # Dumping H
    H_file = os.path.join(base_dir, "H.pickle")
    with open(H_file, "wb")as f:
        pickle.dump(harray, f, pickle.HIGHEST_PROTOCOL)
    
    return harray
