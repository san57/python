import os

from pycif.utils import path


def fetch(ref_dir, ref_file, input_dates, target_dir, tracer=None, **kwargs):
    if ref_dir == "" and hasattr(tracer, "dir"):
        input_dir = tracer.dir
    else:
        input_dir = ref_dir

    if ref_file == "" and hasattr(tracer, "file"):
        input_file = tracer.file
    else:
        input_file = ref_file

    list_files = {
        datei: list(set([dd.strftime("{}/{}".format(input_dir, input_file))
                for dd in input_dates[datei]]))
        for datei in input_dates
    }
    list_dates = {datei: [] for datei in input_dates}

    # Fetching
    for datei in input_dates:
        tmp_list = []
        for f in list_files[datei]:
            target_file = "{}/{}".format(target_dir, os.path.basename(f))
            path.link(f, target_file)
            tmp_list.append(os.path.basename(target_file))
        list_files[datei] = tmp_list
    
    return list_files, list_dates
