from pycif.utils.path import init_dir
from .init_components import init_components

_name = "standard"

# It is necessary to initialize a domain, fluxes and the model itself
requirements = {
    "domain": {"any": True, "empty": False},
    "model": {"any": True, "empty": False},
    "components": {"any": True, "empty": True, "type": "fields"},
}


def ini_data(plugin, **kwargs):
    """Initializes the state vector from information in the Yaml file

    Args:
        plugin (pycif.classes.plugins): the plugin to initialize

    """

    # Initializes reference directories if needed
    init_dir("{}/datavect/".format(plugin.workdir))

    # Saves reference directories and file formats if not prescribed
    # Look for directory by order of priority:
    # 1) directly in tracer definition
    # 2) in component definition if specified
    # 3) in model fluxes if any
    # Getting the right emissions
    init_components(plugin)
