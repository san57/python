#####################
Forward run
#####################


.. automodule:: pycif.plugins.modes.forward
