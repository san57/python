from .read import read

_name = "TM5"

requirements = {"domain": {"name": "dummy", "version": "std", "empty": False}}
