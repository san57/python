########################
Tutorials for developers
########################

This section is dedicated to helping developers to contribute to the CIF.
The following tutorials explain how to implement some plugins to pycif:

.. toctree::
    :maxdepth: 3

    newplugin/newplugin.rst
    newmodel/newmodel.rst


