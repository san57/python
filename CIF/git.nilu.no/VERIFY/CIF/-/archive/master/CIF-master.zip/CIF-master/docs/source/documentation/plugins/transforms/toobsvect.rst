###############################
Datastore to observation vector
###############################

.. automodule:: pycif.plugins.transforms.toobsvect