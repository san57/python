########################
Tutorials for users
########################

.. toctree::
    :maxdepth: 3

    first-simu/index
    first-inversion/index

All tutorials assume that you already have successfully :doc:`installed</installation>` pyCIF.
