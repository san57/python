import shutil
from distutils.dir_util import copy_tree

from logging import info
from pycif.utils.path import init_dir
from .make_chemistry import create_chemicalscheme
from .read_chemistry import read_chemicalscheme

_name = "CHIMERE"
_version = "gasJtab"

input_arguments = {
    "schemeid": {
        "doc": "Name of the chemical scheme",
        "accepted": str
    },
    "nreactamax": {
        "doc": "Max number of reactants/reaction",
        "default": 4,
        "accepted": int
    },
    "ntemps": {
        "doc": "Number of tabul. temperatures for stoichio.",
        "default": 4,
        "accepted": int
    },
    "ntabmax": {
        "doc": "Max number of rate constants",
        "default": 22,
        "accepted": int
    },
    "nlevphotmax": {
        "doc": "Max number of tabulated photolysis levels",
        "default": 50,
        "accepted": int
    },
    "ntabuzenmax": {
        "doc": "Max number of tabulated zenith angles",
        "default": 20,
        "accepted": int
    },
    "nphotmax": {
        "doc": "Max number of photolysis reactions",
        "default": 50,
        "accepted": int
    },
    "dir_precomp": {
        "doc": "Directory where pre-defined chemical schemes are stored. The "
               "assumed structure is: ``${dir_precomp}/${schemeid}/``",
        "optional": True,
        "accepted": str
    }
}


def ini_data(self, **kwargs):
    """Initializes the chemistry depending on the model used
    for the inversion.

    Args:
        plugin (ChemistryPlugin): chemistry definition

    Returns:
        Updates on the fly the chemistry
    """

    info("Initializing the Chemistry")

    # Copying the chemical scheme to the working directory
    workdir = self.workdir
    dirchem_ref = "{}/chemical_scheme/{}/".format(workdir, self.schemeid)
    self.dirchem_ref = dirchem_ref

    shutil.rmtree(dirchem_ref, ignore_errors=True)
    init_dir(dirchem_ref)
    
    # If pre-computed scheme is specified
    try:
        copy_tree(
            "{}/{}/".format(self.dir_precomp, self.schemeid), dirchem_ref
        )

        # Read chemistry
        self.read_chemicalscheme(**kwargs)

    # Otherwise, initialize files from the yaml
    except:
        self.create_chemicalscheme()
