####################
Simulators
####################

.. role:: bash(code)
   :language: bash




Available Simulators
===============================

The following :bash:`simulators` are implemented in pyCIF:

.. toctree::

    dummy
    gausscost

