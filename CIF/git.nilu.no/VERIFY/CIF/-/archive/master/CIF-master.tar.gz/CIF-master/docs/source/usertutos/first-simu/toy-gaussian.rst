##################################################################
First forward simulation with the toy Gaussian Model
##################################################################

.. role:: bash(code)
   :language: bash


Here we generate pyCIF outputs for a forward run using
:doc:`the Toy Gaussian Model</documentation/plugins/models/toy-gaussian>`.
To do so, follow the steps.
Please note :doc:`here</documentation/paths>` some instructions about how pyCIF deals with paths.

1. Set up a Yaml configuration:

    - copy the content of the reference Yaml file available :doc:`here<yaml_fwd>` to a directory of your choice
    - the yaml is plug-and-play ready, you only have to define the following environment variables:
        - :bash:`CIF_OUTPUT`: where the outputs will be generated
        - :bash:`CIF_ROOT`: path where the CIF sources are

      the two variables can be found in the yaml; pyCIF automatically replaces them with corresponding environment variables;
      please find details :doc:`here</documentation/paths>`

2. Run pyCIF based on your Yaml file:

    .. code-block:: bash

        python -m pycif path-to-your-yaml

3. Explore the results in :bash:`workdir`; if you used the default content of the yaml, you should find files in
  :bash:`${CIF_OUTPUT}/CIF_dummy_test/`:

    - :bash:`$workdir/obsvect/monitor.nc`: the output file with perturbed simulations

The example produces five days of simulations using a Gaussian model with arbitrary meteorological conditions,
fluxes distributed to show the text 'CIF', 50 stations randomly distributed over the domain.
You can play with these parameters to see the different possible outputs:

    - l. 176: :bash:`nstations`: you can reduce or increase the number of virtual sites
    - l. 144-159: :bash:`flx_formula`: you can change the formula used to generate fluxes;
      accepted arguments to be changed are:
        - variables: :bash:`zlon` or :bash:`zlat`
        - period: a typical horizontal lenght scale
        - operations: :bash:`product` or :bash:`sum`


