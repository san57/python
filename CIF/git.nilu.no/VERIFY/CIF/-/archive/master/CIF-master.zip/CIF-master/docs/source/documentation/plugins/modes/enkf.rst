#######################
Ensemble Kalman filters
#######################


.. automodule:: pycif.plugins.modes.enkf
