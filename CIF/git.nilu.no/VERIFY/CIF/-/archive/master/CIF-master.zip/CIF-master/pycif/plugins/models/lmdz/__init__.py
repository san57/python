import os
import shutil

from pycif.utils import path
from logging import info
from pycif.utils.classes.setup import Setup
from .flushrun import flushrun
from .ini_mapper import ini_mapper
from .ini_periods import ini_periods
from .io.native2inputs import native2inputs
from .io.outputs2native import outputs2native
from .io.native2inputs_adj import native2inputs_adj
from .io.outputs2native_adj import outputs2native_adj
from .run import run
from .io.inputs import make_input

_name = "LMDZ"

requirements = {
    "domain": {"name": "LMDZ", "version": "std", "empty": False},
    "fluxes": {
        "name": "LMDZ",
        "version": "sflx",
        "empty": True,
        "newplg": True,
    },
    "chemistry": {"name": "CHIMERE", "version": "gasJtab", "empty": False},
    "emis_species": {
        "name": "LMDZ",
        "version": "bin",
        "type": "fluxes",
        "empty": True,
        "newplg": True,
    },
    "meteo": {
        "name": "LMDZ",
        "version": "mass-fluxes",
        "empty": True,
        "any": False,
        "subplug": True,
        "preftree": "datavect/components",
    },
    "inicond": {
        "name": "LMDZ",
        "version": "ic",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
    "prescrconcs": {
        "name": "LMDZ",
        "version": "prescrconcs",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
    "prodloss3d": {
        "name": "LMDZ",
        "version": "prodloss3d",
        "empty": True,
        "any": False,
        "type": "fields",
        "newplg": True,
    },
}

# Replacement component if not defined in state vector
# backup_comps = {"inicond": "isoinicond", "fluxes": "isosignatures"}
backup_comps = {"inicond": "isoinicond"}

# Required inputs for running a LMDz simulations
required_inputs = [
    "fluxes",
    "meteo",
    "inicond",
    "def",
    "chem_fields",
    "prescrconcs",
    "prodloss3d",
    "traj",
    "exe",
]

default_values = {
    "periods": "1MS",
    "physic": True,
    "thermals": False,
    "conv_scheme": "TK",
    "dump": False,
    "autoflush": True
}


def ini_data(plugin, **kwargs):
    """Initializes LMDZ

    Args:
        plugin (Plugin): the model plugin to initialize
        **kwargs (dictionary): possible extra parameters

    Returns:
        loaded plugin and directory with executable

    """

    info("Initializing the model")

    workdir = getattr(plugin, "workdir", "./")

    # Cleaning the model working directory
    shutil.rmtree("{}/model/".format(workdir), ignore_errors=True)

    # Initializes the directory
    path.init_dir("{}/model".format(workdir))

    # copying the executable
    target = "{}/model/".format(workdir) + os.path.basename(plugin.fileexec)
    source = plugin.fileexec
    shutil.copy(source, target)

    # LMDZ has a fixed integration time step
    plugin.tstep = 0

    # Initializes default values
    # Period of sub-simulations: default = 1 month
    if not hasattr(plugin, "periods"):
        plugin.periods = "1MS"

    # Convection scheme: default = TK = Tiedke
    if not hasattr(plugin, "conv_scheme"):
        plugin.conv_scheme = "TK"

    # Loading input fluxes if specified, otherwise, loads default inputs
    for spec in plugin.chemistry.emis_species.attributes:
        tracer = getattr(plugin.chemistry.emis_species, spec)

        if hasattr(tracer, "provider") and hasattr(tracer, "format"):
            name = tracer.provider
            version = tracer.format

        else:
            name = "LMDZ"
            version = "sflx"

        tracer = Setup.load_registered(
            name, version, "fluxes", plg_orig=tracer
        )
        Setup.load_setup(
            Setup.from_dict({"fluxes": tracer}), "fluxes", level=1, **kwargs
        )

        setattr(plugin.chemistry.emis_species, spec, tracer)

    return plugin
