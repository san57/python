import numpy as np
from pycif.utils.datastores.empty import init_empty


def outputs2native_adj(
        self, data2dump, input_type, di, df, runsubdir, mode="fwd", dump=True,
        **kwargs
):
    """Reads outputs to pycif objects.

    If the mode is 'fwd' or 'tl', only onservation-like outputs are extracted.
    For the 'adj' mode, all outputs relative to model sensitivity are extracted.

    Dumps to a NetCDF file with output concentrations if needed"""
    
    if mode == "adj" and input_type == "concs":
        # Unfold observations spanning several time steps
        for trid in data2dump:
            ds = data2dump[trid]["data"]
            ds = ds.loc[ds.index.repeat(ds["dtstep"])]
            ds.loc[:, "tstep"] = \
                ds.groupby(level=0)["tstep"]\
                    .transform(
                    lambda x: np.arange(x.iloc[0], x.iloc[0] + len(x)))
            
            data2dump[trid]["data"] = ds
            
        # Saves the data to the model
        # Other models might need an input file to be writen here to get info
        #  on observations
        self.dataobs = data2dump
        
