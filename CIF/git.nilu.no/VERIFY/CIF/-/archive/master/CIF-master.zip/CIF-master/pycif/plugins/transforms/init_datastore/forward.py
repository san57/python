

def forward(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        **kwargs
):

    ddi = min(di, df)

    if pipe == {}:
        xout = transform.from_dict({})
        xout.datastore = {}
        xmod = {}

    else:
        xout = pipe
        xmod = pipe.datastore

    # Basic objects
    tracer_ids = mapper["outputs"]

    for trid in tracer_ids:
        tracer = tracer_ids[trid]

        comp = trid[0]
        trcr = trid[1]

        force_read = tracer.get("force_read", False)

        component = transform.orig_component_plg
        tracer = transform.orig_parameter_plg

        # Saving reference directories if specified
        xmod[trid] = {"tracer": tracer}
        xmod[trid]["fileorig"] = getattr(tracer, "file", None)
        xmod[trid]["dirorig"] = getattr(tracer, "dir", None)
        xmod[trid]["varname"] = getattr(tracer, "varname", None)

        xout.datastore = xmod
    