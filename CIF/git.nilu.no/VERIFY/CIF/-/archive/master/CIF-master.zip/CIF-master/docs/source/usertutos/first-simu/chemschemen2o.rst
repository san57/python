The yaml below defines a chemical scheme for N2O, adapted from Rona Thompson by Marielle Saunois and Isabelle Pison.

.. literalinclude:: n2o_lmdz_scheme.yml
    :linenos:
    :language: yaml


