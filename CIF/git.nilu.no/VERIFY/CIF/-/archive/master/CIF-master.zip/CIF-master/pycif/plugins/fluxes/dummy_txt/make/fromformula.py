import numpy as np


def makefromformula(formula, zlon, zlat, formula_type="sum"):
    # If variable in formula, means applying an operator
    if "variable" in formula:
        if formula["variable"] == "zlat":
            var = zlat
        elif formula["variable"] == "zlon":
            var = zlon
        else:
            raise Exception("Not recognized variable type (only zlon and zlat):"
                            + formula["variable"])

        formula_type = [k for k in formula if formula[k] is None][0]

        period = formula.get("period", 1)

        if formula_type == "cos":
            return np.cos(var / period)
        elif formula_type == "sin":
            return np.sin(var / period)
        elif formula_type == "exp":
            return np.exp(var / period)
        elif formula_type == "log":
            return np.exp(var / period)
        elif formula_type == "square":
            return (var / period) ** 2
        else:
            raise Exception("Not recognized operation:" + formula_type)

    # Otherwise
    formula_type = list(formula.keys())[0]
    tmp_vars = [
        makefromformula(formula_tmp, zlon, zlat,
                        formula_type=formula_type)
        for formula_tmp in formula[formula_type]
    ]

    if formula_type == "sum":
        out = 0.
        for var in tmp_vars:
            out += var
        return out
    elif formula_type == "product":
        out = 1.
        for var in tmp_vars:
            out *= var
        return out
    else:
        raise Exception("Not recognized operation:" + formula_type)
