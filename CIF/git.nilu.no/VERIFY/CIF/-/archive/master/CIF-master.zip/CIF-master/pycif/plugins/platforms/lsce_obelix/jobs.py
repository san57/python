import subprocess
import os
import numpy as np

from logging import info

job_template = (
    "#QSUB -s /bin/tcsh\n"
    "#PBS -q {queue}\n"
    "#PBS -l nodes={nodes}:ppn={cores}\n"
    "cd {rootdir}\n"
    "{env_variables}\n"
    "{exe}\n"
)


def init_job(self, exe, job_file):

    self.env_variables = getattr(self, "env_variables", {})
    self.env_variables.update(
        {"NUMEXPR_MAX_THREADS": self.cores}
    )

    env_variables = "" if not hasattr(self, "env_variables") \
        else "\n".join(
        ["setenv {} {}".format(key, self.env_variables[key])
         for key in self.env_variables]
    )
    
    job_str = job_template.format(
        queue=self.queue,
        nodes=self.nodes,
        cores=self.cores,
        rootdir=os.path.dirname(job_file),
        exe=exe,
        env_variables=env_variables
    )
    
    with open(job_file, "w") as f:
        f.write(job_str)
    

def submit_job(self, exe, job_file):
    """Submit a job to cluster with qsub"""

    # Initialize the job file to be submitted
    self.init_job(exe, job_file)
    
    # Submitting the job
    info("Submitting job on Obelix server")
    process = subprocess.Popen(
        "qsub {}".format(job_file),
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=os.path.dirname(job_file)
    )
    
    stdout, stderr = process.communicate()

    return stdout.decode('utf-8').strip()
    

def check_jobs(self, list_jobs):
    if len(list_jobs) == 0:
        return True
    
    process = subprocess.Popen(
        "qstat -u ${USER}",
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    stdout, stderr = process.communicate()

    # Sorting active jobs
    active_jobs = len(list_jobs) * [False]
    for ln in stdout.decode('utf-8').split("\n"):
        if os.getenv("USER") in ln:
            if ln.split()[0] in list_jobs:
                active_jobs[list_jobs.index(ln.split()[0])] = True
    
    return np.all(~np.array(active_jobs))





