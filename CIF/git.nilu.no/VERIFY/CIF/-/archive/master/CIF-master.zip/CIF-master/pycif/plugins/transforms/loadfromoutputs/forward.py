def forward(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        do_simu=True,
        onlyinit=False,
        **kwargs
):

    datastore = pipe.datastore
    for trid in mapper["inputs"]:
        input_type = trid[0]

        # If trid in datastore, dumps this one
        if trid in datastore:
            todump = [trid]

        # If input parameter is '',
        # dumps all available parameters of this component
        elif trid[1] == "":
            todump = [t for t in datastore if t[0] == input_type]

        # Otherwise check whether there is a component
        # encompassing all parameters (i.e., with '' as parameter)
        else:
            todump = [(input_type, "")]

        # Create new data to dump
        data2dump = transform.from_dict({})
        data2dump.datastore = {
            t: datastore[t] for t in todump if t in datastore
        }
        
        if not onlyinit:
            data2dump = transform.model.outputs2native(
                data2dump, input_type, di, df, runsubdir, mode,
                onlyinit=onlyinit
            )
    
            pipe.datastore.update(data2dump.datastore)

