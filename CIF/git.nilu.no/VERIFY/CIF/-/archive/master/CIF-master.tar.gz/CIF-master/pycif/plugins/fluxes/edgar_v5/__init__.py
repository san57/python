from .fetch import fetch
from .get_domain import get_domain
from .read import read
from .write import write

_name = "EDGAR"
_version = "v5"

input_arguments = {
    "dir": {
       "doc": "directory where the raw netcdf EDGARv5 files are located",
       "default": None,
       "accepted": str
    },
    "file": {
       "doc": "form of the name of the files to use if different from v50_*.nc XXXCHECKXXXX",
       "default": "available file XXwith the right date?XXX",
       "accepted": str
    }
}

