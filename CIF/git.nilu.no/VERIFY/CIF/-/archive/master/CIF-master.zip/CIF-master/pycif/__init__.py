"""Testing autodoc
AAAAAAAAAA
"""

from . import plugins
