#####################################
How to run a first forward simulation
#####################################

Tutorials on how to run a first foward simulation with various models driven by the CIF:

.. toctree::
    :maxdepth: 2

    toy-gaussian
    lmdz-sacs
    chimere

