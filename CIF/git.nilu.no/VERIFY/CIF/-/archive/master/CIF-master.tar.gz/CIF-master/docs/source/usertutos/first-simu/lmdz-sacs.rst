##################################################################
First forward simulation with LMDz-SACS
##################################################################

.. role:: bash(code)
   :language: bash


Here we run a forward simulation of
:doc:`LMdz-SACS Model</documentation/plugins/models/lmdz>` including the comparison to observation data.

Please note :doc:`here</documentation/paths>` some instructions about how pyCIF deals with paths.

1. Prepare the executable: in directory :bash:`model_sources/DISPERSION_gch`
    
    - edit :bash:`compile_dispersion` to chose the resolution and parameterfor filtering (first lines, user defined variables :bash:`dim` and :bash:`para`, available choices are detailed in the comments); save and close
    - compile the fortran chemistry-transport model:

.. code-block:: bash

    ./compile_dispersion


In case of a previous compilation,

.. code-block:: bash

    ./compile_dispersion clean

ensures that the new compilation starts from scratch.

=> check that you obtain an executable named :bash:`dispersion.e`, about 27M in size.

2. Locate the input files required by LMDz-SACS, which are generally precomputed from LMDz on-line (mass fluxes) or INCA (chemistry files):

    - the file containing the horizontal grid: XX put here possible choices XXXX
    - the file containing the vertical coefficient Ap, Bp: XXXX we should provide one per vertical grid, they are not so numerous??XXX
    - the mass fluxes
    - the kinetic files, containing the photolysis constants and prescribed concentration fields???: mandatory if photolysis and prescribed species used in the chemical scheme (see below) XXX mandatory anyway because of other variables?XXX
    - XXXX prescribed species??? they are not taken from the kinetic file???XXXXX
    - the files of deposition velocities for deposited species, if any used in the chemical scheme
XXXXXXXXXXXXXXXXXXX- the restart file: XXX mandatory or not?XXX

For information on these input files, see XXX LMDz-SACS documentation.XXXX

3. Prepare the chemical scheme and check that the associated LMDz-SACS input files are available. The chemical scheme consists in a yaml file on the following template:

.. code-block:: yaml
    
   # Name of the chemical scheme
   schemeid: my_scheme
   
   # Active species : species to be transported in the model
   acspecies:
     SPEC1:
       restart_id: 1  # number used as ID for the species in the restart files to read/to be created                      
       mass: 16.0425  # molar mass
     SPEC2:
       restart_id: 3
       mass: 16.0

   # emitted species (among the active species)
   emis_species:
      SPEC1:

  # State variables and J for photolysis 
  kinetic:
    dir: a_reference_directory
    file: file_containing_Js_prescribed_fields.nc 

  # Prescribed species: they are not active, XXXthey must be provided in the kinetic file??XXX
  prescrconcs:
    P1:
    P2:
    P3:

  # Deposited species, among the active species
  deposition:
    SPEC2:
      dir: another_reference_directory
      file: file_containing_deposition_velocities 

  # Chemical reactions
  reactions:
    r1: SPEC1+P1->AA+P2  k=1.125e-10
    r2: SPEC2+P2->BB+CC   k=3.75e-11
    r3: SPEC1+P2->CC       k(T)=Aexp(-B/T),A=2.45e-12,B=1775
    r4: SPEC1+P3->DD+EE    k(T)=Aexp(-B/T),A=7.1e-12,B=1270
    r5: SPEC2->CC        J=4

Examples: :doc:`here<chemschemech4>` or :doc:`here<chemschemen2o>` 

4. Prepare the input files required by LMDz-SACS 

    - emissions
    - initial conditions
    - XXXX prescribed species??? they are not taken from the kinetic file???XXXXX

5. Prepare the observations: 



