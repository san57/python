###############
Domains
###############


.. role:: bash(code)
   :language: bash


Available Domains
=========================

The following :bash:`domains` are implemented in pyCIF:

.. toctree::
    :maxdepth: 3

    dummy
    chimere
    lmdz
    flexpart







