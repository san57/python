from .fetch import fetch
from .make import make
from .read import read

_name = "dummy"
_version = "csv"

requirements = {"domain": {"name": "dummy", "version": "std", "empty": False}}

input_arguments = {
    "file": {
        "doc": "File format for the fluxes",
        "default": "dummy_meteo.txt",
        "accepted": str
    },
    "seed": {
        "doc": "Use random generation of meteo parameters",
        "default": False,
        "accepted": bool
    },
    "seed_id": {
        "doc": "ID for the numpy seed to be used",
        "default": 0,
        "accepted": int
    },
}


