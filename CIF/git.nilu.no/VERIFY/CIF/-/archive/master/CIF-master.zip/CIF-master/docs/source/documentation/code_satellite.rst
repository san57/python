The script below converts satellite data from IASI to the standard CIF monitor format.


.. literalinclude:: example_monitor_satellite.py
    :linenos:
    :language: python

..
    :lines: 1, 3-5
    :start-after: 3
    :end-before: 5
