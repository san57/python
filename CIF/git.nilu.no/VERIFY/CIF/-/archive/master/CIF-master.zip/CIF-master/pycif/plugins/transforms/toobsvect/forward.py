import pandas as pd
from logging import debug


def forward(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):
    if onlyinit:
        return
    
    ddi = min(di, df)
    ddf = max(di, df)

    datastore = pipe.datastore
    datavect = obsvect.datavect

    tracer_ids = mapper["outputs"]
    for tracer_id in tracer_ids:
        if tracer_id not in datastore:
            continue
        
        mod_input = tracer_id[0]
        trcr = tracer_id[1]

        # If this type of input is not considered in the control vector,
        # ignoring the model sensitivity
        component = getattr(getattr(datavect, "components", None),
                            mod_input,
                            None)
        parameters = getattr(component, "parameters", None)
        
        # Now fetch info from data structure to common structure
        param = getattr(parameters, trcr, None)
        if param is None:
            debug("{}/{} was not is the observation vector. Passing"
                  .format(trcr, mod_input))
            continue
        
        ds = param.datastore.get("data", None)

        if datastore.get(tracer_id, None).get("data", None) is None:
            debug("{}/{} was not provided any data to put back "
                  "in the observation vector".format(trcr, mod_input))
            continue
        
        data_sim = datastore[tracer_id]["data"]
        if "sim" not in data_sim:
            continue
        
        # Get simulations for the sub-period
        mask = (
            (ds["date"] + pd.to_timedelta(ds["duration"], unit="h") > ddi)
            & (ds["date"] < ddf)
        )
        obsvect.ysim[param.ypointer: param.ypointer + param.dim][mask] += \
            datastore[tracer_id]["data"].loc[:, ["sim"]].values.flatten()
        
        obsvect.dy[param.ypointer: param.ypointer + param.dim][mask] += \
            datastore[tracer_id]["data"].loc[:, ["sim_tl"]].values.flatten()
