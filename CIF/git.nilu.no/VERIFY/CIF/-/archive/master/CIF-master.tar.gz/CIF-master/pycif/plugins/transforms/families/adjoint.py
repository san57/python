import copy


def adjoint(
        transform,
        pipe,
        controlvect,
        obsvect,
        mapper,
        di,
        df,
        mode,
        runsubdir,
        workdir,
        onlyinit=False,
        **kwargs
):

    xmod = pipe.datastore
    trid_out = list(mapper["outputs"].keys())[0]

    for trid in mapper["inputs"]:
        xmod[trid] = {k: xmod[trid_out][k] for k in xmod[trid_out]}
        
        if not onlyinit:
            xmod[trid]["adj_out"] = copy.deepcopy(xmod[trid_out]["adj_out"])

    del xmod[trid_out]
    
    pipe.datastore = xmod

