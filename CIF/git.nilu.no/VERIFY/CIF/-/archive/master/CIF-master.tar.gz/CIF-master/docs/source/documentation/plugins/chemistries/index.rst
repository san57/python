###############
Chemistries
###############


.. role:: bash(code)
   :language: bash


Available Chemistries
=========================

The following :bash:`chemistries` are implemented in pyCIF:

.. toctree::
    :maxdepth: 3

    chimere
    TM5







