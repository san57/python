##################
Plugins in pyCIF
##################



.. toctree::
    :maxdepth: 3

    dependencies
    modes/index
    obsoperators/index
    transforms/index
    models/index
    controlvects/index
    obsvects/index
    datavects/index
    domains/index
    fluxes/index
    meteos/index
    minimizers/index
    simulators/index
    measurements/index
    obsparsers/index
    platforms/index
    chemistries/index


